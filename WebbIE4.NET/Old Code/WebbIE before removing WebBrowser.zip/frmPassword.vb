﻿Public Class frmPassword

    Private mCancelled As Boolean
    Private mPassword As String

    Public Function WasCancelled() As Boolean
        On Error Resume Next
        Return mCancelled
    End Function

    Public Function GetPassword() As String
        On Error Resume Next
        Return mPassword
    End Function

    Public Sub SetLabel(label As String)
        On Error Resume Next
        lblPassword.Text = label
        txtPassword.AccessibleDescription = label
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        On Error Resume Next
        mPassword = ""
        mCancelled = True
        Call Me.Hide()
    End Sub

    Private Sub frmPassword_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        On Error Resume Next
        Call modI18N.DoForm(Me)
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        On Error Resume Next
        mPassword = txtPassword.Text
        mCancelled = False
        Call Me.Hide()
    End Sub
End Class