﻿Public Class frmMediaControl

    'Control audio and video elements through a UI.
    'http://msdn.microsoft.com/en-us/library/system.type.invokemember%28v=vs.71%29.aspx

    Private Enum MediaType
        Audio
        Video
    End Enum

    Private Structure MediaElement
        Dim type As MediaType
        Dim index As Integer
    End Structure

    Private mMediaElement As MediaElement

    Public Sub SetVideoElement(index As Integer)
        Try
            mMediaElement.index = index
            mMediaElement.type = MediaType.Video
        Catch
        End Try
    End Sub

    Public Sub SetAudioElement(index As Integer)
        Try
            mMediaElement.index = index
            mMediaElement.type = MediaType.Audio
        Catch
        End Try
    End Sub

    Private Sub btnPlay_Click(sender As System.Object, e As System.EventArgs) Handles btnPlay.Click
        Try
            Call CurrentMediaItem().InvokeMember("play")
        Catch
        End Try
    End Sub

    Private Sub frmMediaControl_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        Try
            mMediaElement.type = MediaType.Audio
        Catch
        End Try
    End Sub

    Private Function CurrentMediaItem() As HtmlElement
        Try
            Dim tagName As String
            If mMediaElement.type = MediaType.Audio Then
                tagName = "AUDIO"
            Else 'Video by default
                tagName = "VIDEO"
            End If
            Dim doc As mshtml.IHTMLDocument3 = CType(modGlobals.gBrowserClass.Document, mshtml.IHTMLDocument3)
            Dim o As Object = doc.GetElementsByTagName(tagName).Item(mMediaElement.index)
            Return CType(o, HtmlElement)
        Catch
            Return Nothing
        End Try
    End Function

    Private Sub btnStop_Click(sender As Object, e As System.EventArgs) Handles btnStop.Click
        Try
            Call CurrentMediaItem().InvokeMember("stop")
        Catch
        End Try
    End Sub

    Private Sub tmrMedia_Tick(sender As System.Object, e As System.EventArgs) Handles tmrMedia.Tick
        Try
            If Me.Visible Then
                Dim element As HtmlElement = CurrentMediaItem()
                Dim o As Object = element.DomElement
                Dim el As mshtml.IHTMLElement = CType(o, mshtml.IHTMLElement)
                Dim currentTime As Double
                Dim duration As Double
                Dim gotDuration As Boolean
                Dim gotCurrentTime As Boolean
                If el.getAttribute("duration") Is Nothing Then
                    gotDuration = False
                Else
                    gotDuration = Double.TryParse(el.getAttribute("duration").ToString(), duration)
                    If Double.IsNaN(duration) Then ' experienced on facebook.com: audio, duration set, -1 value.
                        gotDuration = False
                    End If
                End If

                If el.getAttribute("currentTime") Is Nothing Then
                    gotCurrentTime = False
                Else
                    gotCurrentTime = Double.TryParse(el.getAttribute("currentTime").ToString(), currentTime)
                    If Double.IsNaN(currentTime) Then
                        gotCurrentTime = False
                    Else
                        If currentTime > duration Then
                            currentTime = duration
                        End If
                    End If
                End If
                'http://stackoverflow.com/questions/136195/trying-to-set-get-a-javascript-variable-in-an-activex-webbrowser-from-c-sharp?

                If gotDuration Then
                    trbMedia.Enabled = True
                    trbMedia.Maximum = CInt(duration * 100)
                    If gotCurrentTime Then
                        trbMedia.Value = CInt(currentTime * 100)
                        lblStatus.Text = Math.Round(currentTime) & " / " & Math.Round(duration)
                    Else
                        lblStatus.Text = Math.Round(duration).ToString()
                    End If
                Else
                    lblStatus.Text = ""
                    trbMedia.Enabled = False
                End If
            End If
        Catch
        End Try
    End Sub
End Class