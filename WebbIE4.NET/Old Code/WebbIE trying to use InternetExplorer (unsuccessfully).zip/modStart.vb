Option Strict On
Option Explicit On
Module modStart

End Module