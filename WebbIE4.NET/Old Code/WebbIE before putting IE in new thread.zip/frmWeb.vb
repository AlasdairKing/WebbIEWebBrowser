﻿Public Class frmWeb

    '1 For suppressing JavaScript errors. See http://support.microsoft.com/?kbid=279535 and detecting page navigation.
    '2 For detecting the end of navigation.
    Private WithEvents mObjDoc As mshtml.HTMLDocument
    Private WithEvents mObjWind As mshtml.HTMLWindow2
    Private mObjEvent As mshtml.CEventObj

    ''' <summary>
    ''' Used to work out if a key is pressed or not.
    ''' </summary>
    ''' <param name="vKey"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    <System.Runtime.InteropServices.DllImport("user32.dll", CharSet:=System.Runtime.InteropServices.CharSet.Auto, CallingConvention:=System.Runtime.InteropServices.CallingConvention.StdCall)> _
    Private Shared Function GetKeyState(ByVal vKey As Integer) As Short
    End Function
    Private Const VK_Escape As Long = &H1B ' 27

    Private mFallbackToDocumentComplete As Boolean = False ' If set, then when webMain fires DocumentComplete, process
    '   the page. It's better to rely on mObjEvent, but that fails sometimes - I don't know why, and it might
    '   be an artifact of running in the debugger.

    Private Sub webMain_StatusTextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles webMain.StatusTextChanged
        Try
            frmMain.staMain.Items.Item(1).Text = CType(eventSender, WebBrowser).StatusText
        Catch
            frmMain.staMain.Items.Item(1).Text = ""
        End Try
    End Sub

    Private Sub webMain_DocumentTitleChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles webMain.DocumentTitleChanged
        Dim title As String
        Try
            title = CType(eventSender, WebBrowser).DocumentTitle
            title = "WebbIE - " & title.Replace(vbNewLine, " ")
        Catch
            title = "WebbIE"
        End Try

        Try
            frmMain.Text = title
            Me.Text = title
        Catch
        End Try
    End Sub

    Private Sub webMain_CanGoBackChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles webMain.CanGoBackChanged
        Try
            frmMain.btnBack.Enabled = webMain.CanGoBack
            frmMain.mnuNavigateBack.Enabled = webMain.CanGoBack
        Catch
        End Try
    End Sub

    ''' <summary>
    ''' This function tries to identify when a navigation starts and capture the necessary references
    ''' so that I tell get when the Javascript onLoad event fires, not just when the WebBrowser
    ''' object finishes navigating. This allows for better Javascript support.
    ''' If something goes wrong then set mFallbackToDocumentComplete to true and get out.
    ''' </summary>
    ''' <param name="eventSender"></param>
    ''' <param name="eventArgs"></param>
    ''' <remarks></remarks>
    Private Sub webMain_Navigated(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.WebBrowserNavigatedEventArgs) Handles webMain.Navigated

        Try
            mObjDoc = CType(webMain.Document.DomDocument, mshtml.HTMLDocument)
        Catch
            mFallbackToDocumentComplete = True
            Exit Sub
        End Try
        'Debug.Print("READYSTATE: " & webMain.ReadyState) Checking readystate doesn't seem to help with the
        'error below. It doesn't matter if you try webMain.ReadyState or mObjDoc.readystate, they only return
        '4 or "loading" in any case. So not much use. Although I haven't tried this out when there is a 
        'valid online webpage that DOESN'T throw the error, so that might be worth checking out.
        Try
            mObjWind = CType(mObjDoc.parentWindow, mshtml.HTMLWindow2)
            'OK, that worked, we'll use it to detect end of navigation.
            Debug.Print("Success in webMain_Navigated. 101. " & mObjDoc.GetType.ToString)
            'No need to fall back. 
            mFallbackToDocumentComplete = False
#If DEBUG Then
            Dim ts As System.IO.StreamWriter = New System.IO.StreamWriter(Environment.CurrentDirectory & "\error.txt", True, System.Text.Encoding.UTF8)
            Call ts.WriteLine("100 OK to COM navigate: " & webMain.Document.Url.ToString() & " " & mObjDoc.GetType.ToString)
            Call ts.Close()
#End If
        Catch comEx As System.Runtime.InteropServices.COMException
            'Failed to navigate via COM events. We could use DocumentComplete and timer. 
            'Call MessageBox.Show("Error!!! " & webMain.Url.ToString)
            Debug.Print("Exception: 10000001 modGlobals.gWebHost.webMain_Navigated COMException: " & comEx.Message & " " & mObjDoc.GetType.ToString)
            'However, it appears that if you wait until you get a susequent event, all is well. So just try later.
            'Really? Having some problems with that.  Try falling back to DocumentComplete.
            mFallbackToDocumentComplete = True
#If DEBUG Then
            'Dim ts As System.IO.StreamWriter = New System.IO.StreamWriter(Environment.CurrentDirectory & "\error.txt", True, System.Text.Encoding.UTF8)
            'Call ts.WriteLine("101 NOT OK to COM navigate: " & webMain.Document.Url.ToString())
            'Call ts.Close()
#End If
        End Try
    End Sub

    Private Sub mObjWind_onerror(description As String, url As String, line As Integer) Handles mObjWind.onerror
        'Trap and prevent script errors. See http://support.microsoft.com/?kbid=279535.
        Try
            mObjEvent = CType(mObjWind.event, mshtml.CEventObj)
            mObjEvent.returnValue = True
        Catch ex As Exception
            'Fail silently. This isn't the only mechanism, and I don't have anything useful
            'to tell the user if it fails.
        End Try
    End Sub

    Private Sub mObjWind_onload() Handles mObjWind.onload
        'Call MessageBox.Show("mObjWind_onload")
        mFallbackToDocumentComplete = False ' Clearly we don't need this since this event fired!
        If webMain.Url.ToString <> "http:///" And webMain.Url.ToString <> "" Then
            frmMain.tmrProcessAfterLoad.Enabled = True
            Call System.Diagnostics.Debug.Print("Did mObjWnd_onload")
        Else
            Call System.Diagnostics.Debug.Print("Skipped mObjWnd_onload")
        End If
    End Sub

    ''' <summary>
    ''' This fires when navigation commences, and fires for each frame or page.
    ''' </summary>
    ''' <param name="eventSender"></param>
    ''' <param name="eventArgs"></param>
    ''' <remarks>It does (did) lots of stuff in WebbIE 3, like handling internal links. But this is all buggy and hard, so I'm trying to fix it by simplifying. </remarks>
    Private Sub webMain_Navigating(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.WebBrowserNavigatingEventArgs) Handles webMain.Navigating
        Dim webMainUrl As String
        If Me.webMain.Url Is Nothing Then
            webMainUrl = ""
        Else
            Try
                webMainUrl = webMain.Url.ToString()
            Catch
                webMainUrl = ""
            End Try
        End If
        Dim eventArgsUrl As String
        If eventArgs.Url Is Nothing Then
            eventArgsUrl = ""
        Else
            Try
                eventArgsUrl = eventArgs.Url.ToString()
            Catch
                eventArgsUrl = ""
            End Try
        End If

        Try
            'New navigation, don't fall back. (Not sure of the logic here: maybe I should check that the navigating item is, in fact,
            'the webBrowser and not a frame?)
            mFallbackToDocumentComplete = False
            If eventArgsUrl.Contains("websearch_89789798") Then
                'Open websearch.
                eventArgs.Cancel = True
                Call frmMain.DoWebSearch()
            ElseIf eventArgsUrl.Contains("goto_89789798") Then
                'Go to address bar.
                eventArgs.Cancel = True
                Call frmMain.DoGotoAddressbar()
            ElseIf eventArgsUrl.StartsWith("https") And Not webMainUrl.StartsWith("https") Then
                'Don't handle!
                Call System.Diagnostics.Debug.Print("Don't handle https in http pages")
            ElseIf eventArgsUrl.ToUpperInvariant().StartsWith("JAVASCRIPT:") Then
                'Don't handle! You get these, for example, in www.youtube.com (23 Feb 2014)
                Call System.Diagnostics.Debug.Print("Don't handle Javascript URLs")
            ElseIf eventArgsUrl.ToUpperInvariant().StartsWith("ABOUT:BLANK") Then
                'Don't handle. You get these, for example, in www.google.co.uk when you hit the "screenreader users,
                'turn off instant" link. 23 Feb 2014.
            Else
                'Note that a page action HAS been triggered.
                gNoPageActionSoRefresh = False
                'Now reset the "we're only showing forms" mode
                gShowFormsOnly = False

                'Dev: you'll see at this point that I tried to be clever and use pDisp as the navigating object
                'to catch navigation. This led, eventually, to an enormous memory leak and a pretty non-functional
                'WebbIE. So fall back to relying on ReadyState, and worry about it breaking another time.

                frmMain.btnStop.Enabled = True 'enable toolbar buttons
                frmMain.tmrBusyAnimation.Enabled = True 'start animation
                frmMain.staMain.Items.Item(0).Text = modI18N.GetText("Downloading")
                frmMain.mnuFavoritesAdd.Enabled = True 'enable adding a bookmark option
                Call frmMain.AddURLToRecent()
                frmMain.mnuLinksViewlinks.Enabled = False 'allow the links to be viewed in a separate form
                'Reset one-time "Must navigate" flag. 3.7.4
                gForceNavigation = False
                Call System.Diagnostics.Debug.Print("Started Navigating:" & eventArgs.Url.ToString())
            End If
        Catch

        End Try
    End Sub

    Private Sub webMain_NewWindow(ByVal eventSender As System.Object, ByVal eventArgs As System.ComponentModel.CancelEventArgs) Handles webMain.NewWindow
        Try
            'This is intended to ask the user if they want to allow a pop-up Window.  However, pop-up
            'windows are almost certainly advertisements.  So, there is a user setting "mnuAllowpopups",
            'which defaults to unchecked.  If this is the case, a pop-up window will be suppressed.
            'If it is true, then a popup is allowed but the user is asked to okay it.
            'See http://support.microsoft.com/kb/q184876/ for more information.
            If My.Settings.AllowPopupWindows Then
                ''        'Let's do a new frmMain and pass this to it. Again, see http://support.microsoft.com/kb/184876.
                ''        'Set frmNew = New frmMain
                ''        'frmNew.Visible = True
                ''        'frmNew.modGlobals.gWebHost.webMain.RegisterAsBrowser = True
                ''        'Set ppDisp = frmNew.modGlobals.gWebHost.webMain.object
                'This is a lovely idea, but WebbIE is completely not designed for multiple windows. Each window
                'uses the same array of links etc. So different windows are actually representing the same page.
                'Lots of work to make pop-ups work properly.
                'Better idea: just shell WebbIE with url. May 2007
                'Call Shell(App.Path & "\" & App.EXEName & " " & ppDisp.LocationURL, vbNormalFocus)
                'Ah, this is also a great idea. But you can't get the location url from the ppDisp object because
                'it is Nothing when this event is called.
                'So just let the popup happen. 3.12.2.
            Else
                'popups are not permitted by the user settings
                Call PlayErrorSound()
                'Call MessageBox.Show(modGlobals.gWebHost.webMain.Url.ToString)
                frmMain.staMain.Items.Item(1).Text = modI18N.GetText("Pop-up window blocked")
                eventArgs.Cancel = True
            End If
        Catch
        End Try
    End Sub

    Private Sub webMain_DocumentCompleted(ByVal sender As Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles webMain.DocumentCompleted
        Dim url As String
        Try
            url = e.Url.ToString()
        Catch
            url = ""
        End Try
        'replacement for using the change in the status bar to indicate download status...!

        Try
            'I'm so bored of handling the odd behaviour of WebBrowser. This allows me to use the IDE more effectively.
            If String.Compare(url, "http:///") = 0 Then
                Exit Sub
            End If

            If mFallbackToDocumentComplete And webMain.ReadyState = WebBrowserReadyState.Complete Then
                System.Diagnostics.Debug.Print("Doing DocumentCompleted fallback")
                If webMain.Url Is e.Url Then
                    mFallbackToDocumentComplete = False ' Done
                    frmMain.tmrProcessAfterLoad.Enabled = True
                End If
            End If
        Catch
        End Try

    End Sub

    Private Sub webMain_CanGoForwardChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles webMain.CanGoForwardChanged
        On Error Resume Next
        frmMain.mnuNavigateForward.Enabled = webMain.CanGoForward
    End Sub

    Private Sub frmWeb_Activated(sender As Object, e As System.EventArgs) Handles Me.Activated
        If modGlobals.gShowingWebpage Then
            'OK, user requested this.
        Else
            'Happens on www.YouTube.com!
            modGlobals.gFrmWebHasFocusAndItShouldNot = True
            frmMain.tmrSetFocus.Enabled = True
        End If
    End Sub

    Private Sub frmWeb_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        On Error Resume Next
        webMain.ScriptErrorsSuppressed = True ' in case we create a new instance
        '   and forget to set it in the IDE!
    End Sub

    Public Sub New()
        Try
            Call WebBrowserUtility.SetWebBrowserEmulation()
        Catch
        End Try
        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
    End Sub

    Private Sub btnCancel_Click(sender As System.Object, e As System.EventArgs) Handles btnCancel.Click
        Try
            Call SwitchBackToMain()
        Catch
        End Try
    End Sub

    Private Sub frmWeb_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            If e.CloseReason = CloseReason.UserClosing Then
                e.Cancel = True
                Call SwitchBackToMain()
            End If
        Catch
        End Try
    End Sub

    Private Sub SwitchBackToMain()
        Try
            Call Me.Hide()
            Call frmMain.RefreshCurrentPage()
            frmMain.Visible = True
            modGlobals.gShowingWebpage = False
        Catch
        End Try
    End Sub

    ''' <summary>
    ''' This is a fall-back because some web pages - e.g. YouTube, so probably pages with Flash - will
    ''' grab the key input and won't let the form get the keypress. So use the Windows API to check for
    ''' the key and close the window if Escape is pressed.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub tmrCheckForEscape_Tick(sender As System.Object, e As System.EventArgs) Handles tmrCheckForEscape.Tick
        Try
            If Me.Visible Then
                If GetKeyState(VK_Escape) < 0 Then
                    Call SwitchBackToMain()
                End If
            End If
        Catch
        End Try
    End Sub
End Class