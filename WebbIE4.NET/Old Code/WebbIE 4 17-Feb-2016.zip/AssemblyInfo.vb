Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.


' TODO: Review the values of the assembly attributes


<Assembly: AssemblyTitle("WebbIE 4")> 
<Assembly: AssemblyDescription("Web Browser")> 
<Assembly: AssemblyCompany("Accessible and WebbIE")> 
<Assembly: AssemblyProduct("WebbIE")> 
<Assembly: AssemblyCopyright("(c) Alasdair King, 2012")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly: AssemblyVersion("4.5.0.0")> 



<Assembly: ComVisibleAttribute(False)> 
<Assembly: AssemblyFileVersionAttribute("4.5.0.0")> 
<Assembly: GuidAttribute("4C9A2956-7A48-40f3-B892-422887FE0B58")> 