Option Strict Off
Option Explicit On
Friend Class frmFindThunder
	Inherits System.Windows.Forms.Form
	
	Private Sub tmrThunder_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrThunder.Tick
		On Error Resume Next
		Dim hWnd As Integer
		
		If gExiting Then
			tmrThunder.Enabled = False
		Else
			hWnd = FindWindow(vbNullString, "Thunder")
			If hWnd = 0 Then hWnd = FindWindow(vbNullString, "Microsoft Narrator")
			If hWnd <> 0 Then
				gGotThunder = True
			End If
		End If
		'Debug.Print "gGotThunder: " & gGotThunder
	End Sub
End Class