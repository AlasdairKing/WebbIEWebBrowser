<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmMain
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
    Public WithEvents tmrDoUpDownKeys As System.Windows.Forms.Timer
	Public WithEvents tmrRefreshIfNotChange As System.Windows.Forms.Timer
    Public WithEvents workBrowser As System.Windows.Forms.WebBrowser
    Public WithEvents tmrSetFocus As System.Windows.Forms.Timer
	Public WithEvents tmrProcessAfterLoad As System.Windows.Forms.Timer
	Public WithEvents tmrStartNavigating As System.Windows.Forms.Timer
    Public WithEvents tmrAjax As System.Windows.Forms.Timer
    Public cdlgOpen As System.Windows.Forms.OpenFileDialog
	Public WithEvents tmrBusyAnimation As System.Windows.Forms.Timer
	Public WithEvents _staMain_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _staMain_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _staMain_Panel3 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents staMain As System.Windows.Forms.StatusStrip
	Public WithEvents tmrConnectionPoller As System.Windows.Forms.Timer
    Public WithEvents lblText As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.cboAddress = New System.Windows.Forms.ComboBox()
        Me.tmrDoUpDownKeys = New System.Windows.Forms.Timer(Me.components)
        Me.tmrRefreshIfNotChange = New System.Windows.Forms.Timer(Me.components)
        Me.workBrowser = New System.Windows.Forms.WebBrowser()
        Me.tmrSetFocus = New System.Windows.Forms.Timer(Me.components)
        Me.tmrProcessAfterLoad = New System.Windows.Forms.Timer(Me.components)
        Me.tmrStartNavigating = New System.Windows.Forms.Timer(Me.components)
        Me.tmrAjax = New System.Windows.Forms.Timer(Me.components)
        Me.cdlgOpen = New System.Windows.Forms.OpenFileDialog()
        Me.tmrBusyAnimation = New System.Windows.Forms.Timer(Me.components)
        Me.staMain = New System.Windows.Forms.StatusStrip()
        Me._staMain_Panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me._staMain_Panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me._staMain_Panel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.tmrConnectionPoller = New System.Windows.Forms.Timer(Me.components)
        Me.lblText = New System.Windows.Forms.Label()
        Me.fraNavigationBar = New System.Windows.Forms.Panel()
        Me.fraToolBar = New System.Windows.Forms.Panel()
        Me.cmdShrink = New System.Windows.Forms.Button()
        Me.cmdHeading = New System.Windows.Forms.Button()
        Me.cmdMagnify = New System.Windows.Forms.Button()
        Me.cmdSkiplinks = New System.Windows.Forms.Button()
        Me.cmdViewIE = New System.Windows.Forms.Button()
        Me.cmdHome = New System.Windows.Forms.Button()
        Me.cmdRefresh = New System.Windows.Forms.Button()
        Me.cmdStop = New System.Windows.Forms.Button()
        Me.cmdForward = New System.Windows.Forms.Button()
        Me.cmdBack = New System.Windows.Forms.Button()
        Me.fraBusy = New System.Windows.Forms.Panel()
        Me.picBusy = New System.Windows.Forms.PictureBox()
        Me.fraMain = New System.Windows.Forms.Panel()
        Me.fraText = New System.Windows.Forms.Panel()
        Me.fraContent = New System.Windows.Forms.Panel()
        Me.txtText = New System.Windows.Forms.TextBox()
        Me.webMain = New System.Windows.Forms.WebBrowser()
        Me.fraAddress = New System.Windows.Forms.Panel()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.tmrFocusMonitor = New System.Windows.Forms.Timer(Me.components)
        Me.mnuBar = New System.Windows.Forms.ToolStripSeparator()
        Me.MenuStripMain = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFilePrint = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditCopy = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditCut = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditPaste = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditSelectall = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditFind = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditFindNext = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuEditWebsearch = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuView = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewIE = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewCroppage = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewRSSNewsFeed = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewMagnify = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewShrink = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuViewSource = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFavorites = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFavoritesAdd = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFavoritesGotofavorites = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFavoritesOrganise = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNavigate = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNavigateBack = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNavigateStop = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNavigateHome = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNavigateRefresh = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNavigateForward = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNavigateGotoheadline = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuNavigateGotoform = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinks = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinksNextlink = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinksPreviouslink = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinksSkipDown = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinksSkipup = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinksViewlinks = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinksDownloadlinktarget = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuLinksFollowlinkaddress = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptions = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsFont = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsInvert = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsLanguage = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsMakeWebbIEDefault = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsOptions = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuOptionsSetHomepage = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpManual = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpWebbIEOrg = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpAbout = New System.Windows.Forms.ToolStripMenuItem()
        Me.staMain.SuspendLayout()
        Me.fraNavigationBar.SuspendLayout()
        Me.fraToolBar.SuspendLayout()
        Me.fraBusy.SuspendLayout()
        CType(Me.picBusy, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.fraMain.SuspendLayout()
        Me.fraText.SuspendLayout()
        Me.fraContent.SuspendLayout()
        Me.fraAddress.SuspendLayout()
        Me.MenuStripMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboAddress
        '
        Me.cboAddress.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cboAddress.BackColor = System.Drawing.SystemColors.Window
        Me.cboAddress.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboAddress.Font = New System.Drawing.Font("Arial", 13.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(186, Byte))
        Me.cboAddress.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboAddress.Location = New System.Drawing.Point(75, 1)
        Me.cboAddress.Name = "cboAddress"
        Me.cboAddress.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboAddress.Size = New System.Drawing.Size(802, 29)
        Me.cboAddress.TabIndex = 2
        Me.cboAddress.Tag = "frmMain.cboAddress"
        '
        'tmrDoUpDownKeys
        '
        Me.tmrDoUpDownKeys.Interval = 51
        '
        'tmrRefreshIfNotChange
        '
        Me.tmrRefreshIfNotChange.Interval = 2000
        '
        'workBrowser
        '
        Me.workBrowser.Location = New System.Drawing.Point(232, 216)
        Me.workBrowser.Name = "workBrowser"
        Me.workBrowser.ScriptErrorsSuppressed = True
        Me.workBrowser.Size = New System.Drawing.Size(297, 153)
        Me.workBrowser.TabIndex = 27
        '
        'tmrSetFocus
        '
        Me.tmrSetFocus.Interval = 50
        '
        'tmrProcessAfterLoad
        '
        Me.tmrProcessAfterLoad.Interval = 250
        '
        'tmrStartNavigating
        '
        Me.tmrStartNavigating.Interval = 55
        '
        'tmrAjax
        '
        Me.tmrAjax.Enabled = True
        Me.tmrAjax.Interval = 3000
        '
        'tmrBusyAnimation
        '
        Me.tmrBusyAnimation.Interval = 300
        '
        'staMain
        '
        Me.staMain.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.staMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._staMain_Panel1, Me._staMain_Panel2, Me._staMain_Panel3})
        Me.staMain.Location = New System.Drawing.Point(0, 530)
        Me.staMain.Name = "staMain"
        Me.staMain.Size = New System.Drawing.Size(880, 27)
        Me.staMain.TabIndex = 2
        Me.staMain.Tag = "frmMain.staMain"
        '
        '_staMain_Panel1
        '
        Me._staMain_Panel1.AutoSize = False
        Me._staMain_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._staMain_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._staMain_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._staMain_Panel1.Name = "_staMain_Panel1"
        Me._staMain_Panel1.Size = New System.Drawing.Size(87, 27)
        Me._staMain_Panel1.Tag = "frmMain.staMain.txtBusy"
        Me._staMain_Panel1.Text = "Idle"
        Me._staMain_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me._staMain_Panel1.ToolTipText = " What WebbIE is doing "
        '
        '_staMain_Panel2
        '
        Me._staMain_Panel2.AutoSize = False
        Me._staMain_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._staMain_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._staMain_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._staMain_Panel2.Name = "_staMain_Panel2"
        Me._staMain_Panel2.Size = New System.Drawing.Size(691, 27)
        Me._staMain_Panel2.Spring = True
        Me._staMain_Panel2.Tag = "frmMain.staMain.txtTitle"
        Me._staMain_Panel2.Text = "Blank"
        Me._staMain_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me._staMain_Panel2.ToolTipText = " Title of this web page "
        '
        '_staMain_Panel3
        '
        Me._staMain_Panel3.AutoSize = False
        Me._staMain_Panel3.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._staMain_Panel3.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._staMain_Panel3.Margin = New System.Windows.Forms.Padding(0)
        Me._staMain_Panel3.Name = "_staMain_Panel3"
        Me._staMain_Panel3.Size = New System.Drawing.Size(87, 27)
        Me._staMain_Panel3.Tag = "frmMain.staMain.txtConnection"
        Me._staMain_Panel3.Text = "Disconnected"
        Me._staMain_Panel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me._staMain_Panel3.ToolTipText = " Whether your are online or offline "
        '
        'tmrConnectionPoller
        '
        Me.tmrConnectionPoller.Enabled = True
        Me.tmrConnectionPoller.Interval = 1000
        '
        'lblText
        '
        Me.lblText.AutoSize = True
        Me.lblText.BackColor = System.Drawing.SystemColors.Control
        Me.lblText.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblText.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblText.Location = New System.Drawing.Point(328, 264)
        Me.lblText.Name = "lblText"
        Me.lblText.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblText.Size = New System.Drawing.Size(33, 16)
        Me.lblText.TabIndex = 17
        Me.lblText.Tag = "frmMain.lblText"
        Me.lblText.Text = "&Text"
        '
        'fraNavigationBar
        '
        Me.fraNavigationBar.Controls.Add(Me.fraToolBar)
        Me.fraNavigationBar.Controls.Add(Me.fraBusy)
        Me.fraNavigationBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.fraNavigationBar.Location = New System.Drawing.Point(0, 0)
        Me.fraNavigationBar.Name = "fraNavigationBar"
        Me.fraNavigationBar.Size = New System.Drawing.Size(880, 80)
        Me.fraNavigationBar.TabIndex = 33
        '
        'fraToolBar
        '
        Me.fraToolBar.BackColor = System.Drawing.SystemColors.Control
        Me.fraToolBar.Controls.Add(Me.cmdShrink)
        Me.fraToolBar.Controls.Add(Me.cmdHeading)
        Me.fraToolBar.Controls.Add(Me.cmdMagnify)
        Me.fraToolBar.Controls.Add(Me.cmdSkiplinks)
        Me.fraToolBar.Controls.Add(Me.cmdViewIE)
        Me.fraToolBar.Controls.Add(Me.cmdHome)
        Me.fraToolBar.Controls.Add(Me.cmdRefresh)
        Me.fraToolBar.Controls.Add(Me.cmdStop)
        Me.fraToolBar.Controls.Add(Me.cmdForward)
        Me.fraToolBar.Controls.Add(Me.cmdBack)
        Me.fraToolBar.Cursor = System.Windows.Forms.Cursors.Default
        Me.fraToolBar.Dock = System.Windows.Forms.DockStyle.Left
        Me.fraToolBar.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraToolBar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraToolBar.Location = New System.Drawing.Point(0, 0)
        Me.fraToolBar.Name = "fraToolBar"
        Me.fraToolBar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraToolBar.Size = New System.Drawing.Size(785, 80)
        Me.fraToolBar.TabIndex = 17
        '
        'cmdShrink
        '
        Me.cmdShrink.BackColor = System.Drawing.SystemColors.Control
        Me.cmdShrink.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdShrink.Enabled = False
        Me.cmdShrink.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdShrink.Image = CType(resources.GetObject("cmdShrink.Image"), System.Drawing.Image)
        Me.cmdShrink.Location = New System.Drawing.Point(688, 0)
        Me.cmdShrink.Name = "cmdShrink"
        Me.cmdShrink.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdShrink.Size = New System.Drawing.Size(97, 81)
        Me.cmdShrink.TabIndex = 30
        Me.cmdShrink.TabStop = False
        Me.cmdShrink.Tag = "frmMain.cmdMagnify"
        Me.cmdShrink.Text = "Shrink"
        Me.cmdShrink.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdShrink.UseVisualStyleBackColor = False
        '
        'cmdHeading
        '
        Me.cmdHeading.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHeading.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHeading.Enabled = False
        Me.cmdHeading.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHeading.Image = CType(resources.GetObject("cmdHeading.Image"), System.Drawing.Image)
        Me.cmdHeading.Location = New System.Drawing.Point(688, 0)
        Me.cmdHeading.Name = "cmdHeading"
        Me.cmdHeading.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHeading.Size = New System.Drawing.Size(97, 81)
        Me.cmdHeading.TabIndex = 29
        Me.cmdHeading.TabStop = False
        Me.cmdHeading.Tag = "frmMain.cmdMagnify"
        Me.cmdHeading.Text = "Heading"
        Me.cmdHeading.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdHeading.UseVisualStyleBackColor = False
        '
        'cmdMagnify
        '
        Me.cmdMagnify.BackColor = System.Drawing.SystemColors.Control
        Me.cmdMagnify.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdMagnify.Enabled = False
        Me.cmdMagnify.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdMagnify.Image = CType(resources.GetObject("cmdMagnify.Image"), System.Drawing.Image)
        Me.cmdMagnify.Location = New System.Drawing.Point(592, 0)
        Me.cmdMagnify.Name = "cmdMagnify"
        Me.cmdMagnify.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdMagnify.Size = New System.Drawing.Size(97, 81)
        Me.cmdMagnify.TabIndex = 9
        Me.cmdMagnify.TabStop = False
        Me.cmdMagnify.Tag = "frmMain.cmdMagnify"
        Me.cmdMagnify.Text = "Magnify"
        Me.cmdMagnify.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdMagnify.UseVisualStyleBackColor = False
        '
        'cmdSkiplinks
        '
        Me.cmdSkiplinks.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSkiplinks.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSkiplinks.Enabled = False
        Me.cmdSkiplinks.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSkiplinks.Image = CType(resources.GetObject("cmdSkiplinks.Image"), System.Drawing.Image)
        Me.cmdSkiplinks.Location = New System.Drawing.Point(592, 0)
        Me.cmdSkiplinks.Name = "cmdSkiplinks"
        Me.cmdSkiplinks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSkiplinks.Size = New System.Drawing.Size(97, 81)
        Me.cmdSkiplinks.TabIndex = 10
        Me.cmdSkiplinks.TabStop = False
        Me.cmdSkiplinks.Tag = "frmMain.cmdSkiplinks"
        Me.cmdSkiplinks.Text = "Skip links"
        Me.cmdSkiplinks.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdSkiplinks.UseVisualStyleBackColor = False
        '
        'cmdViewIE
        '
        Me.cmdViewIE.BackColor = System.Drawing.SystemColors.Control
        Me.cmdViewIE.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdViewIE.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdViewIE.Image = CType(resources.GetObject("cmdViewIE.Image"), System.Drawing.Image)
        Me.cmdViewIE.Location = New System.Drawing.Point(496, 0)
        Me.cmdViewIE.Name = "cmdViewIE"
        Me.cmdViewIE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdViewIE.Size = New System.Drawing.Size(97, 81)
        Me.cmdViewIE.TabIndex = 8
        Me.cmdViewIE.TabStop = False
        Me.cmdViewIE.Tag = "frmMain.cmdViewIE"
        Me.cmdViewIE.Text = "View web"
        Me.cmdViewIE.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdViewIE.UseVisualStyleBackColor = False
        '
        'cmdHome
        '
        Me.cmdHome.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHome.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHome.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHome.Image = CType(resources.GetObject("cmdHome.Image"), System.Drawing.Image)
        Me.cmdHome.Location = New System.Drawing.Point(400, 0)
        Me.cmdHome.Name = "cmdHome"
        Me.cmdHome.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHome.Size = New System.Drawing.Size(97, 81)
        Me.cmdHome.TabIndex = 7
        Me.cmdHome.TabStop = False
        Me.cmdHome.Tag = "frmMain.cmdHome"
        Me.cmdHome.Text = "Home"
        Me.cmdHome.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdHome.UseVisualStyleBackColor = False
        '
        'cmdRefresh
        '
        Me.cmdRefresh.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRefresh.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRefresh.Enabled = False
        Me.cmdRefresh.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRefresh.Image = CType(resources.GetObject("cmdRefresh.Image"), System.Drawing.Image)
        Me.cmdRefresh.Location = New System.Drawing.Point(296, 0)
        Me.cmdRefresh.Name = "cmdRefresh"
        Me.cmdRefresh.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRefresh.Size = New System.Drawing.Size(97, 81)
        Me.cmdRefresh.TabIndex = 6
        Me.cmdRefresh.TabStop = False
        Me.cmdRefresh.Tag = "frmMain.cmdRefresh"
        Me.cmdRefresh.Text = "Refresh"
        Me.cmdRefresh.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdRefresh.UseVisualStyleBackColor = False
        '
        'cmdStop
        '
        Me.cmdStop.BackColor = System.Drawing.SystemColors.Control
        Me.cmdStop.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdStop.Enabled = False
        Me.cmdStop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdStop.Image = CType(resources.GetObject("cmdStop.Image"), System.Drawing.Image)
        Me.cmdStop.Location = New System.Drawing.Point(200, 0)
        Me.cmdStop.Name = "cmdStop"
        Me.cmdStop.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdStop.Size = New System.Drawing.Size(97, 81)
        Me.cmdStop.TabIndex = 5
        Me.cmdStop.TabStop = False
        Me.cmdStop.Tag = "frmMain.cmdStop"
        Me.cmdStop.Text = "Stop"
        Me.cmdStop.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdStop.UseVisualStyleBackColor = False
        '
        'cmdForward
        '
        Me.cmdForward.BackColor = System.Drawing.SystemColors.Control
        Me.cmdForward.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdForward.Enabled = False
        Me.cmdForward.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdForward.Image = CType(resources.GetObject("cmdForward.Image"), System.Drawing.Image)
        Me.cmdForward.Location = New System.Drawing.Point(96, 0)
        Me.cmdForward.Name = "cmdForward"
        Me.cmdForward.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdForward.Size = New System.Drawing.Size(97, 81)
        Me.cmdForward.TabIndex = 4
        Me.cmdForward.TabStop = False
        Me.cmdForward.Tag = "frmMain.cmdForward"
        Me.cmdForward.Text = "Forward"
        Me.cmdForward.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdForward.UseVisualStyleBackColor = False
        '
        'cmdBack
        '
        Me.cmdBack.BackColor = System.Drawing.SystemColors.Control
        Me.cmdBack.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBack.Enabled = False
        Me.cmdBack.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdBack.Image = CType(resources.GetObject("cmdBack.Image"), System.Drawing.Image)
        Me.cmdBack.Location = New System.Drawing.Point(0, 0)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBack.Size = New System.Drawing.Size(97, 81)
        Me.cmdBack.TabIndex = 3
        Me.cmdBack.TabStop = False
        Me.cmdBack.Tag = "frmMain.cmdBack"
        Me.cmdBack.Text = "Back"
        Me.cmdBack.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdBack.UseVisualStyleBackColor = False
        '
        'fraBusy
        '
        Me.fraBusy.BackColor = System.Drawing.SystemColors.Control
        Me.fraBusy.Controls.Add(Me.picBusy)
        Me.fraBusy.Cursor = System.Windows.Forms.Cursors.Default
        Me.fraBusy.Dock = System.Windows.Forms.DockStyle.Right
        Me.fraBusy.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraBusy.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraBusy.Location = New System.Drawing.Point(785, 0)
        Me.fraBusy.Name = "fraBusy"
        Me.fraBusy.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraBusy.Size = New System.Drawing.Size(95, 80)
        Me.fraBusy.TabIndex = 18
        '
        'picBusy
        '
        Me.picBusy.Image = CType(resources.GetObject("picBusy.Image"), System.Drawing.Image)
        Me.picBusy.Location = New System.Drawing.Point(0, 0)
        Me.picBusy.Name = "picBusy"
        Me.picBusy.Size = New System.Drawing.Size(81, 81)
        Me.picBusy.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picBusy.TabIndex = 5
        Me.picBusy.TabStop = False
        '
        'fraMain
        '
        Me.fraMain.Controls.Add(Me.fraText)
        Me.fraMain.Controls.Add(Me.fraNavigationBar)
        Me.fraMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.fraMain.Location = New System.Drawing.Point(0, 24)
        Me.fraMain.Name = "fraMain"
        Me.fraMain.Size = New System.Drawing.Size(880, 506)
        Me.fraMain.TabIndex = 34
        '
        'fraText
        '
        Me.fraText.Controls.Add(Me.fraContent)
        Me.fraText.Controls.Add(Me.fraAddress)
        Me.fraText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.fraText.Location = New System.Drawing.Point(0, 80)
        Me.fraText.Name = "fraText"
        Me.fraText.Size = New System.Drawing.Size(880, 426)
        Me.fraText.TabIndex = 1
        '
        'fraContent
        '
        Me.fraContent.Controls.Add(Me.txtText)
        Me.fraContent.Controls.Add(Me.webMain)
        Me.fraContent.Dock = System.Windows.Forms.DockStyle.Fill
        Me.fraContent.Location = New System.Drawing.Point(0, 32)
        Me.fraContent.Name = "fraContent"
        Me.fraContent.Size = New System.Drawing.Size(880, 394)
        Me.fraContent.TabIndex = 34
        '
        'txtText
        '
        Me.txtText.AcceptsReturn = True
        Me.txtText.BackColor = System.Drawing.SystemColors.Window
        Me.txtText.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtText.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtText.Location = New System.Drawing.Point(0, 0)
        Me.txtText.MaxLength = 0
        Me.txtText.Multiline = True
        Me.txtText.Name = "txtText"
        Me.txtText.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtText.Size = New System.Drawing.Size(880, 394)
        Me.txtText.TabIndex = 32
        '
        'webMain
        '
        Me.webMain.Location = New System.Drawing.Point(0, 0)
        Me.webMain.Name = "webMain"
        Me.webMain.Size = New System.Drawing.Size(5, 5)
        Me.webMain.TabIndex = 33
        '
        'fraAddress
        '
        Me.fraAddress.Controls.Add(Me.lblAddress)
        Me.fraAddress.Controls.Add(Me.cboAddress)
        Me.fraAddress.Dock = System.Windows.Forms.DockStyle.Top
        Me.fraAddress.Location = New System.Drawing.Point(0, 0)
        Me.fraAddress.Name = "fraAddress"
        Me.fraAddress.Size = New System.Drawing.Size(880, 32)
        Me.fraAddress.TabIndex = 0
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.BackColor = System.Drawing.SystemColors.Control
        Me.lblAddress.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblAddress.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblAddress.Location = New System.Drawing.Point(3, 4)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblAddress.Size = New System.Drawing.Size(66, 19)
        Me.lblAddress.TabIndex = 6
        Me.lblAddress.Tag = "frmMain.lblAddress"
        Me.lblAddress.Text = "A&ddress"
        '
        'tmrFocusMonitor
        '
        Me.tmrFocusMonitor.Enabled = True
        Me.tmrFocusMonitor.Interval = 987
        '
        'mnuBar
        '
        Me.mnuBar.Name = "mnuBar"
        Me.mnuBar.Size = New System.Drawing.Size(166, 6)
        '
        'MenuStripMain
        '
        Me.MenuStripMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.mnuView, Me.mnuFavorites, Me.mnuNavigate, Me.mnuLinks, Me.mnuOptions, Me.mnuHelp})
        Me.MenuStripMain.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripMain.Name = "MenuStripMain"
        Me.MenuStripMain.Size = New System.Drawing.Size(880, 24)
        Me.MenuStripMain.TabIndex = 0
        Me.MenuStripMain.Text = "MenuStripMain"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileOpen, Me.mnuFileSave, Me.mnuFilePrint, Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "&File"
        '
        'mnuFileOpen
        '
        Me.mnuFileOpen.Name = "mnuFileOpen"
        Me.mnuFileOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mnuFileOpen.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileOpen.Text = "&Open"
        '
        'mnuFileSave
        '
        Me.mnuFileSave.Name = "mnuFileSave"
        Me.mnuFileSave.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mnuFileSave.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileSave.Text = "&Save"
        '
        'mnuFilePrint
        '
        Me.mnuFilePrint.Name = "mnuFilePrint"
        Me.mnuFilePrint.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.mnuFilePrint.Size = New System.Drawing.Size(146, 22)
        Me.mnuFilePrint.Text = "&Print"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileExit.Text = "E&xit"
        '
        'mnuEdit
        '
        Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuEditCopy, Me.mnuEditCut, Me.mnuEditPaste, Me.mnuEditSelectall, Me.mnuEditFind, Me.mnuEditFindNext, Me.mnuEditWebsearch})
        Me.mnuEdit.Name = "mnuEdit"
        Me.mnuEdit.Size = New System.Drawing.Size(39, 20)
        Me.mnuEdit.Text = "&Edit"
        '
        'mnuEditCopy
        '
        Me.mnuEditCopy.Name = "mnuEditCopy"
        Me.mnuEditCopy.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnuEditCopy.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditCopy.Text = "&Copy"
        '
        'mnuEditCut
        '
        Me.mnuEditCut.Name = "mnuEditCut"
        Me.mnuEditCut.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuEditCut.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditCut.Text = "C&ut"
        '
        'mnuEditPaste
        '
        Me.mnuEditPaste.Name = "mnuEditPaste"
        Me.mnuEditPaste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.mnuEditPaste.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditPaste.Text = "&Paste"
        '
        'mnuEditSelectall
        '
        Me.mnuEditSelectall.Name = "mnuEditSelectall"
        Me.mnuEditSelectall.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.mnuEditSelectall.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditSelectall.Text = "Select &all"
        '
        'mnuEditFind
        '
        Me.mnuEditFind.Name = "mnuEditFind"
        Me.mnuEditFind.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.mnuEditFind.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditFind.Text = "&Find (on this page)"
        '
        'mnuEditFindNext
        '
        Me.mnuEditFindNext.Name = "mnuEditFindNext"
        Me.mnuEditFindNext.ShortcutKeys = System.Windows.Forms.Keys.F3
        Me.mnuEditFindNext.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditFindNext.Text = "Find &next"
        '
        'mnuEditWebsearch
        '
        Me.mnuEditWebsearch.Name = "mnuEditWebsearch"
        Me.mnuEditWebsearch.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.W), System.Windows.Forms.Keys)
        Me.mnuEditWebsearch.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditWebsearch.Text = "&Websearch"
        '
        'mnuView
        '
        Me.mnuView.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuViewIE, Me.mnuViewCroppage, Me.mnuViewRSSNewsFeed, Me.mnuViewMagnify, Me.mnuViewShrink, Me.mnuViewSource})
        Me.mnuView.Name = "mnuView"
        Me.mnuView.Size = New System.Drawing.Size(44, 20)
        Me.mnuView.Text = "&View"
        '
        'mnuViewIE
        '
        Me.mnuViewIE.Name = "mnuViewIE"
        Me.mnuViewIE.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.mnuViewIE.Size = New System.Drawing.Size(187, 22)
        Me.mnuViewIE.Text = "View &webpage"
        '
        'mnuViewCroppage
        '
        Me.mnuViewCroppage.Name = "mnuViewCroppage"
        Me.mnuViewCroppage.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.K), System.Windows.Forms.Keys)
        Me.mnuViewCroppage.Size = New System.Drawing.Size(187, 22)
        Me.mnuViewCroppage.Text = "&Crop page"
        '
        'mnuViewRSSNewsFeed
        '
        Me.mnuViewRSSNewsFeed.Name = "mnuViewRSSNewsFeed"
        Me.mnuViewRSSNewsFeed.Size = New System.Drawing.Size(187, 22)
        Me.mnuViewRSSNewsFeed.Text = "View &RSS news feed"
        '
        'mnuViewMagnify
        '
        Me.mnuViewMagnify.Name = "mnuViewMagnify"
        Me.mnuViewMagnify.Size = New System.Drawing.Size(187, 22)
        Me.mnuViewMagnify.Text = "&Magnify"
        '
        'mnuViewShrink
        '
        Me.mnuViewShrink.Name = "mnuViewShrink"
        Me.mnuViewShrink.Size = New System.Drawing.Size(187, 22)
        Me.mnuViewShrink.Text = "&Shrink"
        '
        'mnuViewSource
        '
        Me.mnuViewSource.Name = "mnuViewSource"
        Me.mnuViewSource.Size = New System.Drawing.Size(187, 22)
        Me.mnuViewSource.Text = "S&ource"
        '
        'mnuFavorites
        '
        Me.mnuFavorites.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFavoritesAdd, Me.mnuFavoritesGotofavorites, Me.mnuFavoritesOrganise})
        Me.mnuFavorites.Name = "mnuFavorites"
        Me.mnuFavorites.Size = New System.Drawing.Size(66, 20)
        Me.mnuFavorites.Text = "F&avorites"
        '
        'mnuFavoritesAdd
        '
        Me.mnuFavoritesAdd.Name = "mnuFavoritesAdd"
        Me.mnuFavoritesAdd.Size = New System.Drawing.Size(169, 22)
        Me.mnuFavoritesAdd.Text = "&Add to favorites"
        '
        'mnuFavoritesGotofavorites
        '
        Me.mnuFavoritesGotofavorites.Name = "mnuFavoritesGotofavorites"
        Me.mnuFavoritesGotofavorites.Size = New System.Drawing.Size(169, 22)
        Me.mnuFavoritesGotofavorites.Text = "&Goto favorites"
        '
        'mnuFavoritesOrganise
        '
        Me.mnuFavoritesOrganise.Name = "mnuFavoritesOrganise"
        Me.mnuFavoritesOrganise.Size = New System.Drawing.Size(169, 22)
        Me.mnuFavoritesOrganise.Text = "&Organise favorites"
        '
        'mnuNavigate
        '
        Me.mnuNavigate.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuNavigateBack, Me.mnuNavigateStop, Me.mnuNavigateHome, Me.mnuNavigateRefresh, Me.mnuNavigateForward, Me.mnuNavigateGotoheadline, Me.mnuNavigateGotoform})
        Me.mnuNavigate.Name = "mnuNavigate"
        Me.mnuNavigate.Size = New System.Drawing.Size(66, 20)
        Me.mnuNavigate.Text = "&Navigate"
        '
        'mnuNavigateBack
        '
        Me.mnuNavigateBack.Name = "mnuNavigateBack"
        Me.mnuNavigateBack.Size = New System.Drawing.Size(148, 22)
        Me.mnuNavigateBack.Text = "&Back"
        '
        'mnuNavigateStop
        '
        Me.mnuNavigateStop.Name = "mnuNavigateStop"
        Me.mnuNavigateStop.Size = New System.Drawing.Size(148, 22)
        Me.mnuNavigateStop.Text = "&Stop"
        '
        'mnuNavigateHome
        '
        Me.mnuNavigateHome.Name = "mnuNavigateHome"
        Me.mnuNavigateHome.Size = New System.Drawing.Size(148, 22)
        Me.mnuNavigateHome.Text = "&Home"
        '
        'mnuNavigateRefresh
        '
        Me.mnuNavigateRefresh.Name = "mnuNavigateRefresh"
        Me.mnuNavigateRefresh.Size = New System.Drawing.Size(148, 22)
        Me.mnuNavigateRefresh.Text = "&Refresh"
        '
        'mnuNavigateForward
        '
        Me.mnuNavigateForward.Name = "mnuNavigateForward"
        Me.mnuNavigateForward.Size = New System.Drawing.Size(148, 22)
        Me.mnuNavigateForward.Text = "&Forward"
        '
        'mnuNavigateGotoheadline
        '
        Me.mnuNavigateGotoheadline.Name = "mnuNavigateGotoheadline"
        Me.mnuNavigateGotoheadline.Size = New System.Drawing.Size(148, 22)
        Me.mnuNavigateGotoheadline.Text = "Goto &headline"
        '
        'mnuNavigateGotoform
        '
        Me.mnuNavigateGotoform.Name = "mnuNavigateGotoform"
        Me.mnuNavigateGotoform.Size = New System.Drawing.Size(148, 22)
        Me.mnuNavigateGotoform.Text = "Goto &form"
        '
        'mnuLinks
        '
        Me.mnuLinks.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuLinksNextlink, Me.mnuLinksPreviouslink, Me.mnuLinksSkipDown, Me.mnuLinksSkipup, Me.mnuLinksViewlinks, Me.mnuLinksDownloadlinktarget, Me.mnuLinksFollowlinkaddress})
        Me.mnuLinks.Name = "mnuLinks"
        Me.mnuLinks.Size = New System.Drawing.Size(46, 20)
        Me.mnuLinks.Text = "&Links"
        '
        'mnuLinksNextlink
        '
        Me.mnuLinksNextlink.Name = "mnuLinksNextlink"
        Me.mnuLinksNextlink.Size = New System.Drawing.Size(244, 22)
        Me.mnuLinksNextlink.Text = "Next link"
        '
        'mnuLinksPreviouslink
        '
        Me.mnuLinksPreviouslink.Name = "mnuLinksPreviouslink"
        Me.mnuLinksPreviouslink.Size = New System.Drawing.Size(244, 22)
        Me.mnuLinksPreviouslink.Text = "Previous link"
        '
        'mnuLinksSkipDown
        '
        Me.mnuLinksSkipDown.Name = "mnuLinksSkipDown"
        Me.mnuLinksSkipDown.Size = New System.Drawing.Size(244, 22)
        Me.mnuLinksSkipDown.Text = "Skip links down"
        '
        'mnuLinksSkipup
        '
        Me.mnuLinksSkipup.Name = "mnuLinksSkipup"
        Me.mnuLinksSkipup.Size = New System.Drawing.Size(244, 22)
        Me.mnuLinksSkipup.Text = "Skip links up"
        '
        'mnuLinksViewlinks
        '
        Me.mnuLinksViewlinks.Name = "mnuLinksViewlinks"
        Me.mnuLinksViewlinks.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.mnuLinksViewlinks.Size = New System.Drawing.Size(244, 22)
        Me.mnuLinksViewlinks.Text = "View links"
        '
        'mnuLinksDownloadlinktarget
        '
        Me.mnuLinksDownloadlinktarget.Name = "mnuLinksDownloadlinktarget"
        Me.mnuLinksDownloadlinktarget.Size = New System.Drawing.Size(244, 22)
        Me.mnuLinksDownloadlinktarget.Text = "Download link target to Desktop"
        '
        'mnuLinksFollowlinkaddress
        '
        Me.mnuLinksFollowlinkaddress.Name = "mnuLinksFollowlinkaddress"
        Me.mnuLinksFollowlinkaddress.Size = New System.Drawing.Size(244, 22)
        Me.mnuLinksFollowlinkaddress.Text = "Follow link address (not click)"
        '
        'mnuOptions
        '
        Me.mnuOptions.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuOptionsFont, Me.mnuOptionsInvert, Me.mnuOptionsLanguage, Me.mnuOptionsMakeWebbIEDefault, Me.mnuOptionsOptions, Me.mnuOptionsSetHomepage})
        Me.mnuOptions.Name = "mnuOptions"
        Me.mnuOptions.Size = New System.Drawing.Size(61, 20)
        Me.mnuOptions.Text = "&Options"
        '
        'mnuOptionsFont
        '
        Me.mnuOptionsFont.Name = "mnuOptionsFont"
        Me.mnuOptionsFont.Size = New System.Drawing.Size(251, 22)
        Me.mnuOptionsFont.Text = "Font..."
        '
        'mnuOptionsInvert
        '
        Me.mnuOptionsInvert.Name = "mnuOptionsInvert"
        Me.mnuOptionsInvert.Size = New System.Drawing.Size(251, 22)
        Me.mnuOptionsInvert.Text = "&Invert"
        '
        'mnuOptionsLanguage
        '
        Me.mnuOptionsLanguage.Name = "mnuOptionsLanguage"
        Me.mnuOptionsLanguage.Size = New System.Drawing.Size(251, 22)
        Me.mnuOptionsLanguage.Text = "Language options..."
        '
        'mnuOptionsMakeWebbIEDefault
        '
        Me.mnuOptionsMakeWebbIEDefault.Name = "mnuOptionsMakeWebbIEDefault"
        Me.mnuOptionsMakeWebbIEDefault.Size = New System.Drawing.Size(251, 22)
        Me.mnuOptionsMakeWebbIEDefault.Text = "Make WebbIE the default browser"
        '
        'mnuOptionsOptions
        '
        Me.mnuOptionsOptions.Name = "mnuOptionsOptions"
        Me.mnuOptionsOptions.Size = New System.Drawing.Size(251, 22)
        Me.mnuOptionsOptions.Text = "&Options..."
        '
        'mnuOptionsSetHomepage
        '
        Me.mnuOptionsSetHomepage.Name = "mnuOptionsSetHomepage"
        Me.mnuOptionsSetHomepage.Size = New System.Drawing.Size(251, 22)
        Me.mnuOptionsSetHomepage.Text = "Set home page"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpManual, Me.mnuHelpWebbIEOrg, Me.mnuHelpAbout})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mnuHelp.Text = "&Help"
        '
        'mnuHelpManual
        '
        Me.mnuHelpManual.Name = "mnuHelpManual"
        Me.mnuHelpManual.Size = New System.Drawing.Size(179, 22)
        Me.mnuHelpManual.Text = "Manual"
        '
        'mnuHelpWebbIEOrg
        '
        Me.mnuHelpWebbIEOrg.Name = "mnuHelpWebbIEOrg"
        Me.mnuHelpWebbIEOrg.Size = New System.Drawing.Size(179, 22)
        Me.mnuHelpWebbIEOrg.Text = "www.webbie.org.uk"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Name = "mnuHelpAbout"
        Me.mnuHelpAbout.Size = New System.Drawing.Size(179, 22)
        Me.mnuHelpAbout.Text = "About"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(880, 557)
        Me.Controls.Add(Me.fraMain)
        Me.Controls.Add(Me.MenuStripMain)
        Me.Controls.Add(Me.workBrowser)
        Me.Controls.Add(Me.staMain)
        Me.Controls.Add(Me.lblText)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(15, 57)
        Me.Name = "frmMain"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Tag = "frmMain"
        Me.Text = "WebbIE"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.staMain.ResumeLayout(False)
        Me.staMain.PerformLayout()
        Me.fraNavigationBar.ResumeLayout(False)
        Me.fraToolBar.ResumeLayout(False)
        Me.fraBusy.ResumeLayout(False)
        Me.fraBusy.PerformLayout()
        CType(Me.picBusy, System.ComponentModel.ISupportInitialize).EndInit()
        Me.fraMain.ResumeLayout(False)
        Me.fraText.ResumeLayout(False)
        Me.fraContent.ResumeLayout(False)
        Me.fraContent.PerformLayout()
        Me.fraAddress.ResumeLayout(False)
        Me.fraAddress.PerformLayout()
        Me.MenuStripMain.ResumeLayout(False)
        Me.MenuStripMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout

End Sub
    Friend WithEvents fraNavigationBar As System.Windows.Forms.Panel
    Friend WithEvents fraMain As System.Windows.Forms.Panel
    Friend WithEvents fraText As System.Windows.Forms.Panel
    Friend WithEvents fraAddress As System.Windows.Forms.Panel
    Public WithEvents cboAddress As System.Windows.Forms.ComboBox
    Public WithEvents fraToolBar As System.Windows.Forms.Panel
    Public WithEvents cmdHeading As System.Windows.Forms.Button
    Public WithEvents cmdMagnify As System.Windows.Forms.Button
    Public WithEvents cmdSkiplinks As System.Windows.Forms.Button
    Public WithEvents cmdViewIE As System.Windows.Forms.Button
    Public WithEvents cmdHome As System.Windows.Forms.Button
    Public WithEvents cmdRefresh As System.Windows.Forms.Button
    Public WithEvents cmdStop As System.Windows.Forms.Button
    Public WithEvents cmdForward As System.Windows.Forms.Button
    Public WithEvents cmdBack As System.Windows.Forms.Button
    Public WithEvents fraBusy As System.Windows.Forms.Panel
    Public WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents tmrFocusMonitor As System.Windows.Forms.Timer
    Friend WithEvents mnuBar As System.Windows.Forms.ToolStripSeparator
    Public WithEvents cmdShrink As System.Windows.Forms.Button
    Friend WithEvents picBusy As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStripMain As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileOpen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFilePrint As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEditCopy As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEditCut As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEditPaste As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEditSelectall As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEditFind As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEditFindNext As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuEditWebsearch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuView As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuViewIE As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuViewCroppage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuViewRSSNewsFeed As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuViewMagnify As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuViewShrink As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuViewSource As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFavorites As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFavoritesAdd As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFavoritesGotofavorites As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFavoritesOrganise As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNavigate As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNavigateBack As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNavigateStop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNavigateHome As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNavigateRefresh As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNavigateForward As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNavigateGotoheadline As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuNavigateGotoform As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinks As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinksNextlink As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinksPreviouslink As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinksSkipDown As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinksSkipup As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinksViewlinks As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinksDownloadlinktarget As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuLinksFollowlinkaddress As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptionsFont As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptionsInvert As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptionsLanguage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptionsMakeWebbIEDefault As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptionsOptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuOptionsSetHomepage As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelpManual As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelpWebbIEOrg As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuHelpAbout As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents fraContent As System.Windows.Forms.Panel
    Public WithEvents webMain As System.Windows.Forms.WebBrowser
    Public WithEvents txtText As System.Windows.Forms.TextBox

#End Region
End Class