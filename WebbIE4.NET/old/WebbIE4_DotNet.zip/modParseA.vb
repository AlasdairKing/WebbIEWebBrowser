Option Strict On
Option Explicit On
Module modParseA
	
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'modParseA
	'Parses an Anchor element, identifying text and image content and getting alt text where necessary
	'Also parses Button nodes, which can also contain content.
	
	Private mAnchorDatabase As New Scripting.Dictionary
    Private mToGetList As New System.Collections.Generic.Dictionary(Of String, String)
	Private mGetter As New frmLocationGetter
	
    Public Function Parse(ByRef anyNode As mshtml.IHTMLDOMNode) As String

        Parse = Trim(ParseA(anyNode))
    End Function

    Public Function ParseAnchor(ByRef anchorNode As mshtml.IHTMLDOMNode) As String
        ParseAnchor = Trim(ParseA(anchorNode))
    End Function


    Private Function ParseA(ByRef anchorNode As mshtml.IHTMLDOMNode) As String

        Dim childNode As mshtml.IHTMLDOMNode
        Dim NBSP As String
        NBSP = Chr(160)
        ParseA = ""
        Dim childNodes As mshtml.IHTMLDOMChildrenCollection
        Dim htmlE As mshtml.IHTMLElement

        If anchorNode.nodeName = "#text" Then
            ParseA = anchorNode.nodeValue.ToString
            ParseA = Replace(ParseA, NBSP, " ")
            ParseA = Replace(ParseA, vbNewLine, "")
            ParseA = Replace(ParseA, vbCr, "")
            ParseA = Replace(ParseA, vbLf, "")
            'Debug.Print "Text obtained via ParseA: " & ParseA
        ElseIf anchorNode.nodeName = "IMG" Then
            htmlE = CType(anchorNode, mshtml.IHTMLElement)
            If htmlE.getAttribute("alt") Is Nothing Then
                'No alt tag!
            Else
                'We put the " " in because people tend to just do "text<img>" - BBC News
                'does this.
                ParseA = " " & htmlE.getAttribute("alt").ToString & " "
            End If
        ElseIf anchorNode.hasChildNodes Then
            childNodes = CType(anchorNode.childNodes, mshtml.IHTMLDOMChildrenCollection)
            For Each childNode In childNodes
                ParseA = ParseA & ParseA(childNode)
            Next childNode
        End If

        'If no text obtained: fall back to A element's title or alt attribute. Title first.
        'But might be a non-A element with some information itself, or it might be
        'an A element with a title attribute - see http://www.unco.edu/, which uses
        'links with &nbsp; as the link content, fills in the content with an image
        'as the background in CSS, and puts the text content in the title attribute
        If ParseA = "" Then
            htmlE = CType(anchorNode, mshtml.IHTMLElement)
            If htmlE.getAttribute("title") Is Nothing Then
            Else
                ParseA = htmlE.getAttribute("title").ToString & " "
            End If
        End If
    End Function

    Public Sub AddLocationTitle(ByRef url As String, ByRef title As String)

        If mAnchorDatabase.Exists(CObj(url)) Then
            mAnchorDatabase(url) = title
        Else
            Call mAnchorDatabase.Add(CObj(url), CObj(title))
        End If
    End Sub

    Public Function GetLocationTitle(ByRef url As String) As String

        If mAnchorDatabase.Exists(CObj(url)) Then
            GetLocationTitle = mAnchorDatabase.Item(url).ToString
        Else
            Call AddLocationToGet(url)
            GetLocationTitle = ""
        End If
    End Function

    Private Sub AddLocationToGet(ByRef url As String)

        If InStr(1, url, "javascript", CompareMethod.Text) = 1 Or InStr(1, url, "doubleclick", CompareMethod.Text) > 0 Then
            'Don't get, crap.
        ElseIf Len(Trim(url)) = 0 Then
            'Don't get, invalid
        Else
            'Debug.Print "Added location to get: " & url
            If Not mToGetList.ContainsKey(url) Then
                Call mToGetList.Add(url, "")
            End If
        End If
    End Sub

    Public Function IsLocationsToGet() As Boolean

        IsLocationsToGet = (mToGetList.Count > 0)
    End Function

    Public Sub StartGettingLocations()

        Call mGetter.StartGetting()
    End Sub

    Public Sub StopGettingLocations()

        Call mGetter.StopGetting()
    End Sub

    Public Function NextLocationToGet() As String
        Dim toGet As String = ""

        If mToGetList.Count > 0 Then
            NextLocationToGet = ""
            For Each toGet In mToGetList.Keys
                NextLocationToGet = toGet
                Exit For
            Next toGet
            If toGet <> "" Then
                Call mToGetList.Remove(toGet)
            End If
        Else
            Return ""
        End If
    End Function
End Module