<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmLinks
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
    Public WithEvents lstLinks As System.Windows.Forms.ListBox
	Public WithEvents _optSort_1 As System.Windows.Forms.RadioButton
    Public WithEvents optSortPageOrder As System.Windows.Forms.RadioButton
    Public WithEvents cmdGo As System.Windows.Forms.Button
    Public WithEvents cmdCloseLinks As System.Windows.Forms.Button
    Public WithEvents lblLinks As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmLinks))
        Me.lstLinks = New System.Windows.Forms.ListBox()
        Me._optSort_1 = New System.Windows.Forms.RadioButton()
        Me.optSortPageOrder = New System.Windows.Forms.RadioButton()
        Me.cmdGo = New System.Windows.Forms.Button()
        Me.cmdCloseLinks = New System.Windows.Forms.Button()
        Me.lblLinks = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.SuspendLayout()
        '
        'lstLinks
        '
        Me.lstLinks.BackColor = System.Drawing.SystemColors.Window
        Me.lstLinks.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstLinks.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstLinks.IntegralHeight = False
        Me.lstLinks.Location = New System.Drawing.Point(0, 8)
        Me.lstLinks.Name = "lstLinks"
        Me.lstLinks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstLinks.Size = New System.Drawing.Size(521, 279)
        Me.lstLinks.TabIndex = 5
        '
        '_optSort_1
        '
        Me._optSort_1.BackColor = System.Drawing.SystemColors.Control
        Me._optSort_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._optSort_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._optSort_1.Location = New System.Drawing.Point(16, 320)
        Me._optSort_1.Name = "_optSort_1"
        Me._optSort_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._optSort_1.Size = New System.Drawing.Size(281, 33)
        Me._optSort_1.TabIndex = 1
        Me._optSort_1.TabStop = True
        Me._optSort_1.Tag = "frmLinks.optSort(1)"
        Me._optSort_1.Text = "Sort by &Alphabetical order"
        Me._optSort_1.UseVisualStyleBackColor = False
        '
        'optSortPageOrder
        '
        Me.optSortPageOrder.BackColor = System.Drawing.SystemColors.Control
        Me.optSortPageOrder.Checked = True
        Me.optSortPageOrder.Cursor = System.Windows.Forms.Cursors.Default
        Me.optSortPageOrder.ForeColor = System.Drawing.SystemColors.ControlText
        Me.optSortPageOrder.Location = New System.Drawing.Point(16, 288)
        Me.optSortPageOrder.Name = "optSortPageOrder"
        Me.optSortPageOrder.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.optSortPageOrder.Size = New System.Drawing.Size(289, 33)
        Me.optSortPageOrder.TabIndex = 0
        Me.optSortPageOrder.TabStop = True
        Me.optSortPageOrder.Tag = "frmLinks.optSort(0)"
        Me.optSortPageOrder.Text = "Sort by &Page order"
        Me.optSortPageOrder.UseVisualStyleBackColor = False
        '
        'cmdGo
        '
        Me.cmdGo.BackColor = System.Drawing.SystemColors.Control
        Me.cmdGo.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdGo.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdGo.Location = New System.Drawing.Point(336, 312)
        Me.cmdGo.Name = "cmdGo"
        Me.cmdGo.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdGo.Size = New System.Drawing.Size(79, 31)
        Me.cmdGo.TabIndex = 2
        Me.cmdGo.Text = "OK"
        Me.cmdGo.UseVisualStyleBackColor = False
        '
        'cmdCloseLinks
        '
        Me.cmdCloseLinks.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCloseLinks.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCloseLinks.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCloseLinks.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCloseLinks.Location = New System.Drawing.Point(424, 312)
        Me.cmdCloseLinks.Name = "cmdCloseLinks"
        Me.cmdCloseLinks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCloseLinks.Size = New System.Drawing.Size(71, 31)
        Me.cmdCloseLinks.TabIndex = 3
        Me.cmdCloseLinks.Tag = "frmLinks.cmdCancel"
        Me.cmdCloseLinks.Text = "Cancel"
        Me.cmdCloseLinks.UseVisualStyleBackColor = False
        '
        'lblLinks
        '
        Me.lblLinks.AutoSize = True
        Me.lblLinks.BackColor = System.Drawing.SystemColors.Control
        Me.lblLinks.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblLinks.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblLinks.Location = New System.Drawing.Point(96, 48)
        Me.lblLinks.Name = "lblLinks"
        Me.lblLinks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblLinks.Size = New System.Drawing.Size(32, 13)
        Me.lblLinks.TabIndex = 4
        Me.lblLinks.Text = "&Links"
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "SortGroupBox"
        '
        'frmLinks
        '
        Me.AcceptButton = Me.cmdGo
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton = Me.cmdCloseLinks
        Me.ClientSize = New System.Drawing.Size(521, 357)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lstLinks)
        Me.Controls.Add(Me._optSort_1)
        Me.Controls.Add(Me.optSortPageOrder)
        Me.Controls.Add(Me.cmdGo)
        Me.Controls.Add(Me.cmdCloseLinks)
        Me.Controls.Add(Me.lblLinks)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(222, 261)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLinks"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Tag = "frmLinks"
        Me.Text = "Webpage Links"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
#End Region 
End Class