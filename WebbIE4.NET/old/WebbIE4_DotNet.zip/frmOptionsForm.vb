﻿Public Class frmOptionsForm

    Private Sub chkAllowMessages_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkAllowMessages.CheckedChanged
        frmMain.webMain.ScriptErrorsSuppressed = Not chkAllowMessages.Checked
    End Sub

    Private Sub btnOK_Click(sender As System.Object, e As System.EventArgs) Handles btnOK.Click
        Me.Hide()
    End Sub
End Class