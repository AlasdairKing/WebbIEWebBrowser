Option Strict Off
Option Explicit On
Friend Class clsSystemFont
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'CSystemFont
	'This class handles checking Windows for the correct system font settings
	'(e.g. bold, size, font to use) and updates forms passed to it.
	
	
	Private mNonClientMetrics As NONCLIENTMETRICS ' holds the response from
	'windows of asking about the font details
	
	'type containing font information obtained from Windows
	Private Structure NMLOGFONT
		Dim height As Integer
		Dim width As Integer
		Dim escapement As Integer
		Dim orientation As Integer
		Dim weight As Integer
		Dim italic As Byte
		Dim underline As Byte
		Dim strikeOut As Byte
		Dim charSet As Byte
		Dim outPrecision As Byte
		Dim clipPrecision As Byte
		Dim quality As Byte
		Dim pitchAndFamily As Byte
		<VBFixedArray(28)> Dim faceName() As Byte
		
		'UPGRADE_TODO: "Initialize" must be called to initialize instances of this structure. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="B4BFF9E0-8631-45CF-910E-62AB3970F27B"'
		Public Sub Initialize()
			ReDim faceName(28)
		End Sub
	End Structure
	
	'bold value
	Private Const FW_NORMAL As Integer = 400
	
	'gets font information from Windows.
	'uAction = SPI_GETNONCLIENTMETRICS for font information
	'UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
	Private Declare Function SystemParametersInfo Lib "user32"  Alias "SystemParametersInfoA"(ByVal uAction As Integer, ByVal uParam As Integer, ByRef lpvParam As Any, ByVal fuWinIni As Integer) As Integer
	Private Const SPI_GETNONCLIENTMETRICS As Short = 41
	'gets form information from Windows
	Private Declare Function GetDeviceCaps Lib "gdi32" (ByVal hDC As Integer, ByVal nIndex As Integer) As Integer
	Private Const LOGPIXELSY As Short = 90 'logical pixels per inch on Y axis
	
	'These hold the VB fonts obtained from Windows
	Private cCaptionFont As System.Drawing.Font = System.Windows.Forms.Control.DefaultFont.Clone()
	Private cSmallCaptionFont As System.Drawing.Font = System.Windows.Forms.Control.DefaultFont.Clone()
	Private cMenuFont As System.Drawing.Font = System.Windows.Forms.Control.DefaultFont.Clone()
	Private cStatusFont As System.Drawing.Font = System.Windows.Forms.Control.DefaultFont.Clone()
	Private cMessagefont As System.Drawing.Font = System.Windows.Forms.Control.DefaultFont.Clone()
	
	'Contents provided by SystemParametersInfo API call
	'see MSDN for details of this structure
	Private Structure NONCLIENTMETRICS
		Dim cbSize As Integer
		Dim iBorderWidth As Integer
		Dim iScrollWidth As Integer
		Dim iScrollHeight As Integer
		Dim iCaptionWidth As Integer
		Dim iCaptionHeight As Integer
		'UPGRADE_WARNING: Arrays in structure lfCaptionFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfCaptionFont As NMLOGFONT
		Dim iSMCaptionWidth As Integer
		Dim iSMCaptionHeight As Integer
		'UPGRADE_WARNING: Arrays in structure lfSMCaptionFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfSMCaptionFont As NMLOGFONT
		Dim iMenuWidth As Integer
		Dim iMenuHeight As Integer
		'UPGRADE_WARNING: Arrays in structure lfMenuFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfMenuFont As NMLOGFONT
		'UPGRADE_WARNING: Arrays in structure lfStatusFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfStatusFont As NMLOGFONT
		'UPGRADE_WARNING: Arrays in structure lfMessageFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfMessageFont As NMLOGFONT
		
		'UPGRADE_TODO: "Initialize" must be called to initialize instances of this structure. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="B4BFF9E0-8631-45CF-910E-62AB3970F27B"'
		Public Sub Initialize()
			lfCaptionFont.Initialize()
			lfSMCaptionFont.Initialize()
			lfMenuFont.Initialize()
			lfStatusFont.Initialize()
			lfMessageFont.Initialize()
		End Sub
	End Structure
	
	'on start-up read the font settings from Windows
	'UPGRADE_NOTE: Class_Initialize was upgraded to Class_Initialize_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
	Private Sub Class_Initialize_Renamed()
		On Error Resume Next
		Dim aForm As System.Windows.Forms.Form
		
		'Get non-client metrics
		mNonClientMetrics.cbSize = 340
		'UPGRADE_WARNING: Couldn't resolve default property of object mNonClientMetrics. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		Call SystemParametersInfo(SPI_GETNONCLIENTMETRICS, 0, mNonClientMetrics, 0)
		'now set our local fonts
		'UPGRADE_ISSUE: Form property frmMain.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
		Call ConvertNMLOGFONTIntoStdFont(mNonClientMetrics.lfCaptionFont, frmMain.hDC, cCaptionFont)
		'UPGRADE_ISSUE: Form property frmMain.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
		Call ConvertNMLOGFONTIntoStdFont(mNonClientMetrics.lfSMCaptionFont, frmMain.hDC, cSmallCaptionFont)
		'UPGRADE_ISSUE: Form property frmMain.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
		Call ConvertNMLOGFONTIntoStdFont(mNonClientMetrics.lfMenuFont, frmMain.hDC, cMenuFont)
		'UPGRADE_ISSUE: Form property frmMain.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
		Call ConvertNMLOGFONTIntoStdFont(mNonClientMetrics.lfStatusFont, frmMain.hDC, cStatusFont)
		'UPGRADE_ISSUE: Form property frmMain.hDC was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="CC4C7EC0-C903-48FC-ACCC-81861D12DA4A"'
		Call ConvertNMLOGFONTIntoStdFont(mNonClientMetrics.lfMessageFont, frmMain.hDC, cMessagefont)
		'now update all the forms
		For	Each aForm In My.Application.OpenForms
			Call AmendControlsOnForm(aForm)
		Next aForm
	End Sub
	Public Sub New()
		MyBase.New()
		Class_Initialize_Renamed()
	End Sub
	
	'go through every control applying the correct font settings
	Private Sub AmendControlsOnForm(ByRef myForm As System.Windows.Forms.Form)
		On Error Resume Next
		Dim aControl As System.Windows.Forms.Control
		
		For	Each aControl In myForm.Controls
			'Debug.Print "Doing: " & aControl.Name
			'okay, this looks odd: the reason is in case I need to differentiate
			'between control types and give them different font values in future
			' - we have five from which to choose.
			'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			If TypeOf aControl Is System.Windows.Forms.Label Then
				aControl.Font = cMessagefont
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.TextBox Then 
				'leave client areas alone
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.GroupBox Then 
				aControl.Font = cMessagefont
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.CheckBox Then 
				aControl.Font = cMessagefont
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.RadioButton Then 
				aControl.Font = cMessagefont
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.Button Then 
				aControl.Font = cMessagefont
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.ComboBox Then 
				'leave client areas alone
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.StatusStrip Then 
				aControl.Font = cStatusFont
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.ProgressBar Then 
				'this doesn't have a font property
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.WebBrowser Then 
				'this doesn't have a font property
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.ToolStripMenuItem Then 
				'this doesn't have a font property
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.ImageList Then 
				'this doesn't have a font property
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is AxMSWinsockLib.AxWinsock Then 
				'this doesn't have a font property
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is Object Then 
				'this doesn't have a font property
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.Timer Then 
				'this doesn't have a font property
				'UPGRADE_WARNING: TypeOf has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
			ElseIf TypeOf aControl Is System.Windows.Forms.ToolStrip Then 
				'this doesn't have a font property
			Else
				'everything else gets default
				aControl.Font = cMessagefont
			End If
		Next aControl
	End Sub
	
	'converts a LOGFONT obtained from Windows into a standard VB font
	Private Sub ConvertNMLOGFONTIntoStdFont(ByRef LOGFONT As NMLOGFONT, ByVal hDC As Integer, ByRef standardFont As System.Drawing.Font)
		On Error Resume Next
		'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
		standardFont = VB6.FontChangeName(standardFont, StrConv(System.Text.UnicodeEncoding.Unicode.GetString(LOGFONT.faceName), vbUnicode))
		'Debug.Print "logfont.height:" & logFont.height
		If LOGFONT.height < 1 Then
			standardFont = VB6.FontChangeSize(standardFont, System.Math.Abs((72# / GetDeviceCaps(hDC, LOGPIXELSY)) * LOGFONT.height))
		Else
			standardFont = VB6.FontChangeSize(standardFont, LOGFONT.height)
		End If
		'Debug.Print "Standard font size: " & standardFont.Size
		standardFont = VB6.FontChangeGdiCharSet(standardFont, LOGFONT.charSet)
		standardFont = VB6.FontChangeItalic(standardFont, Not (LOGFONT.italic = 0))
		standardFont = VB6.FontChangeUnderline(standardFont, Not (LOGFONT.underline = 0))
		standardFont = VB6.FontChangeStrikeOut(standardFont, Not (LOGFONT.strikeOut = 0))
		'    Debug.Print "logFont.weight: " & logFont.weight
		standardFont = VB6.FontChangeBold(standardFont, (LOGFONT.weight > FW_NORMAL))
	End Sub
End Class