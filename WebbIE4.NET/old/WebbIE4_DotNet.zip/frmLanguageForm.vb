Option Strict On
Option Explicit On
Friend Class frmLanguageForm
    Inherits System.Windows.Forms.Form
    '   This file is part of WebbIE.
    '
    '    WebbIE is free software: you can redistribute it and/or modify
    '    it under the terms of the GNU General Public License as published by
    '    the Free Software Foundation, either version 3 of the License, or
    '    (at your option) any later version.
    '
    '    WebbIE is distributed in the hope that it will be useful,
    '    but WITHOUT ANY WARRANTY; without even the implied warranty of
    '    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    '    GNU General Public License for more details.
    '
    '    You should have received a copy of the GNU General Public License
    '    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
        'exit the form, no changes

        Me.Hide()
    End Sub

    Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click
        'update the default codepage selection, intDefaultCodepage


        'set the user setting on whether the user wants to override the
        'ie autodetection of language and always use their own
        'selected character set
        If optDetect(0).Checked Then
            blnAlwaysUseUserDefaultLanguage = True
        Else
            blnAlwaysUseUserDefaultLanguage = False
        End If
        'change the default language used by WebbIE
        If optLanguage(0).Checked Then
            intDefaultCharset = CHARSET_ARABIC
            lngDefaultLocale = LOCALE_ARABIC
        ElseIf optLanguage(1).Checked Then
            intDefaultCharset = CHARSET_BALTIC
            lngDefaultLocale = LOCALE_BALTIC
        ElseIf optLanguage(2).Checked Then
            intDefaultCharset = CHARSET_EASTERN_EUROPE
            lngDefaultLocale = LOCALE_EASTERN_EUROPE
        ElseIf optLanguage(3).Checked Then
            intDefaultCharset = CHARSET_CHINESE_SIMPLIFIED
            lngDefaultLocale = LOCALE_CHINESE_SIMPLIFIED
        ElseIf optLanguage(4).Checked Then
            intDefaultCharset = CHARSET_CHINESE_TRADITIONAL
            lngDefaultLocale = LOCALE_CHINESE_TRADITIONAL
        ElseIf optLanguage(5).Checked Then
            intDefaultCharset = CHARSET_RUSSIAN
            lngDefaultLocale = LOCALE_RUSSIAN
        ElseIf optLanguage(6).Checked Then
            intDefaultCharset = CHARSET_GREEK
            lngDefaultLocale = LOCALE_GREEK
        ElseIf optLanguage(7).Checked Then
            intDefaultCharset = CHARSET_HEBREW
            lngDefaultLocale = LOCALE_HEBREW
        ElseIf optLanguage(8).Checked Then
            intDefaultCharset = CHARSET_JAPANESE
            lngDefaultLocale = LOCALE_JAPANESE
        ElseIf optLanguage(9).Checked Then
            intDefaultCharset = CHARSET_KOREAN
            lngDefaultLocale = LOCALE_KOREAN
        ElseIf optLanguage(10).Checked Then
            intDefaultCharset = CHARSET_THAI
            lngDefaultLocale = LOCALE_THAI
        ElseIf optLanguage(11).Checked Then
            intDefaultCharset = CHARSET_TURKISH
            lngDefaultLocale = LOCALE_TURKISH
        ElseIf optLanguage(12).Checked Then
            intDefaultCharset = CHARSET_VIETNAMESE
            lngDefaultLocale = LOCALE_VIETNAMESE
        ElseIf optLanguage(13).Checked Then
            intDefaultCharset = CHARSET_WESTERN_EUROPEAN
            lngDefaultLocale = LOCALE_WESTERN_EUROPEAN
        End If
        'trigger a reload if a page is loaded
        Call Me.Hide()
        If Len(frmMain.webMain.Url.ToString()) > 0 Then
            Call frmMain.RefreshCurrentPage()
        End If
    End Sub

    'UPGRADE_WARNING: Form event frmLanguage.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
    Private Sub frmLanguage_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
        'show the current default homepage value in the option menu list

        If intDefaultCharset = CHARSET_ARABIC Then optLanguage(0).Checked = True
        If intDefaultCharset = CHARSET_BALTIC Then optLanguage(1).Checked = True
        If intDefaultCharset = CHARSET_EASTERN_EUROPE Then optLanguage(2).Checked = True
        If intDefaultCharset = CHARSET_CHINESE_SIMPLIFIED Then optLanguage(3).Checked = True
        If intDefaultCharset = CHARSET_CHINESE_TRADITIONAL Then optLanguage(4).Checked = True
        If intDefaultCharset = CHARSET_RUSSIAN Then optLanguage(5).Checked = True
        If intDefaultCharset = CHARSET_GREEK Then optLanguage(6).Checked = True
        If intDefaultCharset = CHARSET_HEBREW Then optLanguage(7).Checked = True
        If intDefaultCharset = CHARSET_JAPANESE Then optLanguage(8).Checked = True
        If intDefaultCharset = CHARSET_KOREAN Then optLanguage(9).Checked = True
        If intDefaultCharset = CHARSET_THAI Then optLanguage(10).Checked = True
        If intDefaultCharset = CHARSET_TURKISH Then optLanguage(11).Checked = True
        If intDefaultCharset = CHARSET_VIETNAMESE Then optLanguage(12).Checked = True
        If intDefaultCharset = CHARSET_WESTERN_EUROPEAN Then optLanguage(13).Checked = True
        If blnAlwaysUseUserDefaultLanguage Then
            optDetect(0).Checked = True
        Else
            optDetect(1).Checked = True
        End If
    End Sub

End Class