Option Strict On
Option Explicit On
Friend Class frmTextareaInput
	Inherits System.Windows.Forms.Form
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	Private mobjTextAreaNode As mshtml.IHTMLDOMNode ' the text area node we're working on
	Public targetForm As frmMain
	Public areaLabel As String ' holds any label give the input by the page
	
	Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click

        Call Me.Hide()
        Call Me.targetForm.Show()
    End Sub

    Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click
        'exit the form

        Call Me.Hide()
        Call Me.targetForm.Show()
        Call targetForm.UpdateTextarea((txtInput.Text), mobjTextAreaNode)
    End Sub

    'UPGRADE_WARNING: Form event frmTextareaInput.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
    Private Sub frmTextareaInput_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

        txtInput.Font = targetForm.txtText.Font
        If Len(areaLabel) > 0 Then
            'we've had the areaLabel variable set to something: this should be
            'the label applied to the element in the web page
            Me.Text = areaLabel
        Else
            'nope, use the default phrase
            Me.Text = modI18N.GetText("Input text")
        End If
        Call Me.txtInput.Focus()
    End Sub

    Private Sub frmTextareaInput_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000
        'exit when user presses escape

        If KeyCode = System.Windows.Forms.Keys.Escape Then
            Call cmdCancel_Click(cmdCancel, New System.EventArgs())
        End If
    End Sub

    Public Sub Populate(ByRef textAreaNode As mshtml.IHTMLDOMNode)
        'show the original text
        Dim e As mshtml.IHTMLElement

        e = CType(textAreaNode, mshtml.IHTMLElement)
        txtInput.Text = e.innerText
        mobjTextAreaNode = textAreaNode
    End Sub

    Private Sub txtInput_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles txtInput.KeyDown
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000

        If KeyCode = CInt(System.Windows.Forms.Keys.A) And eventArgs.Control Then
            txtInput.SelectionStart = 0
            txtInput.SelectionLength = Len(txtInput.Text)
            Call ScrollToCursor(txtInput)
        ElseIf KeyCode = System.Windows.Forms.Keys.Return And eventArgs.Control Then
            Call cmdOK_Click(cmdOK, New System.EventArgs())
        End If
    End Sub
End Class