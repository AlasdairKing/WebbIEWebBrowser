<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmRSS
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents lstItems As System.Windows.Forms.ListBox
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents cmdSubscribe As System.Windows.Forms.Button
	Public WithEvents cmdOpen As System.Windows.Forms.Button
	Public WithEvents lblItems As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmRSS))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.lstItems = New System.Windows.Forms.ListBox
		Me.cmdClose = New System.Windows.Forms.Button
		Me.cmdSubscribe = New System.Windows.Forms.Button
		Me.cmdOpen = New System.Windows.Forms.Button
		Me.lblItems = New System.Windows.Forms.Label
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		Me.Text = "RSS News feed"
		Me.ClientSize = New System.Drawing.Size(788, 248)
		Me.Location = New System.Drawing.Point(4, 30)
		Me.Font = New System.Drawing.Font("Tahoma", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Icon = CType(resources.GetObject("frmRSS.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmRSS"
		Me.lstItems.Size = New System.Drawing.Size(305, 119)
		Me.lstItems.IntegralHeight = False
		Me.lstItems.Location = New System.Drawing.Point(8, 32)
		Me.lstItems.TabIndex = 3
		Me.lstItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lstItems.BackColor = System.Drawing.SystemColors.Window
		Me.lstItems.CausesValidation = True
		Me.lstItems.Enabled = True
		Me.lstItems.ForeColor = System.Drawing.SystemColors.WindowText
		Me.lstItems.Cursor = System.Windows.Forms.Cursors.Default
		Me.lstItems.SelectionMode = System.Windows.Forms.SelectionMode.One
		Me.lstItems.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lstItems.Sorted = False
		Me.lstItems.TabStop = True
		Me.lstItems.Visible = True
		Me.lstItems.MultiColumn = False
		Me.lstItems.Name = "lstItems"
		Me.cmdClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.CancelButton = Me.cmdClose
		Me.cmdClose.Text = "Close"
		Me.cmdClose.Size = New System.Drawing.Size(97, 33)
		Me.cmdClose.Location = New System.Drawing.Point(112, 160)
		Me.cmdClose.TabIndex = 1
		Me.cmdClose.Tag = "frmRSS.cmdClose"
		Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
		Me.cmdClose.CausesValidation = True
		Me.cmdClose.Enabled = True
		Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdClose.TabStop = True
		Me.cmdClose.Name = "cmdClose"
		Me.cmdSubscribe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdSubscribe.Text = "&Subscribe"
		Me.cmdSubscribe.Enabled = False
		Me.cmdSubscribe.Size = New System.Drawing.Size(97, 33)
		Me.cmdSubscribe.Location = New System.Drawing.Point(216, 160)
		Me.cmdSubscribe.TabIndex = 2
		Me.cmdSubscribe.BackColor = System.Drawing.SystemColors.Control
		Me.cmdSubscribe.CausesValidation = True
		Me.cmdSubscribe.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdSubscribe.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdSubscribe.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdSubscribe.TabStop = True
		Me.cmdSubscribe.Name = "cmdSubscribe"
		Me.cmdOpen.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdOpen.Text = "&Open"
		Me.AcceptButton = Me.cmdOpen
		Me.cmdOpen.Enabled = False
		Me.cmdOpen.Size = New System.Drawing.Size(97, 33)
		Me.cmdOpen.Location = New System.Drawing.Point(8, 160)
		Me.cmdOpen.TabIndex = 0
		Me.cmdOpen.Tag = "frmRSS.cmdOpen"
		Me.cmdOpen.BackColor = System.Drawing.SystemColors.Control
		Me.cmdOpen.CausesValidation = True
		Me.cmdOpen.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdOpen.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdOpen.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdOpen.TabStop = True
		Me.cmdOpen.Name = "cmdOpen"
		Me.lblItems.Text = "&Items"
		Me.lblItems.Size = New System.Drawing.Size(105, 17)
		Me.lblItems.Location = New System.Drawing.Point(8, 8)
		Me.lblItems.TabIndex = 4
		Me.lblItems.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblItems.BackColor = System.Drawing.SystemColors.Control
		Me.lblItems.Enabled = True
		Me.lblItems.ForeColor = System.Drawing.SystemColors.ControlText
		Me.lblItems.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblItems.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblItems.UseMnemonic = True
		Me.lblItems.Visible = True
		Me.lblItems.AutoSize = False
		Me.lblItems.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.lblItems.Name = "lblItems"
		Me.Controls.Add(lstItems)
		Me.Controls.Add(cmdClose)
		Me.Controls.Add(cmdSubscribe)
		Me.Controls.Add(cmdOpen)
		Me.Controls.Add(lblItems)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class