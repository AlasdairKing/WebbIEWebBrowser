Option Strict Off
Option Explicit On
Module modAccesskeys
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'This module handles the use of accesskeys, key presses that trigger particular links
	
	
	Private accessKeys As Scripting.Dictionary
	Private validKeys As String
	
	Public Sub ClearAccessKeys()
		'clears any existing access keys
		On Error Resume Next
		accessKeys = New Scripting.Dictionary
	End Sub
	
	Public Sub AddAccessKey(ByRef anchor As mshtml.IHTMLAnchorElement)
		'adds an access key to the current collection.
		On Error Resume Next
		'remove it if it exists already - in case the site has assigned it twice
		If accessKeys.Exists(anchor.accessKey) Then
			Call accessKeys.Remove(anchor.accessKey)
		End If
		Call accessKeys.Add(anchor.accessKey, anchor.href)
	End Sub
	
    Public Function GetURL(ByRef accessKey As Integer) As String
        'returns the url for an access key, if any. Make case insensitive
        Dim uCaseKey As String
        Dim lCaseKey As String

        uCaseKey = UCase(ChrW(accessKey))
        lCaseKey = LCase(ChrW(accessKey))
        On Error Resume Next
        'check we have any accesskeys
        If Not (accessKeys Is Nothing) Then
            If accessKeys.Exists(lCaseKey) Then
                'yep, we have this
                'UPGRADE_WARNING: Couldn't resolve default property of object accessKeys(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                GetURL = accessKeys(lCaseKey)
            ElseIf accessKeys.Exists(uCaseKey) Then
                'UPGRADE_WARNING: Couldn't resolve default property of object accessKeys(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                GetURL = accessKeys(uCaseKey)
            Else
                'nope, no href
            End If
        End If
    End Function
End Module