Option Strict Off
Option Explicit On
Module modStart
End Module