<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmTextareaInput
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents txtInput As System.Windows.Forms.TextBox
	Public WithEvents cmdCancel As System.Windows.Forms.Button
	Public WithEvents cmdOK As System.Windows.Forms.Button
	Public WithEvents lblInputText As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmTextareaInput))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.txtInput = New System.Windows.Forms.TextBox
		Me.cmdCancel = New System.Windows.Forms.Button
		Me.cmdOK = New System.Windows.Forms.Button
		Me.lblInputText = New System.Windows.Forms.Label
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
		Me.Text = "Input text"
		Me.ClientSize = New System.Drawing.Size(616, 374)
		Me.Location = New System.Drawing.Point(4, 25)
		Me.Icon = CType(resources.GetObject("frmTextareaInput.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Tag = "frmTextareaInput"
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmTextareaInput"
		Me.txtInput.AutoSize = False
		Me.txtInput.Size = New System.Drawing.Size(617, 329)
		Me.txtInput.Location = New System.Drawing.Point(0, 0)
		Me.txtInput.MultiLine = True
		Me.txtInput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.txtInput.TabIndex = 2
		Me.txtInput.AcceptsReturn = True
		Me.txtInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtInput.BackColor = System.Drawing.SystemColors.Window
		Me.txtInput.CausesValidation = True
		Me.txtInput.Enabled = True
		Me.txtInput.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtInput.HideSelection = True
		Me.txtInput.ReadOnly = False
		Me.txtInput.Maxlength = 0
		Me.txtInput.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtInput.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtInput.TabStop = True
		Me.txtInput.Visible = True
		Me.txtInput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtInput.Name = "txtInput"
		Me.cmdCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.CancelButton = Me.cmdCancel
		Me.cmdCancel.Text = "Cancel"
		Me.cmdCancel.Size = New System.Drawing.Size(81, 33)
		Me.cmdCancel.Location = New System.Drawing.Point(304, 336)
		Me.cmdCancel.TabIndex = 1
		Me.cmdCancel.Tag = "frmTextareaInput.cmdCancel"
		Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
		Me.cmdCancel.CausesValidation = True
		Me.cmdCancel.Enabled = True
		Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdCancel.TabStop = True
		Me.cmdCancel.Name = "cmdCancel"
		Me.cmdOK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdOK.Text = "OK"
		Me.cmdOK.Size = New System.Drawing.Size(81, 33)
		Me.cmdOK.Location = New System.Drawing.Point(208, 336)
		Me.cmdOK.TabIndex = 0
		Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
		Me.cmdOK.CausesValidation = True
		Me.cmdOK.Enabled = True
		Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdOK.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdOK.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdOK.TabStop = True
		Me.cmdOK.Name = "cmdOK"
		Me.lblInputText.Text = "Input &text for form"
		Me.lblInputText.Size = New System.Drawing.Size(81, 33)
		Me.lblInputText.Location = New System.Drawing.Point(272, 168)
		Me.lblInputText.TabIndex = 3
		Me.lblInputText.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblInputText.BackColor = System.Drawing.SystemColors.Control
		Me.lblInputText.Enabled = True
		Me.lblInputText.ForeColor = System.Drawing.SystemColors.ControlText
		Me.lblInputText.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblInputText.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblInputText.UseMnemonic = True
		Me.lblInputText.Visible = True
		Me.lblInputText.AutoSize = False
		Me.lblInputText.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.lblInputText.Name = "lblInputText"
		Me.Controls.Add(txtInput)
		Me.Controls.Add(cmdCancel)
		Me.Controls.Add(cmdOK)
		Me.Controls.Add(lblInputText)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class