<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmGoogle
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents lstResults As System.Windows.Forms.ListBox
	Public WithEvents txtSearch As System.Windows.Forms.TextBox
	Public WithEvents mWebBrowser As System.Windows.Forms.WebBrowser
	Public WithEvents tmrNavigating As System.Windows.Forms.Timer
	Public WithEvents cmdInformation As System.Windows.Forms.Button
	Public WithEvents cmdSearch As System.Windows.Forms.Button
	Public WithEvents cmdGo As System.Windows.Forms.Button
	Public WithEvents cmdAddress As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents lblResults As System.Windows.Forms.Label
	Public WithEvents lblSearch As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmGoogle))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.lstResults = New System.Windows.Forms.ListBox
		Me.txtSearch = New System.Windows.Forms.TextBox
		Me.mWebBrowser = New System.Windows.Forms.WebBrowser
		Me.tmrNavigating = New System.Windows.Forms.Timer(components)
		Me.cmdInformation = New System.Windows.Forms.Button
		Me.cmdSearch = New System.Windows.Forms.Button
		Me.cmdGo = New System.Windows.Forms.Button
		Me.cmdAddress = New System.Windows.Forms.Button
		Me.cmdClose = New System.Windows.Forms.Button
		Me.lblResults = New System.Windows.Forms.Label
		Me.lblSearch = New System.Windows.Forms.Label
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
		Me.Text = "Google Results"
		Me.ClientSize = New System.Drawing.Size(775, 435)
		Me.Location = New System.Drawing.Point(4, 10)
		Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Icon = CType(resources.GetObject("frmGoogle.Icon"), System.Drawing.Icon)
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Tag = "frmGoogle"
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmGoogle"
		Me.lstResults.Size = New System.Drawing.Size(617, 167)
		Me.lstResults.Location = New System.Drawing.Point(8, 88)
		Me.lstResults.TabIndex = 9
		Me.lstResults.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lstResults.BackColor = System.Drawing.SystemColors.Window
		Me.lstResults.CausesValidation = True
		Me.lstResults.Enabled = True
		Me.lstResults.ForeColor = System.Drawing.SystemColors.WindowText
		Me.lstResults.IntegralHeight = True
		Me.lstResults.Cursor = System.Windows.Forms.Cursors.Default
		Me.lstResults.SelectionMode = System.Windows.Forms.SelectionMode.One
		Me.lstResults.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lstResults.Sorted = False
		Me.lstResults.TabStop = True
		Me.lstResults.Visible = True
		Me.lstResults.MultiColumn = False
		Me.lstResults.Name = "lstResults"
		Me.txtSearch.AutoSize = False
		Me.txtSearch.Size = New System.Drawing.Size(617, 33)
		Me.txtSearch.Location = New System.Drawing.Point(8, 32)
		Me.txtSearch.TabIndex = 8
		Me.txtSearch.Text = "Text1"
		Me.txtSearch.AcceptsReturn = True
		Me.txtSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtSearch.BackColor = System.Drawing.SystemColors.Window
		Me.txtSearch.CausesValidation = True
		Me.txtSearch.Enabled = True
		Me.txtSearch.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtSearch.HideSelection = True
		Me.txtSearch.ReadOnly = False
		Me.txtSearch.Maxlength = 0
		Me.txtSearch.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtSearch.MultiLine = False
		Me.txtSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtSearch.ScrollBars = System.Windows.Forms.ScrollBars.None
		Me.txtSearch.TabStop = True
		Me.txtSearch.Visible = True
		Me.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtSearch.Name = "txtSearch"
		Me.mWebBrowser.Size = New System.Drawing.Size(89, 89)
		Me.mWebBrowser.Location = New System.Drawing.Point(208, 48)
		Me.mWebBrowser.TabIndex = 7
		Me.mWebBrowser.AllowWebBrowserDrop = True
		Me.mWebBrowser.Name = "mWebBrowser"
		Me.tmrNavigating.Interval = 300
		Me.tmrNavigating.Enabled = True
		Me.cmdInformation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdInformation.Text = "&Information"
		Me.cmdInformation.Enabled = False
		Me.cmdInformation.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdInformation.Size = New System.Drawing.Size(81, 33)
		Me.cmdInformation.Location = New System.Drawing.Point(104, 248)
		Me.cmdInformation.TabIndex = 1
		Me.cmdInformation.Tag = "frmGoogle.cmdInformation"
		Me.cmdInformation.Visible = False
		Me.cmdInformation.BackColor = System.Drawing.SystemColors.Control
		Me.cmdInformation.CausesValidation = True
		Me.cmdInformation.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdInformation.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdInformation.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdInformation.TabStop = True
		Me.cmdInformation.Name = "cmdInformation"
		Me.cmdSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdSearch.Text = "S&earch"
		Me.cmdSearch.Enabled = False
		Me.cmdSearch.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdSearch.Size = New System.Drawing.Size(81, 33)
		Me.cmdSearch.Location = New System.Drawing.Point(96, 272)
		Me.cmdSearch.TabIndex = 2
		Me.cmdSearch.Tag = "frmGoogle.cmdSearch"
		Me.cmdSearch.BackColor = System.Drawing.SystemColors.Control
		Me.cmdSearch.CausesValidation = True
		Me.cmdSearch.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdSearch.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdSearch.TabStop = True
		Me.cmdSearch.Name = "cmdSearch"
		Me.cmdGo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdGo.Text = "&Go"
		Me.cmdGo.Enabled = False
		Me.cmdGo.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdGo.Size = New System.Drawing.Size(81, 33)
		Me.cmdGo.Location = New System.Drawing.Point(184, 272)
		Me.cmdGo.TabIndex = 3
		Me.cmdGo.Tag = "frmGoogle.cmdGo"
		Me.cmdGo.BackColor = System.Drawing.SystemColors.Control
		Me.cmdGo.CausesValidation = True
		Me.cmdGo.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdGo.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdGo.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdGo.TabStop = True
		Me.cmdGo.Name = "cmdGo"
		Me.cmdAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdAddress.Text = "&Address"
		Me.cmdAddress.Enabled = False
		Me.cmdAddress.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdAddress.Size = New System.Drawing.Size(81, 33)
		Me.cmdAddress.Location = New System.Drawing.Point(8, 272)
		Me.cmdAddress.TabIndex = 0
		Me.cmdAddress.Tag = "frmGoogle.cmdAddress"
		Me.cmdAddress.Visible = False
		Me.cmdAddress.BackColor = System.Drawing.SystemColors.Control
		Me.cmdAddress.CausesValidation = True
		Me.cmdAddress.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdAddress.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdAddress.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdAddress.TabStop = True
		Me.cmdAddress.Name = "cmdAddress"
		Me.cmdClose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.CancelButton = Me.cmdClose
		Me.cmdClose.Text = "Cancel"
		Me.cmdClose.Font = New System.Drawing.Font("Arial", 12!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.cmdClose.Size = New System.Drawing.Size(81, 33)
		Me.cmdClose.Location = New System.Drawing.Point(272, 272)
		Me.cmdClose.TabIndex = 4
		Me.cmdClose.Tag = "frmGoogle.cmdClose"
		Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
		Me.cmdClose.CausesValidation = True
		Me.cmdClose.Enabled = True
		Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdClose.TabStop = True
		Me.cmdClose.Name = "cmdClose"
		Me.lblResults.Text = "&Results"
		Me.lblResults.Size = New System.Drawing.Size(61, 20)
		Me.lblResults.Location = New System.Drawing.Point(8, 64)
		Me.lblResults.TabIndex = 6
		Me.lblResults.Tag = "frmGoogle.lblResults"
		Me.lblResults.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblResults.BackColor = System.Drawing.SystemColors.Control
		Me.lblResults.Enabled = True
		Me.lblResults.ForeColor = System.Drawing.SystemColors.ControlText
		Me.lblResults.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblResults.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblResults.UseMnemonic = True
		Me.lblResults.Visible = True
		Me.lblResults.AutoSize = True
		Me.lblResults.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.lblResults.Name = "lblResults"
		Me.lblSearch.Text = "&Search"
		Me.lblSearch.Size = New System.Drawing.Size(86, 20)
		Me.lblSearch.Location = New System.Drawing.Point(8, 8)
		Me.lblSearch.TabIndex = 5
		Me.lblSearch.Tag = "frmGoogle.lblSearch"
		Me.lblSearch.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblSearch.BackColor = System.Drawing.SystemColors.Control
		Me.lblSearch.Enabled = True
		Me.lblSearch.ForeColor = System.Drawing.SystemColors.ControlText
		Me.lblSearch.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblSearch.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblSearch.UseMnemonic = True
		Me.lblSearch.Visible = True
		Me.lblSearch.AutoSize = True
		Me.lblSearch.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.lblSearch.Name = "lblSearch"
		Me.Controls.Add(lstResults)
		Me.Controls.Add(txtSearch)
		Me.Controls.Add(mWebBrowser)
		Me.Controls.Add(cmdInformation)
		Me.Controls.Add(cmdSearch)
		Me.Controls.Add(cmdGo)
		Me.Controls.Add(cmdAddress)
		Me.Controls.Add(cmdClose)
		Me.Controls.Add(lblResults)
		Me.Controls.Add(lblSearch)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class