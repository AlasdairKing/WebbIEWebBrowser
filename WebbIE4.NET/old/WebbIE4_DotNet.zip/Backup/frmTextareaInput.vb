Option Strict Off
Option Explicit On
Friend Class frmTextareaInput
	Inherits System.Windows.Forms.Form
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	Private mobjTextAreaNode As mshtml.IHTMLDOMNode ' the text area node we're working on
	Public targetForm As frmMain
	Public areaLabel As String ' holds any label give the input by the page
	
	Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click
		On Error Resume Next
		Call Me.Hide()
		Call Me.targetForm.Show()
	End Sub
	
	Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click
		'exit the form
		On Error Resume Next
		Call Me.Hide()
		Call Me.targetForm.Show()
		Call targetForm.UpdateTextarea((txtInput.Text), mobjTextAreaNode)
	End Sub
	
	'UPGRADE_WARNING: Form event frmTextareaInput.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
	Private Sub frmTextareaInput_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		On Error Resume Next
		txtInput.Font = targetForm.txtText.Font
		If Len(areaLabel) > 0 Then
			'we've had the areaLabel variable set to something: this should be
			'the label applied to the element in the web page
			Me.Text = areaLabel
		Else
			'nope, use the default phrase
			Me.Text = modI18N.GetText("Input text")
		End If
		Call Me.txtInput.Focus()
	End Sub
	
	Private Sub frmTextareaInput_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		'exit when user presses escape
		On Error Resume Next
		If KeyCode = System.Windows.Forms.Keys.Escape Then
			Call cmdCancel_Click(cmdCancel, New System.EventArgs())
		End If
	End Sub
	
	Public Sub Populate(ByRef textAreaNode As mshtml.IHTMLDOMNode)
		'show the original text
		On Error Resume Next
		
        'UPGRADE_WARNING: Couldn't resolve default property of object textAreaNode.value. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        txtInput.Text = textAreaNode.value
        mobjTextAreaNode = textAreaNode
	End Sub
	
    'UPGRADE_WARNING: Event frmTextareaInput.Resize may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub frmTextareaInput_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
		On Error Resume Next
		If VB6.PixelsToTwipsX(Me.Width) < 1500 Then Exit Sub
		If VB6.PixelsToTwipsY(Me.Height) < 1500 Then Exit Sub
		txtInput.Left = VB6.TwipsToPixelsX(100)
		txtInput.Width = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - 350)
		txtInput.Height = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - 1300)
		cmdOK.Top = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - VB6.PixelsToTwipsY(cmdOK.Height) - 550)
		cmdCancel.Top = cmdOK.Top
		cmdOK.Left = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) / 2 - VB6.PixelsToTwipsX(cmdOK.Width) - 200)
		cmdCancel.Left = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(cmdOK.Left) + VB6.PixelsToTwipsX(cmdOK.Width) + 200)
		
	End Sub
	
	Private Sub txtInput_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles txtInput.KeyDown
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		On Error Resume Next
		If KeyCode = System.Windows.Forms.Keys.A And (Shift And VB6.ShiftConstants.CtrlMask) Then
			txtInput.SelectionStart = 0
			txtInput.SelectionLength = Len(txtInput.Text)
			Call ScrollToCursor(txtInput)
		ElseIf KeyCode = System.Windows.Forms.Keys.Return And (Shift And VB6.ShiftConstants.CtrlMask) Then 
			Call cmdOK_Click(cmdOK, New System.EventArgs())
		End If
	End Sub
End Class