Option Strict On
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmGoogle
	Inherits System.Windows.Forms.Form
	
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	Private mResults As Collection
	Private mResultURLs As Collection
	Private mSearch As String
	Public targetForm As frmMain
	Private mNextPageHRef As String
	Private mStartAt As Integer
	
	Private Sub cmdAddress_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdAddress.Click

		Dim e As mshtml.IHTMLElement
		Dim childE As mshtml.IHTMLElement
		Dim result As String
        Dim found As Integer
        Dim es As mshtml.IHTMLElementCollection
		
        e = CType(mResults.Item(lstResults.SelectedIndex + 1), mshtml.IHTMLElement)
        es = CType(e, mshtml.IHTMLElementCollection)
        For Each childE In es
            If childE.tagName = "TABLE" Or childE.tagName = "FONT" Then
                result = childE.innerText
                If InStr(1, result, vbNewLine) > 0 Then
                    If VB.Right(result, 1) = "]" Then
                        'Debug.Print "result0: " & result
                        'Debug.Print "right: [" & Right(result, Len(result) - InStrRev(result, vbNewLine))
                        found = InStrRev(result, vbNewLine)
                        found = InStrRev(result, vbNewLine, found - 1)
                        found = found + 1
                        result = VB.Right(result, Len(result) - found)
                        'Debug.Print "result1: " & result
                        result = VB.Left(result, InStr(1, result, vbNewLine))
                    Else
                        result = VB.Right(result, Len(result) - InStrRev(result, vbNewLine))
                    End If
                End If
                If InStr(1, result, " ") > 0 Then
                    result = VB.Left(result, InStr(1, result, " "))
                End If
                MsgBox(result, MsgBoxStyle.OkOnly, modI18N.GetText("Result address"))
                Exit For
            End If
        Next childE
		Call lstResults.Focus()
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click

		Call Me.Hide()
		Call targetForm.Activate()
	End Sub
	
	Private Sub cmdGo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdGo.Click
		On Error GoTo roger
		Dim e As mshtml.IHTMLElement
		Dim childE As mshtml.IHTMLElement
		Dim url As Object
		
		If lstResults.SelectedIndex = lstResults.Items.Count - 1 And Len(mNextPageHRef) > 0 Then
			Call Me.mWebBrowser.Navigate(New System.URI(mNextPageHRef))
		Else
            e = CType(mResults.Item(lstResults.SelectedIndex + 1), mshtml.IHTMLElement)
			If lstResults.SelectedIndex = 0 And e.tagname = "A" Then
				'It's a "Did you mean...?" link
                Call mWebBrowser.Navigate(New System.Uri(e.getAttribute("href").ToString))
			Else
				'Standard result.
				Debug.Print("TAG: !" & e.innerHTML)
                frmMain.cboAddress.Text = mResultURLs.Item(lstResults.SelectedIndex + 1).ToString
				'3.7.4 Changed order: got an odd "Can't navigate" bug from the main form webbrowser,
				'think it might be because it wasn't visible.
				Call Me.Hide()
				Call targetForm.Activate()
				Call frmMain.cmdGo_Click()
			End If
		End If
		Exit Sub
roger: 
		Resume Next
	End Sub
	
	Private Sub cmdInformation_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdInformation.Click

		Dim e As mshtml.IHTMLElement
		Dim childE As mshtml.IHTMLElement
        Dim result As String
        Dim es As mshtml.IHTMLElementCollection
		
        e = CType(mResults.Item(lstResults.SelectedIndex + 1), mshtml.IHTMLElement)
        es = CType(e.children, mshtml.IHTMLElementCollection)
        For Each childE In es
            If childE.tagName = "TABLE" Or childE.tagName = "FONT" Then
                result = childE.innerText
                If InStr(1, result, vbNewLine) > 0 Then
                    If VB.Right(result, 1) = "]" Then
                        result = VB.Left(result, InStrRev(result, vbNewLine, InStrRev(result, vbNewLine) - 1))
                    Else
                        result = VB.Left(result, InStrRev(result, vbNewLine))
                    End If
                End If
                MsgBox(result, MsgBoxStyle.OkOnly, modI18N.GetText("Result information"))
            End If
        Next childE
		Call lstResults.Focus()
	End Sub
	
	Private Sub cmdSearch_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSearch.Click

        Call txtSearch_KeyDown(txtSearch, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.Return))
	End Sub
	
	'UPGRADE_WARNING: Form event frmGoogle.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
	Private Sub frmGoogle_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

		txtSearch.Text = mSearch
		txtSearch.Font = Me.targetForm.txtText.Font
		lstResults.Font = Me.targetForm.txtText.Font
		Me.Text = modI18N.GetText("Websearch")
		'Set focus to one of txtSearch or lstResults
		'UPGRADE_ISSUE: Control name could not be resolved because it was within the generic namespace ActiveControl. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="084D22AD-ECB1-400F-B4C7-418ECEC5E36E"'
		If Me.ActiveControl.Name = "txtSearch" Then
			Call txtSearch.Focus()
			'UPGRADE_ISSUE: Control name could not be resolved because it was within the generic namespace ActiveControl. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="084D22AD-ECB1-400F-B4C7-418ECEC5E36E"'
		ElseIf Me.ActiveControl.Name = "lstResults" Then 
			Call lstResults.Focus()
		Else
			If Len(txtSearch.Text) = 0 Then
				Call txtSearch.Focus()
			Else
				Call lstResults.Focus()
			End If
		End If
	End Sub
	
	'UPGRADE_WARNING: Form event frmGoogle.Deactivate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
	Private Sub frmGoogle_Deactivate(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Deactivate

		mSearch = txtSearch.Text
		Call frmMain.Activate()
	End Sub
	
	Private Sub frmGoogle_GotFocus(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.GotFocus

		If VB6.GetItemString(lstResults, 0) = modI18N.GetText("No results found") Then
			'no results. go to search box
			Call txtSearch.Focus()
		Else
			Call lstResults.Focus()
		End If
	End Sub
	
	Private Sub frmGoogle_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        mWebBrowser.ScriptErrorsSuppressed = True
        mWebBrowser.Left = -100 - mWebBrowser.Width
		mWebBrowser.TabStop = False
		Me.lblSearch.TabIndex = 0
		Me.txtSearch.TabIndex = 1
		Me.lblResults.TabIndex = 2
		Me.lstResults.TabIndex = 3
		Me.lblSearch.TabIndex = 0
		Me.txtSearch.TabIndex = 1
		Me.lblResults.TabIndex = 2
		Me.lstResults.TabIndex = 3
	End Sub
	
	Private Sub frmGoogle_LostFocus(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.LostFocus

		Call Me.Hide()
	End Sub
	
    
	Private Sub frmGoogle_FormClosed(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

		tmrNavigating.Enabled = False
    End Sub
	
	'UPGRADE_WARNING: Event lstResults.SelectedIndexChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub lstResults_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstResults.SelectedIndexChanged

        cmdInformation.Enabled = (mResults.Count() > 0)
		cmdAddress.Enabled = cmdInformation.Enabled
		cmdGo.Enabled = cmdInformation.Enabled
		If Len(mNextPageHRef) > 0 And lstResults.SelectedIndex = lstResults.Items.Count - 1 Then
			cmdInformation.Enabled = False
			cmdAddress.Enabled = False
		End If
	End Sub
	
	Private Sub lstResults_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstResults.Enter

		cmdGo.Enabled = (Not (VB6.GetItemString(lstResults, 0) = modI18N.GetText("No results found"))) And (lstResults.Items.Count > 0)
	End Sub
	
	Private Sub lstResults_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles lstResults.KeyDown
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000
        If KeyCode = System.Windows.Forms.Keys.Return And (mResults.Count() > 0) Then
            Call cmdGo_Click(cmdGo, New System.EventArgs())
        ElseIf KeyCode = System.Windows.Forms.Keys.Up And lstResults.SelectedIndex = 0 Then
            Call Beep()
        ElseIf KeyCode = System.Windows.Forms.Keys.Down And lstResults.SelectedIndex = lstResults.Items.Count - 1 Then
            Call Beep()
        End If
	End Sub
	
    Private Sub tmrNavigating_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrNavigating.Tick

        '3.8.4 Prevent ticking if navigation has stopped for any reason.
        If mWebBrowser.IsBusy Then
            Call PlayWorkingSound()
        Else
            tmrNavigating.Enabled = False
        End If
    End Sub
	
	'UPGRADE_WARNING: Event txtSearch.TextChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub txtSearch_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtSearch.TextChanged

        cmdSearch.Enabled = Len(txtSearch.Text) > 0
	End Sub
	
	Private Sub txtSearch_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtSearch.Enter

		txtSearch.SelectionStart = 0
		txtSearch.SelectionLength = Len(txtSearch.Text)
        cmdSearch.Enabled = Len(txtSearch.Text) > 0
		cmdGo.Enabled = False
	End Sub
	
	Private Sub txtSearch_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000

		Dim terms() As String
		Dim searchString As String
		Dim i As Integer
		
		If KeyCode = System.Windows.Forms.Keys.Return Then
			KeyCode = 0
			mStartAt = 0
			cmdInformation.Enabled = False
			cmdAddress.Enabled = False
			If Len(Replace(txtSearch.Text, " ", "")) > 0 Then
				terms = Split(txtSearch.Text, " ")
				searchString = modI18N.GetText("Search engine:")
				'Make sure default is specified.
				If searchString = "Search engine:" Then searchString = "http://www.google.com/search?q="
				searchString = searchString & terms(LBound(terms))
				For i = LBound(terms) + 1 To UBound(terms)
					searchString = searchString & "+" & terms(i)
				Next i
				Call mWebBrowser.Navigate(New System.URI(searchString))
				tmrNavigating.Enabled = True
			End If
		End If
	End Sub
	
    Private Sub mWebBrowser_DocumentCompleted(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles mWebBrowser.DocumentCompleted
        Dim url As String = eventArgs.Url.ToString()

        Dim e As mshtml.IHTMLElement
        Dim childE As mshtml.IHTMLElement
        Dim es As mshtml.IHTMLElementCollection
        Dim className As String

        Call lstResults.Items.Clear()
        mResults = New Collection
        mResultURLs = New Collection
        mNextPageHRef = ""
        'Debug.Print "Got: " & url
        If mWebBrowser.Document Is Nothing Then
            'didn't get a document
        ElseIf eventArgs.Url.ToString = "http:///" Then
            'Ignore.
        ElseIf eventArgs.Url.ToString = "" Then
            'Ignore
        Else
            For Each e In mWebBrowser.Document.All
                'Debug.Print "className:[" & e.getAttribute("className") & "] tagName:[" & e.tagName & "]"
                'Was tagName = DIV: Google changed November 2006
                If e.tagName = "A" Then
                    If InStr(1, e.getAttribute("href").ToString, "oi=spell") > 0 Then
                        'It's a "Did you mean" link from misspelling. Add it in.
                        Call lstResults.Items.Add(modI18N.GetText("Did you mean:") & " " & e.innerText)
                        Call mResults.Add(e)
                    End If
                End If
                'Debug.Print "ClassName: " & e.getAttribute("className")
                'Google changed August 2008, was e.tagname = "DIV"
                'Jan 2011 changed again.
                className = ""
                className = LCase(e.getAttribute("className").ToString)
                If e.tagName = "H3" And (className = "r" Or VB.Left(className, 2) = "r " Or InStr(1, className, " r ", CompareMethod.Text) > 0 Or VB.Right(className, 2) = " r") Then
                    'If (className = "g" Or (left(className, 2) = "g ") Or right(className, 2) = " g" Or InStr(1, className, " g ") > 0) And e.tagname = "LI" Then
                    'Debug.Print "it:" & e.innerText
                    'Call lstResults.AddItem(e.innerText)
                    Call mResults.Add(e)
                    If InStr(1, e.outerHTML, "24 hours") > 0 Then
                        Debug.Print("!")
                    End If
                    es = CType(e.children, mshtml.IHTMLElementCollection)
                    For Each childE In es
                        If childE.tagName = "A" Then
                            Call lstResults.Items.Add(childE.innerText)
                            Call mResultURLs.Add(childE.getAttribute("href"))
                            'Debug.Print "URL: " & childE.getAttribute("href")
                            Exit For
                        End If
                    Next childE
                    '                    If childE.tagname = "H3" Then
                    '                        If childE.Style.display = "none" Then
                    '                            Debug.Print "OK"
                    '                        Else
                    '                            For Each grandchildE In childE.children
                    '                                If grandchildE.tagname = "A" Then
                    '                                    Call lstResults.AddItem(grandchildE.innerText)
                    '                                End If
                    '                            Next grandchildE
                    '                        End If
                    '                    ElseIf childE.tagname = "TABLE" Or childE.tagname = "FONT" Then
                    '                        info = childE.innerText
                    '                        If InStr(1, info, vbNewLine) > 0 Then
                    '                            If right(info, 1) = "]" Then
                    '                                info = left(info, InStrRev(info, vbNewLine, InStrRev(info, vbNewLine) - 1))
                    '                            Else
                    '                                info = left(info, InStrRev(info, vbNewLine))
                    '                            End If
                    '                            If Len(Trim(info)) > 0 Then
                    '                                lstResults.List(lstResults.ListCount - 1) = lstResults.List(lstResults.ListCount - 1) & " - " & info
                    '                            End If
                    '                        End If
                    '                        linkUrl = childE.innerText
                    '                        If InStr(1, linkUrl, vbNewLine) > 0 Then
                    '                            If right(linkUrl, 1) = "]" Then
                    '                                'Debug.Print "result0: " & result
                    '                                'Debug.Print "right: [" & Right(result, Len(result) - InStrRev(result, vbNewLine))
                    '                                found = InStrRev(linkUrl, vbNewLine)
                    '                                found = InStrRev(linkUrl, vbNewLine, found - 1)
                    '                                found = found + 1
                    '                                linkUrl = right(linkUrl, Len(linkUrl) - found)
                    '                                'Debug.Print "result1: " & result
                    '                                linkUrl = left(linkUrl, InStr(1, linkUrl, vbNewLine))
                    '                            Else
                    '                                linkUrl = right(linkUrl, Len(linkUrl) - InStrRev(linkUrl, vbNewLine))
                    '                            End If
                    '                        End If
                    '                        If InStr(1, linkUrl, " ") > 0 Then
                    '                            linkUrl = left(linkUrl, InStr(1, linkUrl, " "))
                    '                        End If
                    '                        If Len(Trim(linkUrl)) > 0 Then
                    '                            lstResults.List(lstResults.ListCount - 1) = lstResults.List(lstResults.ListCount - 1) & " - " & linkUrl
                    '                        End If
                    '                    End If
                    '                Next childE
                    'Handle next-page link below
                    '            ElseIf e.tagname = "A" And e.children.length > 0 Then
                    '                If e.children(0).getAttribute("classname") = "nn" Then
                    '                    'DEV: this is currently (November 2006) broken, but since
                    '                    'people only look at the first page of results, and it's been
                    '                    'broken for a while, I'm not going to worry about fixing it
                    '                    'since I'm time-pressured.
                    '                        'found the Next link
                    '                        mNextPageHRef = e.getAttribute("href")
                    '                        Call lstResults.AddItem(modI18N.GetText("Next page of results"))
                    '                End If
                End If
            Next e
            If lstResults.Items.Count = 0 Then
                Call lstResults.Items.Add(modI18N.GetText("No results found"))
            Else
                'Work out next-page link.
                '        Set nextLink = pDisp.Document.getElementById("nn")
                '        If nextLink Is Nothing Then
                '        Else
                '            'Found next page link.
                '            Set e = nextLink.parentElement
                '            mNextPageHRef = e.getAttribute("href")
                'UPGRADE_WARNING: Couldn't resolve default property of object url. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                mNextPageHRef = url
                If mStartAt > 0 Then
                    'Take off old "start=" argument
                    mNextPageHRef = Replace(mNextPageHRef, "&start=" & mStartAt, "")
                End If
                mStartAt = mStartAt + 10
                'UPGRADE_WARNING: Couldn't resolve default property of object url. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                mNextPageHRef = url & "&start=" & mStartAt
                Call lstResults.Items.Add(modI18N.GetText("Next page of results"))

                'Update UI
                cmdAddress.Enabled = True
                cmdInformation.Enabled = True
                cmdGo.Enabled = True
            End If
            lstResults.SelectedIndex = 0
            If Me.Visible Then
                Call lstResults.Focus()
            End If
            tmrNavigating.Enabled = False
        End If
    End Sub
	
	Public Sub StartSearch(ByRef terms As String)
		'starts a search from an external call

		mSearch = terms
		txtSearch.Text = terms
		Call Me.Show()
        Call txtSearch_KeyDown(txtSearch, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.Return))
	End Sub
End Class