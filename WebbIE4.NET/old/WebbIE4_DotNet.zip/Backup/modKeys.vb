Option Strict Off
Option Explicit On
Module modKeys
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General private License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General private License for more details.
	'
	'    You should have received a copy of the GNU General private License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	
	
	Private Declare Function GetKeyState Lib "user32" (ByVal vKey As Integer) As Short
	
	Private Const VK_NUMLOCK As Integer = &H90
	Private Const VK_SCROLL As Integer = &H91
	Private Const VK_CAPITAL As Integer = &H14
	Private Const KEYEVENTF_EXTENDEDKEY As Integer = &H1
	Private Const KEYEVENTF_KEYUP As Integer = &H2
	Private Const VER_PLATFORM_WIN32_NT As Short = 2
	Private Const VER_PLATFORM_WIN32_WINDOWS As Short = 1
	Private Const VK_CONTROL As Integer = &H11
	Private Const VK_LCONTROL As Integer = &HA2
	Private Const VK_RCONTROL As Integer = &HA3
	Private Const VK_SHIFT As Integer = &H10
	Private Const VK_LSHIFT As Integer = &HA0
	Private Const VK_RSHIFT As Integer = &HA1
	
	Public Function KeyShiftPressed() As Boolean
		On Error Resume Next
		KeyShiftPressed = (GetKeyState(VK_SHIFT) < 0)
		'Debug.Print "KeyShiftPressed: " & KeyShiftPressed
	End Function
End Module