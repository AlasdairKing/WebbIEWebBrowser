Option Strict On
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmMain
	Inherits System.Windows.Forms.Form
	'WebbIE
	
	'.Net version of WebbIE
	
	'LICENCE
	'This program is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    This program is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with this program.  If not, see <http://www.gnu.or5g/licenses/>.
	
	'"WebbIE" is copyright 2002 Paul Blenkhorn and Gareth Evans, and is released by them under the GNU Public
	'Licence Version 3. A copy is available at http://www.gnu.org/licenses/gpl.txt
	'WebbIE includes code copyright 2002, 2005 Alasdair King, and where this is the case it is also licenced
	'under the GNU Public Licence Version 3.
	'Copyright 2007 Alasdair King.
	
	'Name: Alasdair King alasdair@webbie.org.uk
	
	'4.0 Conversion to .Net
	'       Removed:
	'           Ability to report errors.
	'           Bespoke password/text input forms.
	'           Bespoke font form
	'           Help forms.
	'           Table display.
	'           Bookmarks
    '           External browser
    '           Ability to start a dial-up connection automatically and monitor it.
    '           Display of online status
    '           Any kind of Ajax tracking.

    'FIXED
    '   Working out base url
    '   File upload controls.

    'TODO
    '   Can I lose the Language form? I probably can. See blnAlwaysUseUserDefaultLanguage
    '   Registering WebbIE as the default browser.
    '   Reinstate my cunning mechanism for catching onLoad events and suppressing onError events. maybe http://support.microsoft.com/kb/312777

    Dim DownloadProgressForm As frmDownloadProgress
    Dim GoogleForm As frmGoogle
    Dim LanguageForm As frmLanguage
    Dim LinksForm As frmLinks
    Dim LocationGetterForm As frmLinks
    Dim ParseHTMLHelpForm As frmLinks
    Dim RSSForm As frmLinks
    Dim SelectForm As frmSelect
    Dim TextareaInputForm As frmTextareaInput
    Dim TextViewForm As frmTextView

	'For suppressing JavaScript errors. See http://support.microsoft.com/?kbid=279535
	Private WithEvents objDoc As mshtml.HTMLDocument
    Private WithEvents objWind As mshtml.IHTMLWindow2
    Private objEvent As mshtml.CEventObj

    Private mIgnoreNextKeypress As Boolean ' OK so Narrator (Thunder) has some problems
    '   tracking the cursor when you use a shortcut key to move the cursor like "skip
	'   to heading". Try doing SendKeys to fix it, but don't trigger any commands
	'   by using this as a flag.
	
	Private mNoPageActionSoRefresh As Boolean ' If set, then
	'the user has done something that should result in a
	'change to the page - like clicking a Submit button.
	'Sometimes, however, this doesn't actually trigger a
	'page navigation. If this is the case then you have to
	'do a refresh instead.
	
	Private mForceFollowAddress As Boolean ' If set, you must follow the href for a link, not do a click.
	Private mForceDownloadLink As Boolean ' if set, you must download the file this link points at, not do a click
	
	Private mProcessNextDocumentComplete As Boolean ' exception to the general "process on _onload" rule from 3.11.
	'   If set, we have an internal navigation, so we should start processing on _DocumentComplete instead.
	
    Private Const NUMBER_CHARS_AFTER_LINK_PERMITTED As Integer = 5 ' the number of chars permitted
	Private Const EM_SETMODIFY As Integer = &HB9
	
	Private Declare Function SetFocusAPI Lib "user32" (ByVal hWnd As Integer) As Integer
	
	'Private timing As String
	'Private timingStart As Long
	'Private timingWebBrowserFinished As Long
	'Private timingDisplayFinished As Long
	
	Private mblnJustDidLink As Boolean ' indicates that we've just done a link, so can add a very
	'limited amount of text
	'after a link before a newline is applied.
	Private mstrnewline As String ' whether we've just done a newline in the page
	Public NBSP As String ' the value of the non-breaking space character, unicode 160
    Private mblnGoingBack As Boolean ' used to indicate we're going back
	Private mblnIEVisible As Boolean 'whether we can see IE
	Private mstrCurrentPageFilename As String ' the name we save the current page under
	Private mblnIEFavorites As Boolean ' whether we use the IE websites system or the SimpleBookmarks system
	Private mstrErrorURL As String ' the url for where page errors can be submitted
    Private mobjNavigationRecord As System.Collections.Generic.Dictionary(Of String, Integer) ' stores line numbers of where we've been before
	Private mblnErrorPage As Boolean ' whether there has been an error detected by mWebBrowser
	Private mstrTargetWithID As String ' optional html target e.g. myfile.htm#chapter2
	Private mAlldocs As Collection ' the complete collection of HTML documents (e.g. including frames)
    Private mToolbarVisible As Boolean 'whether we're showing or hiding the toolbar
	Private mHeadingLevel As String ' the tags for the heading level found
	'on the page: we check first that we can find a heading, and if
	'we can, set the heading level to that.
	Private mJustDidHeading As Boolean ' indicates that we've just found the heading for the page.
	'If the following text is a link, we have to handle it a bit differently.
	Private mSeekingInternalTarget As Boolean ' indicates that we are looking for
	'an internal target on this page parse called...
	Private mInternalTarget As String
	Private mControlKeyPressed As Boolean
	Private mShiftKeyPressed As Boolean
	Private mActiveElement As mshtml.IHTMLElement ' For Ajax handling. Keeps track of the active element
	'in the current document.
	Private mElementWithFocus As mshtml.IHTMLElement ' For Ajax handling. Tracks the element that has suddenly
	'   got the focus in IE and should therefore now get the focus in WebbIE.
	Private mSeekingFocusElement As Boolean ' indicates we are looking for an internal target node
	'   on this page: mElementWithFocus in fact.
	Private mHasIFRAMES As Boolean ' indicate that the current top-level element has some IFRAMES in it.
	'   This is important for reparsing when we're trying to handle AJAX pages.
	Private mInternalLinkNavigationStart As Integer ' The line number we started on when we did an internal
	'   link navigation.
	Private mBBCIPlayer As mshtml.IHTMLElement ' the embedded BBC iPlayer Flash object.
	Private mAjaxNodeCount As Integer ' the number of nodes in the body of the document, indicating the
	'   page structure.
	Private mTerminateParsing As Boolean ' if set, stop parsing and present contents of the page. This isn't
	'   very neat, but we do it because of sites like http://www.epoznan.pl/, which fails to stop parsing.
	'   It keeps adding new nodes.
	Private mShowFormsOnly As Boolean ' indicates that only form contents should be parsed and shown.
	Private mInForm As Boolean ' indicates that we are in a form.
    Private Document As Integer ' dummy for capitalization: this variable doesn't
	'do anything in the program, but it stops mWebBrowser.Document becoming
	'mWebBrowser.document, and the latter doesn't work for mWebBrowser_V1 objects
	'received as pDisp arguments - so VB is being case-sensitive. Ugh.
	
	Private mForceNavigation As Boolean ' 3.7.4. Set this to true when a user action has occurred (e.g. a
	'   form submit) that MUST result in a page navigation even though the resultant href indicates that
	'   this is a intra-page (#) link. Try submitting a comment to MetaFilter: the target is .....php/#comment
	'   which looks like an internal link.
	
	'Refresh levels for web browser
	Private Const REFRESH_NORMAL As Integer = 0 ' Perform a lightweight refresh that does not include sending the HTTP "pragma:nocache" header to the server.
	Private Const REFRESH_IFEXPIRED As Integer = 1 ' Perform a lightweight refresh if the page has expired.
	Private Const REFRESH_COMPLETELY As Integer = 3 ' Perform a full refresh that includes sending a "pragma:nocache" header to the server (HTTP URLs only).
	
	Private mNumberLinks As Boolean ' indicates we should (or should not) number links, form elements and so on.
	
    Private Declare Function GetKeyState Lib "user32" (ByVal vKey As Integer) As Integer
	Private Const VK_CONTROL As Integer = &H11
	Private Const VK_SHIFT As Integer = &H10
	
	
	'For getting the temporary folder
	Private Declare Function GetTempPath Lib "kernel32"  Alias "GetTempPathA"(ByVal nBufferLength As Integer, ByVal lpBuffer As String) As Integer
	
	'for images on or off in registry
	Public Enum imageStates
        wbimagesoff = 0
		wbimageson = 1
	End Enum
	
    Private Sub cboAddress_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboAddress.Enter
        'Turn on the Paste and Cut buttons since the cursor is now somewhere where this is allowed
        mnuEditPaste.Enabled = True
        mnuEditCut.Enabled = True
        'Disable txtText tabstop so we get tab press events
        'txtText.TabStop = False '3.11.4 Don't do this, loads of problems have resulted.
    End Sub
	
    Private Sub cboAddress_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboAddress.Leave
        mnuEditPaste.Enabled = False
        mnuEditCut.Enabled = False
        If Not mblnIEVisible Then
            If System.Windows.Forms.Form.ActiveForm.Name = Me.Name Then
                'UPGRADE_ISSUE: Control name could not be resolved because it was within the generic namespace ActiveControl. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="084D22AD-ECB1-400F-B4C7-418ECEC5E36E"'
                If VB6.GetActiveControl().Name = mWebBrowser.Name Then
                    Call cboAddress.Focus()
                End If
            End If
        End If
    End Sub
	
	Friend Sub DoBack()
        Call cmdBack_Click(cmdBack, New System.EventArgs())
    End Sub
	
	Friend Sub DoForward()
        Call cmdForward_Click(cmdForward, New System.EventArgs())
    End Sub
	
    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click
        On Error GoTo cantGoBack
        'Debug.Print "cmdBack"
        Dim lineNumber As Integer
        If cmdBack.Enabled Then
            If mInternalLinkNavigationStart > -1 Then
                'aha, we're trying to do back on an internal link
                Call modAPIFunctions.SetCurrentLineIndex(txtText, mInternalLinkNavigationStart)
                mInternalLinkNavigationStart = -1
            Else
                'Call PlayNavigationStartSound DEV- IE does this already
                tmrBusyAnimation.Enabled = True 'start animation
                'go back
                mblnGoingBack = True
                Call modAccesskeys.ClearAccessKeys()
                'Call gobjBackForwardsHandler.goingBack
                'Get the current line before we navigate - used
                'for back and forward. Used to be in BeforeNavigate, but
                'gets too confusing with all the frames and adverts triggering
                'BeforeNavigate
                'record the line number
                lineNumber = GetCurrentLineIndex(CType(txtText, System.Windows.Forms.TextBox))
                'we often get several  events for a page while it
                'loads (e.g. adverts) and we only want to record the line number when
                'there's actually something on the page, e.g. lineNumber > 1
                If lineNumber > 1 Then
                    'UPGRADE_WARNING: Couldn't resolve default property of object mobjNavigationRecord.Item(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    mobjNavigationRecord.Add(mWebBrowser.Url.ToString(), lineNumber)
                End If
                'Call gobjBackForwardsHandler.NavigationBegin(GetCurrentLineIndex(txtText))

                Call mWebBrowser.GoBack()
            End If
        Else
            Call PlayErrorSound()
        End If
        Exit Sub
cantGoBack:
        'can't go backwards, don't do anything
        Call StopBrowsers()
    End Sub
	
    Private Sub cmdForward_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdForward.Click
        On Error GoTo cantGoForward
        Dim lineNumber As Integer
        'Call PlayNavigationStartSound
        If cmdForward.Enabled Then
            tmrBusyAnimation.Enabled = True
            mblnGoingBack = True
            'Call gobjBackForwardsHandler.goingForwards
            'get the current line before we navigate - used
            'for back and forward. Used to be in BeforeNavigate, but
            'gets too confusing with all the frames and adverts triggering
            'BeforeNavigate
            'record the line number
            lineNumber = GetCurrentLineIndex(txtText)
            'we often get several  events for a page while it
            'loads (e.g. adverts) and we only want to record the line number when
            'there's actually something on the page, e.g. lineNumber > 1
            If lineNumber > 1 Then
                'UPGRADE_WARNING: Couldn't resolve default property of object mobjNavigationRecord.Item(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                mobjNavigationRecord.Add(mWebBrowser.Url.ToString(), lineNumber)
            End If
            'Call gobjBackForwardsHandler.NavigationBegin(GetCurrentLineIndex(txtText))

            Call mWebBrowser.GoForward()
        Else
            Call PlayErrorSound()
        End If
        Exit Sub
cantGoForward:
        'can't go forwards, don't do anything
        Call StopBrowsers()
    End Sub
	
	Public Sub cmdGo_Click()
		'Activate and manage the movement to a new URL
		On Error GoTo Errhandler
		Dim got As String
		
		got = LCase(Trim(cboAddress.Text))
		If got = "" Then Exit Sub ' nowhere to go if the address bar is empty
		'okay, so there is something to get in the address box.
		'If it looks like a url or local file, go get it.
		'Otherwise, start a Google search.
		If got = "home" Then
			'go to home
			Call cmdHome_Click(cmdHome, New System.EventArgs())
		ElseIf InStr(1, got, ".") > 0 Or InStr(1, got, "\") > 0 Or InStr(1, got, "/") > 0 Or InStr(1, got, "about:") > 0 Then 
			'it's a url or local file or config line
            Call StartNavigating(cboAddress.Text) 'navigate to specified address
		Else
			'No idea what this is, do a google search.
			Call frmGoogle.StartSearch((cboAddress.Text))
		End If
		Exit Sub
Errhandler: 'if an error occurs
		'stop trying to navigate
		Call mWebBrowser.Stop()
	End Sub
	
    Private Sub cmdHeading_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdHeading.Click
        Call mnuNavigateGotoheadline_Click(mnuNavigateGotoheadline, New System.EventArgs())
        Call txtText.Focus()
    End Sub
	
    Private Sub cmdHome_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdHome.Click
        Call StartNavigating(gstrCurrentHomepage)
    End Sub
	
    Private Sub cmdMagnify_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdMagnify.Click
        'zoom IE web page
        Call ZoomIE(mAlldocs, 1)
        Call mWebBrowser.Focus()
    End Sub
	
    Private Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRefresh.Click
        On Error GoTo Errhandler1
        'Call StartNavigating(mWebBrowser.LocationURL) ' DEV: is this the best method? Why not use WebBrowser.Refresh at some level?
        'OK, I think it's a pain not to have refresh actually refresh a page.
        'So back to using .Refresh
        'Call mWebBrowser.Refresh2(REFRESH_COMPLETELY) ' use mWebBrowser refresh method at level 0 = normal
        'unless user is pressing the shift key, in which case do complete.
        'Ah, now, the problem is that this doesn't fire the DocumentComplete event! September 2010.
        'So how do I know when the mWebBrowser is ready?
        '   .busy is not true at any point.
        '   .readyState does not shift from READYSTATE_COMPLETE
        'Um, erm.
        Dim doneStatus As String
        Dim i As Integer
        Dim timeNow As Integer

        'This assumes that the status bar is showing "Done" - if it's still navigating it's a problem.
        doneStatus = staMain.Items.Item("txttitle").Text
        If InStr(1, doneStatus, "http:", CompareMethod.Text) > 0 Then doneStatus = "" 'showing a URL, still loading.
        staMain.Items.Item("txttitle").Text = ""
        If modKeys.KeyShiftPressed Then
            Call mWebBrowser.Refresh(WebBrowserRefreshOption.Completely)
        Else
            Call mWebBrowser.Refresh(WebBrowserRefreshOption.Normal)
        End If
        timeNow = GetTickCount
        timeNow = timeNow + 10000
        'Stop when (1) we've got the "Done" message or (2) we're quitting or (3) we've waited 10 seconds.
        While staMain.Items.Item("txttitle").Text <> doneStatus And Not gExiting And doneStatus <> ""
            For i = 0 To 100 : System.Windows.Forms.Application.DoEvents() : Next i
        End While
        If Not gExiting Then
            'Because DocumentComplete never fires, call refresh manually.
            Call RefreshCurrentPage()
        End If
        Exit Sub
Errhandler1:  'if reloading fails, try to use the refresh method - rarely works
        If mWebBrowser.Url.ToString() <> cboAddress.Text Then
            Call mWebBrowser.Navigate(New System.Uri(cboAddress.Text))
        Else
            Call mWebBrowser.Refresh()
        End If
    End Sub
	
	Private Sub cmdShrink_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdShrink.Click
        'zoom IE web page out
        Call ZoomIE(mAlldocs, -1)
        Call mWebBrowser.Focus()
    End Sub
	
    Private Sub cmdSkiplinks_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSkiplinks.Click
        Call SkipLinks(SKIP_DOWN)
        'txtText.TabStop = True ' Don't mess with tabstops.
        Call txtText.Focus()
    End Sub
	
    Private Sub cmdStop_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdStop.Click
        Call StopBrowsers()
    End Sub
	
    Private Sub cmdViewIE_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdViewIE.Click
        'test to see if we have a running external browser
        If mblnIEVisible Then
            'IE visible, hide it
            mWebBrowser.Left = txtText.Width
            mWebBrowser.Width = 100
            mWebBrowser.Top = txtText.Top
            mWebBrowser.Height = 100
            mWebBrowser.TabStop = False
            If mnuOptionsToolbarcaptions.Checked Then
                cmdViewIE.Text = modI18N.GetText("View webpage")
            End If
            cmdSkiplinks.Visible = True
            cmdHeading.Visible = True
            cmdMagnify.Visible = False
            cmdShrink.Visible = False
            mnuViewMagnify.Enabled = False
            mnuViewShrink.Enabled = False
            mnuViewIE.Text = modI18N.GetText("View &webpage")
            mblnIEVisible = False
            'Call SetImagesOnOrOffInIE(False)
            txtText.TabStop = True
            Call txtText.BringToFront()
            Call txtText.Focus()
            'enable now relevant menu items
            mnuNavigateGotoform.Enabled = True
            mnuNavigateGotoheadline.Enabled = True
        Else
            'IE invisible, show it
            mWebBrowser.Left = txtText.Left
            mWebBrowser.Width = txtText.Width
            mWebBrowser.Top = txtText.Top
            mWebBrowser.Height = txtText.Height
            mWebBrowser.TabStop = True
            If mnuOptionsToolbarcaptions.Checked Then
                cmdViewIE.Text = modI18N.GetText("Hide webpage")
            End If
            cmdSkiplinks.Visible = False
            cmdHeading.Visible = False
#If Panel = 0 Then
            cmdMagnify.Visible = True
            cmdShrink.Visible = True
#End If
            mnuViewMagnify.Enabled = True
            mnuViewShrink.Enabled = False
            mnuViewIE.Text = modI18N.GetText("Hide &webpage")
            mblnIEVisible = True
            txtText.TabStop = False
            'disable irrelevant menu items
            mnuNavigateGotoform.Enabled = False
            mnuNavigateGotoheadline.Enabled = False
            Call mWebBrowser.BringToFront()
            Call mWebBrowser.Focus()
        End If
    End Sub
	
	Private Sub frmMain_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        Dim KeyAscii As Integer = Asc(eventArgs.KeyChar)
		If mIgnoreNextKeypress Then
			KeyAscii = 0
			GoTo EventExitSub
		End If
EventExitSub: 
		eventArgs.KeyChar = Chr(KeyAscii)
		If KeyAscii = 0 Then
			eventArgs.Handled = True
		End If
	End Sub
	
	Public Sub mnuLinksDownloadlink_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuLinksDownloadlink.Click
		mForceDownloadLink = True
		Call txtText_KeyPress(txtText, New System.Windows.Forms.KeyPressEventArgs(Chr(System.Windows.Forms.Keys.Return)))
		mForceDownloadLink = False
	End Sub
	
	Public Sub mnuOptionsUsefavouritesforhomepage_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsUsefavouritesforhomepage.Click
        mnuOptionsUsefavouritesforhomepage.Checked = Not mnuOptionsUsefavouritesforhomepage.Checked
    End Sub
	
	Public Sub mnuViewMagnify_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewMagnify.Click
        Call cmdMagnify_Click(cmdMagnify, New System.EventArgs())
    End Sub
	
	Private Sub frmMain_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000
		'process user keypresses by calling the appropriate GUI component
		Dim ctrlDown As Boolean 'control is pressed
		Dim altDown As Boolean ' alt is pressed
		Dim shiftDown As Boolean
		Dim quickKeysOn As Boolean
		Dim line As Integer
		
		If mIgnoreNextKeypress Then
			KeyCode = 0
			Exit Sub
		End If
		'UPGRADE_ISSUE: Control name could not be resolved because it was within the generic namespace ActiveControl. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="084D22AD-ECB1-400F-B4C7-418ECEC5E36E"'
		quickKeysOn = (mnuOptionsUsequickkeys.Checked And Not Me.ActiveControl.Name = "cboAddress")
		ctrlDown = ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Or quickKeysOn
		altDown = (Shift And VB6.ShiftConstants.AltMask) > 0
		shiftDown = (Shift And VB6.ShiftConstants.ShiftMask) > 0
		Select Case KeyCode
			Case Is = System.Windows.Forms.Keys.Escape ' Stop loading
				If cmdStop.Enabled Then
					Call cmdStop_Click(cmdStop, New System.EventArgs())
				Else
					'Are we at the top of the text area?
					line = GetCurrentLineIndex(txtText)
					If line > 0 Then
						'Nope, set cursor to first line (so the user gets the page title)
						'Is this not really annoying? One presses Escape
						'a lot, and you can get yourself hopping back to
						'the top of the page when you don't mean to.
						txtText.SelectionStart = 0
						txtText.SelectionLength = 0
						'Don't select - stops screenreaders reading line, they read the document instead.
						'Call SelectCurrentParagraph
					Else
						'Set focus on url/address bar (3.10)
						Call cboAddress.Focus()
					End If
				End If
				KeyCode = 0
			Case Is = System.Windows.Forms.Keys.F7
				'goto headline
				KeyCode = 0
				Call mnuNavigateGotoheadline_Click(mnuNavigateGotoheadline, New System.EventArgs())
			Case Is = System.Windows.Forms.Keys.D ' address bar
				If ctrlDown Then
					Call cboAddress.Focus()
				End If
			Case Is = System.Windows.Forms.Keys.Back ' Go back
				'check it isn't in the address field
				'UPGRADE_ISSUE: Control name could not be resolved because it was within the generic namespace ActiveControl. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="084D22AD-ECB1-400F-B4C7-418ECEC5E36E"'
				If Me.ActiveControl.Name <> cboAddress.Name Then
					Call cmdBack_Click(cmdBack, New System.EventArgs())
					KeyCode = 0
				End If
			Case Is = System.Windows.Forms.Keys.Right ' Go forward (with ALT)
				If altDown Then
					cmdForward_Click(cmdForward, New System.EventArgs())
					KeyCode = 0
				End If
			Case Is = System.Windows.Forms.Keys.Left ' Go back (with ALT)
				If altDown Then
					cmdBack_Click(cmdBack, New System.EventArgs())
					KeyCode = 0
				End If
			Case Is = System.Windows.Forms.Keys.F5 ' Refresh
				cmdRefresh_Click(cmdRefresh, New System.EventArgs())
				KeyCode = 0
			Case Is = System.Windows.Forms.Keys.Home ' Home (with ALT)
				If altDown And ctrlDown And Not (mnuOptionsUsequickkeys.Checked) Then
					Call mnuOptionsSethome_Click(mnuOptionsSethome, New System.EventArgs())
					KeyCode = 0
				ElseIf altDown Then 
					cmdHome_Click(cmdHome, New System.EventArgs())
					KeyCode = 0
				End If
			Case Is = System.Windows.Forms.Keys.H ' next headline
				If ctrlDown Or quickKeysOn Then
					KeyCode = 0
					Call mnuNavigateGotoheadline_Click(mnuNavigateGotoheadline, New System.EventArgs())
				End If
				
				'DEV: can't hard-code access keys - doesn't allow for I18N
				'        Case Is = vbKeyD ' in case the access key doesn't work
				'            If altDown Then
				'                Call cboAddress.SetFocus
				'                KeyCode = 0
				'            End If
				'        Case Is = vbKeyT 'in case the access key doesn't work
				'            If altDown Then
				'                Call txtText.SetFocus
				'                KeyCode = 0
				'            End If
			Case Is = System.Windows.Forms.Keys.W ' for Google search
				If ctrlDown Then
					KeyCode = 0
					Call mnuEditWebsearch_Click(mnuEditWebsearch, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.I ' for save image
				If shiftDown And ctrlDown Then
					KeyCode = 0
					Call SaveImage()
				ElseIf ctrlDown Then 
					KeyCode = 0
					Call mnuViewIE_Click(mnuViewIE, New System.EventArgs())
				End If
				'We now have a bunch of shortcuts specifically for when are in QuickLinks
				'mode, that is, when users can hit a single character to operate a function.
			Case Is = System.Windows.Forms.Keys.S 'for skip down
				If quickKeysOn Then
					KeyCode = 0
					Call mnuLinksSkiplinks_Click(mnuLinksSkiplinks, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.A ' select all
				If quickKeysOn Then
					KeyCode = 0
					Call mnuEditSelectall_Click(mnuEditSelectall, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.C ' copy
				If quickKeysOn Then
					KeyCode = 0
					Call mnuEditCopy_Click(mnuEditCopy, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.X ' cut
				If quickKeysOn Then
					KeyCode = 0
					Call mnuEditCut_Click(mnuEditCut, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.V ' paste
				If quickKeysOn Then
					KeyCode = 0
					Call mnuEditPaste_Click(mnuEditPaste, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.U ' for skip up
				If quickKeysOn Then
					KeyCode = 0
					Call mnuLinksSkipup_Click(mnuLinksSkipup, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.K ' crop
				If quickKeysOn Then
					KeyCode = 0
					Call mnuViewCroppage_Click(mnuViewCroppage, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.R ' refresh
				If quickKeysOn Or ctrlDown Then ' Need also ctrlDown to handle Ctrl+Shift+R
					KeyCode = 0
					Call mnuNavigateRefresh_Click(mnuNavigateRefresh, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.E ' rss
				If quickKeysOn Then
					KeyCode = 0
					Call mnuViewRSSNewsFeed_Click(mnuViewRSSNewsFeed, New System.EventArgs())
				End If
			Case Is = System.Windows.Forms.Keys.F6
				If shiftDown Then
					KeyCode = 0
					Call SkipToFormElement(-1)
				End If
		End Select
		'Don't do this messing with tabstop. 3.11.4.
		'    If KeyCode <> 0 And KeyCode <> vbKeyShift Then
		'        cboAddress.TabStop = True
		'    End If

	End Sub
	
	Private Sub frmMain_KeyUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000
		If mIgnoreNextKeypress Then
			KeyCode = 0
			Exit Sub
		End If
		'popup help
		If KeyCode = System.Windows.Forms.Keys.F1 Then
			Call modPopupHelp.popupHelp(Me.Name, Me.ActiveControl)
		End If
		'cboAddress.TabStop = False Don't do this! 3.11.3. LOADS of problems with tabbing and the
		'WebbIE interface now.
	End Sub
	
	Public Sub mnuHelpCheck_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuHelpCheck.Click
        Call Shell(My.Application.Info.DirectoryPath & "\WiseUpdt.exe")
    End Sub
	
	Public Sub mnuLinksFollowlinkaddress_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuLinksFollowlinkaddress.Click
        mForceFollowAddress = True
        Call txtText_KeyPress(txtText, New System.Windows.Forms.KeyPressEventArgs(Chr(System.Windows.Forms.Keys.Return)))
        mForceFollowAddress = False
    End Sub
	
    Public Sub mnuOptionsAllowajax_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsAllowajax.Click
        mnuOptionsAllowajax.Checked = Not mnuOptionsAllowajax.Checked
        tmrAjax.Enabled = mnuOptionsAllowajax.Checked
    End Sub
	
	Public Sub mnuOptionsAlwaysstartintextview_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsAlwaysstartintextview.Click
        mnuOptionsAlwaysstartintextview.Checked = Not mnuOptionsAlwaysstartintextview.Checked
    End Sub
	
	Public Sub mnuOptionsFetchPDFfromGoogle_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsFetchPDFfromGoogle.Click
        mnuOptionsFetchPDFfromGoogle.Checked = Not mnuOptionsFetchPDFfromGoogle.Checked
    End Sub
	
	Public Sub mnuOptionsInvertcolours_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsInvertcolours.Click
        'Assumes that the default is black on white
        mnuOptionsInvertcolours.Checked = Not mnuOptionsInvertcolours.Checked
        Call InvertColours((mnuOptionsInvertcolours.Checked))
    End Sub
	
	Private Sub InvertColours(ByRef invert As Boolean)
        'inverts the colours in the text areas. 
        'TODO 
    End Sub
	
	Public Sub mnuOptionsJavascriptonlyitems_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsJavascriptonlyitems.Click
        Me.mnuOptionsJavascriptonlyitems.Checked = Not Me.mnuOptionsJavascriptonlyitems.Checked
        Call RefreshCurrentPage()
    End Sub
	
	Public Sub mnuOptionsLanguageoptions_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsLanguageoptions.Click
        Call VB6.ShowForm(frmLanguage, VB6.FormShowConstants.Modal, Me)
    End Sub
	
	'Private Sub mnuOptionsLanguageselect_Click(index As Integer)
    '    
    '    Select Case index
    '        Case 0 ' Czech
    '            modI18N.language = "cz"
    '        Case 1 ' English (UK)
    '            modI18N.language = "en-gb"
    '        Case 2 ' Spanish
    '            modI18N.language = "es"
    '        Case 3 ' French
    '            modI18N.language = "fr"
    '        Case 4 ' Dutch
    '            modI18N.language = "nl"
    '        Case 5 ' Polish
    '            modI18N.language = "pl"
    '        Case 6 ' Finnish
    '            modI18N.language = "fi"
    '        Case 7 ' Russian
    '            modI18N.language = "ru"
    '        Case 8 ' German
    '            modI18N.language = "de"
    '        Case 9 ' Greek
    '            modI18N.language = "gr"
    '    End Select
    '    Call modI18N.ApplyUILanguageToAllForms
    '    'do WebbIE page elements and other global strings
    '    Call modGlobals.Initialise
    '    Call ResizeToolbar
    '    Call Form_Resize
    'End Sub

    Public Sub mnuOptionsMadedefault_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsMadedefault.Click
        Call Shell(My.Application.Info.DirectoryPath & "\WebbIEMakeDefaultBrowser.exe -reinstall")
    End Sub

    Public Sub mnuOptionsNavigationsounds_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsNavigationsounds.Click
        mnuOptionsNavigationsounds.Checked = Not mnuOptionsNavigationsounds.Checked
    End Sub

    Public Sub mnuOptionsNumberlinksandotheritems_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsNumberlinksandotheritems.Click
        mnuOptionsNumberlinksandotheritems.Checked = Not mnuOptionsNumberlinksandotheritems.Checked
        mNumberLinks = mnuOptionsNumberlinksandotheritems.Checked
        Call ParseDocument()
    End Sub

    Public Sub mnuOptionsToolbarcaptions_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsToolbarcaptions.Click
        mnuOptionsToolbarcaptions.Checked = Not mnuOptionsToolbarcaptions.Checked
        Call LoadToolbarCaptionsAndResizeToolbar()
        Call frmMain_Resize(Me, New System.EventArgs())
    End Sub

    Private Sub LoadToolbarCaptionsAndResizeToolbar()
        '    MsgBox "Resizing: " & modi18n.GetText("frmMain.cmdBack.Caption")
        cmdBack.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdBack.Caption"), "").ToString
        cmdBack.Height = CType(VB6.TwipsToPixelsY(CType(IIf(mnuOptionsToolbarcaptions.Checked, 1215, 975), Double)), Integer)
        cmdBack.Width = CType(VB6.TwipsToPixelsX(CType(IIf(mnuOptionsToolbarcaptions.Checked, 1455, 975), Double)), Integer)
        cmdForward.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdForward.Caption"), "").ToString
        cmdForward.Height = cmdBack.Height
        cmdForward.Width = cmdBack.Width
        cmdStop.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdStop.Caption"), "").ToString
        cmdStop.Height = cmdBack.Height
        cmdStop.Width = cmdBack.Width
        cmdHome.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdHome.Caption"), "").ToString
        cmdHome.Width = cmdBack.Width
        cmdHome.Height = cmdBack.Height
        cmdRefresh.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdRefresh.Caption"), "").ToString
        cmdRefresh.Width = cmdBack.Width
        cmdRefresh.Height = cmdBack.Height
        cmdViewIE.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdViewIE.Caption"), "").ToString
        cmdViewIE.Height = cmdBack.Height
        cmdViewIE.Width = cmdBack.Width
        cmdSkiplinks.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdSkiplinks.Caption"), "").ToString
        cmdSkiplinks.Width = cmdBack.Width
        cmdSkiplinks.Height = cmdBack.Height
        cmdHeading.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdHeading.Caption"), "").ToString
        'Handle missing I18N
        If cmdHeading.Text = "frmMain.cmdHeading.Caption" Then cmdHeading.Text = "Heading"
        cmdHeading.Width = cmdBack.Width
        cmdHeading.Height = cmdBack.Height
        cmdMagnify.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdMagnify.Caption"), "").ToString
        'Handle missing I18N
        If cmdMagnify.Text = "frmMain.cmdMagnify.Caption" Then cmdMagnify.Text = "Magnify"
        cmdMagnify.Height = cmdBack.Height
        cmdMagnify.Width = cmdBack.Width
        cmdShrink.Width = cmdBack.Width
        cmdShrink.Height = cmdBack.Height
        cmdShrink.Text = IIf(mnuOptionsToolbarcaptions.Checked, modI18N.GetText("frmMain.cmdShrink.Caption"), "").ToString
        'Handle missing I18N
        If cmdShrink.Text = "frmMain.cmdShrink.Caption" Then cmdShrink.Text = "Shrink"
        fraToolBar.Height = cmdBack.Height
        If mnuOptionsToolbarcaptions.Checked Then
            Call fraBusy.BringToFront()
        Else
            Call fraBusySmall.BringToFront()
        End If
    End Sub

    Public Sub mnuOptionsUsequickkeys_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsUsequickkeys.Click
        mnuOptionsUsequickkeys.Checked = Not mnuOptionsUsequickkeys.Checked
    End Sub

    Public Sub mnuViewLinkinformation_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewLinkinformation.Click
        Call txtText_KeyDown(txtText, New System.Windows.Forms.KeyEventArgs(System.Windows.Forms.Keys.F8))
    End Sub

    Public Sub mnuViewReadability_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewReadability.Click
        'UPGRADE_WARNING: Navigate2 was upgraded to Navigate and has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
        mWebBrowser.Navigate(New System.Uri(("" & "javascript:(function(){readConvertLinksToFootnotes=false;readStyle='style-apertura';readSize='size-medium';readMargin='margin-wide';_readability_script=document.createElement('SCRIPT');_readability_script.type='text/javascript';_readability_script.src='http://lab.arc90.com/experiments/readability/js/readability.js?x='+(Math.random());document.getElementsByTagName('head')[0].appendChild(_readability_script);_readability_css=document.createElement('LINK');_readability_css.rel='stylesheet';_readability_css.href='http://lab.arc90.com/experiments/readability/css/readability.css';_readability_css.type='text/css';_readability_css.media='all';document.getElementsByTagName('head')[0].appendChild(_readability_css);_readability_print_css=document.createElement('LINK');_readability_print_css.rel='stylesheet';_readability_print_css.href='http://lab.arc90.com/experiments/readability/css/readability-print.css';_readability_print_css.media='print';_readability_print_css.type='text/css';" & "document.getElementsByTagName('head')[0].appendChild(_readability_print_css);})();")))
    End Sub

    Public Sub mnuViewRSSNewsFeed_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewRSSNewsFeed.Click
        Call frmRSS.Show()
    End Sub

    Public Sub mnuViewShrink_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewShrink.Click
        Call cmdShrink_Click(cmdShrink, New System.EventArgs())
    End Sub

    Public Sub mnuViewViewforms_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewViewforms.Click
        mShowFormsOnly = Not mShowFormsOnly
        Call ParseDocument()
    End Sub

    Private Sub mWebBrowser_CanGoBackChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles mWebBrowser.CanGoBackChanged
        cmdBack.Enabled = mWebBrowser.CanGoBack
        mnuNavigateBack.Enabled = mWebBrowser.CanGoBack
    End Sub

    Private Sub mWebBrowser_Navigated(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.WebBrowserNavigatedEventArgs) Handles mWebBrowser.Navigated
        Dim url As String = eventArgs.Url.ToString()

        objDoc = CType(mWebBrowser.Document.DomDocument, mshtml.HTMLDocument)
        objWind = CType(objDoc.parentWindow, mshtml.IHTMLWindow2)
    End Sub

    'Private Function objDoc_onerrorupdate() As Boolean
    '	
    '	'Script error?
    '	If objWind.event Is Nothing Then
    '		Debug.Print("document error update!")
    '	Else
    '		Debug.Print("document error: " & objWind.event.reason)
    '	End If
    'End Function

    'Private Sub objWind_onerror(ByVal description As String, ByVal url As String, ByVal line As Integer) Handles objWind.onerror
    '	
    '	'Trap and prevent script errors. See http://support.microsoft.com/?kbid=279535.
    '	'3.11.0
    '	objEvent = objWind.event
    '	objEvent.returnValue = True
    '	'    Debug.Print "Script error: " & description
    '	'MsgBox (description) Displays the script error.
    'End Sub


    'Private Sub objWind_onload() Handles objWind
    '    'Debug.Print "OnLoad! " & mWebBrowser.LocationURL & " " & mWebBrowser.readyState
    '    If mWebBrowser.Url.ToString() <> "http:///" Then
    '        tmrProcessAfterLoad.Enabled = True
    '    End If
    'End Sub



    Private Sub tmrAjax_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrAjax.Tick
        'check for non-navigation page changes, like in FaceBook or Google Mail.
        'TODO Ajax tracking.
        'On Error GoTo ExitAjax
        '		Dim pageLength As Integer
        '		Dim displayLength As Integer
        '		Static forcedReload As Integer
        '		Dim nodeCount As Integer

        '		Exit Sub ' 3.14.1. I'm not sure this is a good approach because the new page-access
        '		'mechanism may lead to the incorrect detection of page contents wrongly and any form
        '		'usage may change the active
        '		'element and I'm not aware of anywhere it helps. So pull it for now.

        '		If Me.mnuOptionsAllowajax.Checked Then
        '			If mWebBrowser.IsBusy Then
        '				'UPGRADE_NOTE: Object mActiveElement may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        '				mActiveElement = Nothing
        '			Else
        '				If (mWebBrowser.Document.DomDocument Is Nothing) Then
        '					'UPGRADE_NOTE: Object mActiveElement may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        '					mActiveElement = Nothing
        '				Else
        '					'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.activeElement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '					If mWebBrowser.Document.DomDocument.activeElement Is Nothing Then
        '						'UPGRADE_NOTE: Object mActiveElement may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        '						mActiveElement = Nothing
        '					Else
        '						'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.activeElement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '						If Not (mActiveElement Is mWebBrowser.Document.DomDocument.activeElement) Then
        '							'Change in element with focus, trigger refresh
        '							'                    Call PlayAjaxSound
        '							'                    Set mActiveElement = mWebBrowser.Document.activeElement
        '							'                    Set mElementWithFocus = mActiveElement
        '							'                    mSeekingFocusElement = True
        '							'                    Call RefreshCurrentPage
        '						ElseIf Not mblnIEVisible Then 
        '							''                        'we haven't triggered a refresh because of active element changing,
        '							''                        'see if we have a change because of page length. Only do this if we're
        '							''                        'looking at the text view.
        '							'DEV: seriously, comparing .innerText to the length of my parsing? What about
        '							'crop page? Dumb.
        '							''                        pageLength = Len(mWebBrowser.Document.body.innerText)
        '							''                        displayLength = Len(txtText.Text)
        '							''                        'Debug.Print "Page: " & pageLength & " Display: " & displayLength
        '							''                        If pageLength < displayLength * 0.5 Or pageLength > displayLength * 2 Then
        '							''                            '... but only once.
        '							''                            If pageLength < forcedReload - 100 Or pageLength > forcedReload + 100 Then
        '							''                                'Debug.Print "Triggered refresh from page length"
        '							''                                forcedReload = pageLength
        '							''                                Call PlayAjaxSound
        '							''                                Call RefreshCurrentPage
        '							''                            End If

        '							'If CDate(mWebBrowser.Document.lastModified) <> mMainDocumentLastModified Then
        '							'Oh look, the page has been updated by script or form!
        '							'DEV: Nope, this completely doesn't work. It works for the first page loaded,
        '							'but not for subsequent pages. Scrap. (This was only tried in a beta in Sep 2009,
        '							'and reports came in that it kept refreshing - true.)
        '							'Update global so we don't end up here again.
        '							'mMainDocumentLastModified = mWebBrowser.Document.lastModified
        '							'Call PlayAjaxSound
        '							'Call RefreshCurrentPage
        '							'Else
        '							'Okay, instead check for the number of nodes
        '							'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.body. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '							If mWebBrowser.Document.DomDocument.body.All.length = mAjaxNodeCount Or mAjaxNodeCount <> -1 Then
        '								'OK, still fine.
        '							Else
        '								'Debug.Print "Triggered refresh from node count"
        '								Call PlayAjaxSound()
        '								Call RefreshCurrentPage()
        '								'OK, this has triggered a refresh. Update so this value doesn't trigger again.
        '								'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.body. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '								mAjaxNodeCount = mWebBrowser.Document.DomDocument.body.All.length
        '							End If
        '							'End If
        '						End If
        '					End If
        '				End If
        '			End If
        '		Else
        '			tmrAjax.Enabled = False
        '		End If
        'ExitAjax: 

        '		'    
        '		'    Static busy As Boolean
        '		'    Static oldText As String
        '		'    Static url As String
        '		'    Dim oldPos As Long
        '		'
        '		'    If busy Then
        '		'    Else
        '		'        busy = True
        '		'        If url <> mWebBrowser.LocationURL Then
        '		'            url = mWebBrowser.LocationURL
        '		'            oldText = Empty
        '		'        ElseIf mWebBrowser.busy Then
        '		'            'navigating, don't do anything
        '		'            oldText = Empty
        '		'        ElseIf oldText = Empty Then
        '		'            oldText = mWebBrowser.Document.body.innerText
        '		'        Else
        '		'            If oldText <> mWebBrowser.Document.body.innerText Then
        '		'                'change in page has occurred
        '		'                staMain.Panels("txtbusy").text = "Updating page change..."
        '		'                oldPos = txtText.selStart
        '		'                Call ClearPageData
        '		'                Call ParseDocument
        '		'                txtText.selStart = oldPos
        '		'                oldText = mWebBrowser.Document.body.innerText
        '		'            End If
        '		'        End If
        '		'        busy = False
        '		'    End If
    End Sub

    Private Sub tmrDoUpDownKeys_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrDoUpDownKeys.Tick
        Dim i As Integer

        tmrDoUpDownKeys.Enabled = False
        Call System.Windows.Forms.SendKeys.Send("{DOWN}")
        For i = 1 To 100 : System.Windows.Forms.Application.DoEvents() : Next i
        Call System.Windows.Forms.SendKeys.Send("{UP}")
        For i = 1 To 100 : System.Windows.Forms.Application.DoEvents() : Next i
        mIgnoreNextKeypress = False
    End Sub

    Private Sub tmrProcessAfterLoad_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrProcessAfterLoad.Tick
        'Try taking processing out of WebBrowser DocumentComplete event.

        Static busy As Boolean
        Dim lineNumber As Integer
        tmrProcessAfterLoad.Enabled = False

        If busy Then
        Else
            busy = True
            Call ProcessPage()

            'Do zooming
            Call ZoomIE(mAlldocs, 0)

            'Right, we've just finished loading and displaying a page. Now, where
            'do we put the caret? Two factors:
            ' - there is an internal target to which we should move the caret
            ' - if we've gone forwards or backwards, put the caret where it was
            'You could go f/b to a page with an internal target, but you
            'should go to where the caret was, not where the target indicates.
            'So check f/b first.
            If mobjNavigationRecord.ContainsKey(mWebBrowser.Url.ToString()) Then
                'found an entry for this page.
                lineNumber = mobjNavigationRecord.Item(mWebBrowser.Url.ToString())
            End If
            If lineNumber > 0 Then
                'okay, we have to go somewhere
                'Debug.Print "Decided to put caret at line:" & lineNumber
                txtText.SelectionStart = GetCharacterIndexOfLine(txtText, lineNumber)
                txtText.SelectionLength = 0
            Else
                'not gone back/forwards: try going to internal link
                Call MoveCursorToInternalTarget()
                'Call modInternalTargets.MoveCursorToInternalLink(Me)
            End If
            busy = False
        End If
    End Sub

    Private Sub tmrRefreshIfNotChange_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrRefreshIfNotChange.Tick

        tmrRefreshIfNotChange.Enabled = False
        If gExiting Then
        ElseIf mNoPageActionSoRefresh Then
            mNoPageActionSoRefresh = False
            Debug.Print("Triggered refresh!")
            Call RefreshCurrentPage()
            Call PlayDoneSound()
        End If
    End Sub

    Private Sub tmrSetFocus_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrSetFocus.Tick

        tmrSetFocus.Enabled = False
        'log "tmrSetFocus_Timer"
        Call txtText.Focus()
    End Sub

    Private Sub tmrStartNavigating_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrStartNavigating.Tick

        tmrStartNavigating.Enabled = False
        Call cmdGo_Click()
    End Sub

    Private Sub workBrowser_DocumentCompleted(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles workBrowser.DocumentCompleted
        Dim url As String = eventArgs.Url.ToString()
        'an image or other binary file has downloaded and needs to be saved to disk
        'OR the user has logged a problem with the WebbIE website

        'UPGRADE_WARNING: Couldn't resolve default property of object url. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        If url = "" Or url = "http://" Then
        Else
            If workBrowser.ReadyState = System.Windows.Forms.WebBrowserReadyState.Complete Then
                If workBrowser.Url.ToString() = "http:///" Then
                    'this is the location url when the object is started up when
                    'Visual Studio is opened. If you don't handle this sit  uation
                    '- that is, if you don't allow for this firing when WebbIE
                    'starts up -
                    'you have to delete and replace the WebBrowser control on the
                    'form every time you open Visual Studio. Don't know why.
                ElseIf workBrowser.Url.ToString() = "" Then
                    'haven't gone anywhere: don't do anything
                ElseIf InStr(1, workBrowser.Url.ToString(), "http://www.aljo.org.uk/cgi") = 1 Then
                    'we were using the work browser to report a webbie error: don't do anything
                ElseIf InStr(1, workBrowser.Url.ToString(), "webbieprint.htm", CompareMethod.Text) > 0 Then
                    'we are trying to print the textbox contents
                    'UPGRADE_WARNING: Couldn't resolve default property of object workBrowser.Document.execCommand. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    Dim doc As HtmlDocument
                    doc = workBrowser.Document
                    Call doc.ExecCommand("print", False, "")
                    'DEV: Not sure what this was deleting, but we shouldn't be deleting
                    'things (or creating them) in the Program Folder anyway, so commented
                    'these out (29 Nov 2006)
                    'Dim fso As New FileSystemObject
                    'Call fso.DeleteFile(modPath.applicationPath & "\temp.htm")
                Else
                    'we have none of an HTML file, and we're not reporting an error:
                    'assume this is an image, and save it.
                    'UPGRADE_WARNING: Couldn't resolve default property of object workBrowser.Document.execCommand. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    Dim doc As HtmlDocument
                    doc = workBrowser.Document
                    Call doc.ExecCommand("saveas", False, "")
                End If
            End If
        End If
    End Sub

    Public Sub mnuHelpWebbiehome_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuHelpWebbiehome.Click
        'go to home for webbie - website

        cboAddress.Text = modI18N.GetText("http://www.webbie.org.uk")
        Call cmdGo_Click()
    End Sub

    Public Sub mnuOptionsHideToolbar_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsHideToolbar.Click

        'Toggles the toolbar visible and invisible.
        If mToolbarVisible Then
            'make it invisible
            mToolbarVisible = False
            mnuOptionsHideToolbar.Text = modI18N.GetText("Show &Toolbar")
        Else
            'make toolbar visible
            mToolbarVisible = True
            mnuOptionsHideToolbar.Text = modI18N.GetText("Hide &Toolbar")
        End If
        Call frmMain_Resize(Me, New System.EventArgs())
    End Sub

    Public Sub mnuNavigateGotoheadline_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuNavigateGotoheadline.Click
        'move cursor to the headline

        Dim direction As Integer

        If GetKeyState(VK_SHIFT) < 0 Then
            'PRessing shift, go backwards
            direction = -1
        Else
            direction = 1
        End If
        If GotoLineStarting(SECTION_MARKER_COMMON, direction, False) Then
            'Don't select - stops screenreaders reading line, they read the document instead.
            'Call SelectCurrentParagraph
            'okay, this will have selected the paragraph starting "Page Headline:". But
            'what if the headline is the next line as well? Happens with links.
            'Well, then, select the next line
            '        If Len(txtText.SelText) < Len(SECTION_MARKER_H1) + 10 Then
            '            nextLine = txtText.selStart + txtText.SelLength + Len(vbNewLine)
            '            nextLine = InStr(nextLine, txtText.Text, vbNewLine)
            '            If nextLine > 0 Then
            '                'found new end-of-line
            '                txtText.SelLength = nextLine - txtText.selStart
            '            End If
            '        End If
        End If
    End Sub

    Private Function GotoLineStarting(ByRef startsWith As String, Optional ByRef direction As Integer = 1, Optional ByRef wrap As Boolean = True) As Boolean
        'moves cursor to line beginning with startsWith. Returns true if found.

        Dim numberLines As Integer
        Dim i As Integer
        Dim lineContent As String
        Dim found As Boolean
        Dim currentLine As Integer

        numberLines = GetNumberOfLines(txtText)
        currentLine = GetCurrentLineIndex(txtText)
        Debug.Print("STart: " & currentLine)
        i = currentLine + direction
        'Debug.Print "Line: " & i
        While i >= 0 And i < numberLines And (Not found)
            lineContent = GetNumberedLine(txtText, i)
            If InStr(1, lineContent, startsWith, CompareMethod.Text) = 1 Then
                'found it
                Debug.Print("Found")
                found = True
                txtText.SelectionStart = GetCharacterIndexOfLine(txtText, i)
                txtText.SelectionLength = 0
                'Call ScrollToCursor(txtText)
                'Call PlayDoneSound ' Don't play the done sound, it's really intrusive. Aug 2010.
            End If
            i = i + direction
            'Debug.Print "Line: " & i
        End While
        If Not found And wrap Then
            If direction > 0 Then
                i = 0
            Else
                i = numberLines - 1
            End If
            While i >= 0 And i <= currentLine And Not found
                lineContent = GetNumberedLine(txtText, i)
                If InStr(1, lineContent, startsWith, CompareMethod.Text) = 1 Then
                    'found it
                    found = True
                    txtText.SelectionStart = GetCharacterIndexOfLine(txtText, i)
                    txtText.SelectionLength = 0
                    'Call ScrollToCursor(txtText)
                    'Call PlayDoneSound ' Don't play the done sound, it's really intrusive. Aug 2010.
                End If
                i = i + direction
            End While
        End If
        If Not found Then Call PlayErrorSound()
        GotoLineStarting = found
        'This is to make sure Narrator (Thunder) reads the text, which it only does if you've
        'hit up or down, so do an up and down after a key up.
        'Ah, this appears to completely suck. I've got loads of complaints from NVDA users, Hal users
        'etc. about hearing "Escape" and other odd things as they cursor around. Let's try disabling it.
        'Moved here from txtText_KeyUp after many complaints from other screenreader users that things were
        'working oddly.
        If gGotThunder Then
            mIgnoreNextKeypress = True
            tmrDoUpDownKeys.Enabled = True
        End If
    End Function


    Public Sub mnuLinksSkipup_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuLinksSkipup.Click

        Call SkipLinks(SKIP_UP)
    End Sub

    Public Sub mnuNavigateGotoform_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuNavigateGotoform.Click
        'Causes the cursor to jump to the next input element over any links

        Call SkipToFormElement(1)
    End Sub

    Private Sub SkipToFormElement(ByRef direction As Integer)

        Dim lineNumber As Integer
        Dim found As Boolean
        Dim line As String
        Dim numberLines As Integer

        lineNumber = GetCurrentLineIndex(txtText) + direction
        numberLines = GetNumberOfLines(txtText)
        found = False
        While lineNumber < numberLines And lineNumber >= 0 And Not found
            line = GetNumberedLine(txtText, lineNumber)
            If LineIsForm(line) Then
                'found form element
                found = True
            Else
                'keep going
                lineNumber = lineNumber + direction
            End If
        End While
        If found Then
            txtText.SelectionStart = GetCharacterIndexOfLine(txtText, lineNumber)
            txtText.SelectionLength = 0
            'Call ScrollToCursor(txtText)
            'Don't select - stops screenreaders reading line, they read the document instead.
            'Call SelectCurrentParagraph
        Else
            Call PlayErrorSound()
        End If
    End Sub

    Public Sub mnuOptionsAllowmessages_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsAllowmessages.Click

        mnuOptionsAllowmessages.Checked = Not mnuOptionsAllowmessages.Checked
        mWebBrowser.ScriptErrorsSuppressed = Not mnuOptionsAllowmessages.Checked
    End Sub

    Public Sub mnuOptionsDownloadingimagesOptions_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsDownloadingimagesOptions.Click
        Dim index As Short = mnuOptionsDownloadingimagesOptions.GetIndex(CType(eventSender, System.Windows.Forms.ToolStripMenuItem))

        mnuOptionsDownloadingimagesOptions(0).Checked = False
        mnuOptionsDownloadingimagesOptions(1).Checked = False
        mnuOptionsDownloadingimagesOptions(index).Checked = True
        If index = imageStates.wbimageson Then
            Call SetImagesOnOrOffInIE(True)
        ElseIf index = imageStates.wbimagesoff Then
            Call SetImagesOnOrOffInIE(False)
        End If
        Call MsgBox(modI18N.GetText("Display changes will take effect when you restart WebbIE"), MsgBoxStyle.OkOnly, modI18N.GetText("Display of images changed"))
    End Sub

    Public Sub mnuLinksPreviousLink_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuLinksPreviouslink.Click
        'go up to previous link

        Dim lineNumber As Integer
        Dim linkFound As Boolean

        lineNumber = GetCurrentLineIndex(txtText) - 1
        linkFound = False
        While lineNumber >= 0 And Not linkFound
            If StrComp(VB.Left(GetNumberedLine(txtText, lineNumber), Len(ID_LINK)), ID_LINK, CompareMethod.Text) = 0 Then
                'found a link
                linkFound = True
            Else
                lineNumber = lineNumber - 1
            End If
        End While
        If linkFound Then
            txtText.SelectionStart = GetCharacterIndexOfLine(txtText, lineNumber)
            'txtText.SelLength = Len(Trim(modAPIFunctions.GetCurrentLine(txtText)))
            'Call ScrollToCursor(txtText)
        Else
            Call PlayErrorSound()
        End If
    End Sub



    Public Sub mnuLinksSkiplinks_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuLinksSkiplinks.Click

        Call SkipLinks(SKIP_DOWN)
    End Sub

    Private Function LineIsForm(ByRef line As String) As Boolean
        'returns true if the line is a form element, false if not

        LineIsForm = True
        If InStr(1, line, ID_SELECT, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_BUTTON, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_CHECKBOX, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_RADIO, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_TEXTBOX, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_PASSWORD, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_SUBMIT, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_FILE, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_RESET, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_TEXTAREA, CompareMethod.Binary) = 1 Then
        Else
            'nope, this isn't a form element
            LineIsForm = False
        End If
    End Function

    Private Function LineIsText(ByRef line As String) As Boolean
        'returns true if the line is text, false if it is a link or form element or similar: used by mnuViewCroppage

        LineIsText = False
        If InStr(1, line, ID_LINK, CompareMethod.Binary) = 1 Then
            'found a link!
        ElseIf InStr(1, line, ID_SELECT, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_BUTTON, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_CHECKBOX, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_RADIO, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_TEXTBOX, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_PASSWORD, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_SUBMIT, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_FILE, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_RESET, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_TEXTAREA, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_OBJECT, CompareMethod.Binary) = 1 Then
        ElseIf InStr(1, line, ID_FLASHOBJECT, CompareMethod.Binary) = 1 Then
        Else
            'yep, we're going to use this line
            LineIsText = True
        End If
    End Function

    Friend Sub DoCrop()

        Call mnuViewCroppage_Click(mnuViewCroppage, New System.EventArgs())
    End Sub

    Friend Function Cropped() As Boolean

        Cropped = Not (mnuViewCroppage.Text = modI18N.GetText("&Crop page"))
    End Function

    Public Sub mnuViewCroppage_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewCroppage.Click
        'strip out link content from the page, hopefully leaving only main content: may trim out link content
        'occuring as part of main content, but should remove all the navigation info


        'DEV: new version Jan 2007: doesn't just skip links, does some clever
        'text processing. See modParseAsText
        Static contents As String ' the old page before cropping
        Static where As String 'where we were on the page, roughly
        Dim i As Integer
        'UPGRADE_NOTE: left was upgraded to left_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
        Dim left_Renamed As Integer
        'UPGRADE_NOTE: right was upgraded to right_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
        Dim right_Renamed As Integer
        Dim done As Boolean
        Dim targetLine As Integer
        Dim found As Integer
        Dim parsedAsText As String

        If Cropped() Then
            'already cropped, uncropping. Get the text around the cursor, not
            'newlines, and try to find it.
            'Get leftwards
            left_Renamed = txtText.SelectionStart
            While Not done
                left_Renamed = left_Renamed - 1
                If left_Renamed < 1 Then
                    left_Renamed = 1
                    done = True
                ElseIf AscW(Mid(txtText.Text, left_Renamed, 1)) < 32 Then
                    left_Renamed = left_Renamed + 1
                    done = True
                ElseIf left_Renamed < txtText.SelectionStart - 5 Then
                    done = True
                End If
            End While
            'get rightwards
            done = False
            right_Renamed = txtText.SelectionStart
            While Not done
                right_Renamed = right_Renamed + 1
                If right_Renamed > Len(txtText.Text) Then
                    right_Renamed = Len(txtText.Text)
                    done = True
                ElseIf AscW(Mid(txtText.Text, right_Renamed, 1)) < 32 Then
                    right_Renamed = right_Renamed - 1
                    done = True
                ElseIf right_Renamed > txtText.SelectionStart + 5 Then
                    done = True
                End If
            End While
            'get text to find
            where = Mid(txtText.Text, left_Renamed, right_Renamed - left_Renamed)
            'replace text with old text
            txtText.Text = contents
            txtText.SelectionStart = InStr(1, txtText.Text, where)
            'Don't select - stops screenreaders reading line, they read the document instead.
            'Call SelectCurrentParagraph
            mnuViewCroppage.Text = modI18N.GetText("&Crop page")
        Else
            'not cropped, cropping now
            contents = txtText.Text
            'first, find and remember the line we're going to restore if we uncrop
            targetLine = 0
            If LineIsText(Trim(Replace(GetCurrentLine(txtText), Chr(0), " "))) Then
                'hurrah, a text line: this is nice and easy
                targetLine = GetCurrentLineIndex(txtText)
            Else
                'a non-text line, which therefore will be lost in the processing: have to find the next line
                'that is text
                targetLine = -1
                For i = GetCurrentLineIndex(txtText) To GetNumberOfLines(txtText)
                    If LineIsText(Trim(Replace(GetNumberedLine(txtText, i), Chr(0), " "))) Then
                        'good, found a text line: we'll use that
                        targetLine = i 'indicates we're using this system
                        Exit For
                    End If
                Next i
                'NB: if we didn't find somewhere, try working backwards: we'll eventually end up at line 1 if
                'nowhere else (which contains the document title and therefore is always a text line)
                If targetLine = -1 Then ' initial value
                    For i = GetCurrentLineIndex(txtText) To 0 Step -1
                        If LineIsText(Trim(Replace(GetNumberedLine(txtText, i), Chr(0), " "))) Then
                            'good, found a text line: we'll use that
                            targetLine = i 'indicates we're using this system
                            Exit For
                        End If
                    Next i
                End If
            End If
            If targetLine = -1 Then targetLine = 0 ' failed to match anything!
            where = Replace(GetNumberedLine(txtText, targetLine), Chr(0), "")
            where = Trim(where)
            where = Replace(where, vbNewLine, "")
            Debug.Print("Cropping: [" & where & "]")
            parsedAsText = modParseAsText.ParseDocs 'in fact only works on
            'webbrowser.Document, so won't handle any frames. I'm going to
            'argue this is a good thing for the moment: less nonsense.
            'We'll have to see experimentally if this is the case.
            If Len(parsedAsText) = 0 Then
                'Ah, the new-style parsing - removing frames - returned absolutely nothing.
                'Instead, parse the page directly.
                Call CropOriginalPage()
            Else
                txtText.Text = parsedAsText
            End If
            found = InStr(1, txtText.Text, where, CompareMethod.Text)
            While found = 0 And Len(where) > 2
                where = Mid(where, 2, Len(where) - 2)
                found = InStr(1, txtText.Text, where, CompareMethod.Text)
            End While
            If found > 0 Then txtText.SelectionStart = found
            'Don't select - stops screenreaders reading line, they read the document instead.
            'Call SelectCurrentParagraph
            mnuViewCroppage.Text = modI18N.GetText("Un&crop page")
        End If
        'DEV: 3.2.0 and earlier version, took out lines of links. This therefore worked
        'exactly like Skip Links, but broke the page. Better to do some clever text
        'processing, maybe? See above.

    End Sub

    Private Sub CropOriginalPage()
        'crops the original text page according to the pre-3.2 mechanisms. This supports pages with
        'lots of IFRAMES and other contructs that prevent me reparsing the page

        Dim i As Integer
        Static page As String 'should hold the contents of the page
        Dim content() As String
        Dim output As String = ""
        Dim targetLine As Integer
        

        'cropping links
        page = txtText.Text 'remember the original content
        'first, find and remember the line we're going to restore if we uncrop
        targetLine = 0
        If LineIsText(Trim(Replace(GetCurrentLine(txtText), Chr(0), " "))) Then
            'hurrah, a text line: this is nice and easy
        Else
            'a non-text line, which therefore will be lost in the processing: have to find the next line
            'that is text
            For i = GetCurrentLineIndex(txtText) To GetNumberOfLines(txtText)
                If LineIsText(Trim(Replace(GetNumberedLine(txtText, i), Chr(0), " "))) Then
                    'good, found a text line: we'll use that
                    targetLine = i 'indicates we're using this system
                    Exit For
                End If
            Next i
            'NB: if we didn't find somewhere, try working backwards: we'll eventually end up at line 1 if
            'nowhere else (which contains the document title and therefore is always a text line)
            If targetLine = 0 Then ' initial value
                For i = GetCurrentLineIndex(txtText) To 0 Step -1
                    If LineIsText(Trim(Replace(GetNumberedLine(txtText, i), Chr(0), " "))) Then
                        'good, found a text line: we'll use that
                        targetLine = i 'indicates we're using this system
                        Exit For
                    End If
                Next i
            End If
            'assertion: targetLine holds the line we should move the cursor to. So do so!
            txtText.SelectionStart = GetCharacterIndexOfLine(txtText, targetLine)
        End If
        txtText.SelectionLength = 0
        txtText.SelectedText = TARGET_MARKER ' mark where the cursor was
        content = Split(txtText.Text, vbNewLine) ' split the content into lines
        'now chop out lines that aren't text
        'DEV: did try something with scoring, didn't work too well: need to work
        'at text block level if this is tried again (e.g. working out A in DIV
        'with lots of text versus A in LI with no text)
        For i = 0 To UBound(content) ' iterate through removing lines that aren't text
            'find out if this is/was the target line
            If LineIsText(content(i)) Then
                'yep, we're going to use this line if it's long enough
                If Len(content(i)) > 4 Then ' note "magic number": this removes
                    'lines that are just punctuation points, such as bullets
                    output = output & content(i) & vbNewLine
                End If
            Else
                'nope, we're not
            End If
        Next i
        txtText.Text = output
        txtText.SelectionStart = InStr(1, output, TARGET_MARKER, CompareMethod.Binary) - 1
        txtText.SelectionLength = Len(TARGET_MARKER)
        txtText.SelectedText = ""

    End Sub

    Public Sub mnuViewLaunchIE_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewLaunchIE.Click

        'TODO or remove.
        'Dim externalBrowser As Object
        'externalBrowser = CreateObject("InternetExplorer.Application")
        'If Trim(cboAddress.Text) = "" Then
        '    Call externalBrowser.Navigate(New System.Uri("about:blank"))
        'Else
        '    Call externalBrowser.Navigate(New System.Uri(cboAddress.Text))
        'End If
        'externalBrowser.Visible = True
    End Sub

    Private Function GetUserFriendlyURL(ByRef url As String) As String


        Dim found As Integer
        Dim friendlyURL As String

        friendlyURL = url
        'take off ? queries
        found = InStr(1, friendlyURL, "?")
        If found > 0 Then
            friendlyURL = VB.Left(friendlyURL, Len(friendlyURL) - found - 1)
        End If
        'take off //
        found = InStr(1, friendlyURL, "//")
        If found > 0 Then
            friendlyURL = VB.Right(friendlyURL, Len(friendlyURL) - found - 1)
        End If
        'take off trailing /
        If VB.Right(friendlyURL, 1) = "/" Then
            friendlyURL = VB.Left(friendlyURL, Len(friendlyURL) - 1)
        End If
        'UPGRADE_WARNING: Couldn't resolve default property of object GetUserFriendlyURL. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        GetUserFriendlyURL = friendlyURL
    End Function

    Public Sub mnuViewSource_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewSource.Click

        Dim doc As HtmlDocument

        doc = mWebBrowser.Document
        frmTextView.Text = modI18N.GetText("Page HTML Source")
        'TODO How do I work out the mimetype?
        'frmTextView.txtTextView.Text = modI18N.GetText("Document mimetype:") & " "
        On Error GoTo mimeTypeError
        'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.mimeType. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        'frmTextView.txtTextView.Text = frmTextView.txtTextView.Text & mWebBrowser.Document.DomDocument.mimeType

        frmTextView.txtTextView.Text = frmTextView.txtTextView.Text & vbNewLine
        'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.charSet. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        'TODO how do I get the charset? Unmanaged code, so late binding?
        'frmTextView.txtTextView.Text = frmTextView.txtTextView.Text & modI18N.GetText("Character encoding:") & " " & mWebBrowser.Document.DomDocument.charSet & vbNewLine


        If blnAlwaysUseUserDefaultLanguage Then
            'TODO This only provides the BODY HTML.
            frmTextView.txtTextView.Text = frmTextView.txtTextView.Text & Replace(doc.Body.OuterHtml.ToString, vbLf, vbNewLine)
        Else
            'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.documentElement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            frmTextView.txtTextView.Text = frmTextView.txtTextView.Text & Replace(doc.Body.OuterHtml.ToString, vbLf, vbNewLine)
        End If
        Call VB6.ShowForm(frmTextView, VB6.FormShowConstants.Modal, Me)
        Exit Sub
mimeTypeError:

        frmTextView.txtTextView.Text = frmTextView.txtTextView.Text & "-"
        Resume Next
    End Sub

    Private Sub txtText_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtText.Enter
        'We can't cut or paste in the main text box, so disable the menu items: we can't copy until we've
        'selected some text, so disable copy

        '    mnuEditCopy.Enabled = False
        'This is in addition to the txtDummy function - see http://support.microsoft.com/kb/195235/ 3.8.4
        Call txtText.Focus()

        'cboAddress.TabStop = False ' Do this so we can get tab keypress events so we can do next link.
        'Don't do this! 3.11.4. Loads of problems with the UI if we do this.
    End Sub

    Private Sub txtText_Leave(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles txtText.Leave

        'don't allow user to tab to mWebBrowser control if it is not visible
        'Debug.Print "txtText_LostFocus()"
        If Not (VB6.GetActiveControl() Is Nothing) Then
            'UPGRADE_ISSUE: Control name could not be resolved because it was within the generic namespace ActiveControl. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="084D22AD-ECB1-400F-B4C7-418ECEC5E36E"'
            If Not mblnIEVisible And (VB6.GetActiveControl().Name = mWebBrowser.Name) Then
                Call txtText.Focus()
            Else
                'Debug.Print "Screen ActiveControl Name: " & Screen.ActiveControl.name
            End If
        End If
    End Sub










































    '==========================================================================================
    ' USER RESPONSES
    ' User response functions and routines
    '==========================================================================================

    'UPGRADE_WARNING: Event cboAddress.TextChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
    'UPGRADE_WARNING: ComboBox event cboAddress.Change was upgraded to cboAddress.TextChanged which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
    Private Sub cboAddress_TextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cboAddress.TextChanged
        'Binned autocomplete December 2003

    End Sub

    Private Sub cboAddress_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles cboAddress.KeyDown
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000
        'process when a user presses a key in the address box

        '3.11.4 Abandoned this "tab through links" feature for now, causes too many problems.

    End Sub

    Private Sub cboAddress_KeyUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles cboAddress.KeyUp
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000
        'check for which edit functions we can allow

        If cboAddress.SelectionLength > 0 Then
            mnuEditCut.Enabled = True
            '        mnuEditCopy.Enabled = True
        Else
            mnuEditCut.Enabled = False
            '        mnuEditCopy.Enabled = False
        End If
        If Len(My.Computer.Clipboard.GetText) > 0 Then
            mnuEditPaste.Enabled = True
        Else
            mnuEditPaste.Enabled = False
        End If
    End Sub

    Private Sub cboaddress_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles cboAddress.KeyPress
        Dim KeyAscii As Integer = Asc(eventArgs.KeyChar)

        If KeyAscii = System.Windows.Forms.Keys.Return Then 'if return is hit
            If cboAddress.SelectedIndex > -1 Then
                cboAddress.Text = VB6.GetItemString(cboAddress, cboAddress.SelectedIndex)
            End If
            Call cmdGo_Click() 'make this action the same as pressing go
        End If
        eventArgs.KeyChar = Chr(KeyAscii)
        If KeyAscii = 0 Then
            eventArgs.Handled = True
        End If
    End Sub

    Private Sub frmMain_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize

        If mToolbarVisible Then
            Me._picBusyAnimation_0.Visible = True
        Else
            Me._picBusyAnimation_0.Visible = False
        End If

        If mblnIEVisible Then
            mWebBrowser.Left = txtText.Left
        Else
            mWebBrowser.Left = Me.Width + 90
        End If
        workBrowser.Left = -workBrowser.Width - 1000
    End Sub





































    '==========================================================================================
    ' FORM LOAD AND UNLOAD
    ' Things to do when the form loads or unloads
    '==========================================================================================

    Private Sub frmMain_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        'load settings, displays, bookmarks when the program starts up.

        Dim result As String
        Dim commandLine As String
        Dim fso As Scripting.FileSystemObject
        Dim helpIndex As String
        Dim startedNavigating As Boolean
        Dim filePath As String = ""
        Dim f As Scripting.File
10:     Dim timing As String
        Dim timingStart As Integer

        timingStart = GetTickCount
        timing = "START 0" & vbNewLine
11:
        'Whoa! Use of "End"? That's pretty aggressive. Why? Because the winInet control I'm using in 3.8.0 to get the
        'pages I need to populate links causes non-termination of the program, and this is the fallback. Jan 2009.
        If gExiting Then End
        'determine and set up the settings directory
12:     Call modPath.DetermineSettingsPath("WebbIE", "WebbIE", "3")
13:     Call modUpdate.CheckForUpdates()


        mWebBrowser.ScriptErrorsSuppressed = True
        workBrowser.ScriptErrorsSuppressed = False
        'are we installed? If not, don't allow Help > Check for Updates
        If modPath.runningLocal Then
            mnuHelpCheck.Visible = False
        End If

        Call txtText.SendToBack()
        'make txtText non-editable
        txtText.ReadOnly = True

        timing = timing & "AT 2 " & (GetTickCount - timingStart) / 1000 & vbNewLine

        Call SetupTabs()
        Call SetupTabs() ' Do again so it takes (!)

        fso = New Scripting.FileSystemObject
        'State variables
        'the current page filename when saved to disk
        mstrCurrentPageFilename = CStr(False)
        'make the webBrowser small as possible
        mWebBrowser.Height = CInt(VB6.TwipsToPixelsY(100))
        mWebBrowser.Width = CInt(VB6.TwipsToPixelsX(100))

        'Turn off Script errors showing up.
        Call DisableScriptErrors()

        timing = timing & "AT 3 " & (GetTickCount - timingStart) / 1000 & vbNewLine

        'language settings
        'get the language settings for the default character set for the user's system
        Call modCharacterSupport.InitSystemLocale()
        Call modCharacterSupport.InitCharsetMappings()
        result = modIniFile.GetString("Internationalisation", "Default charset", "-1", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        If result <> "-1" Then
            intDefaultCharset = CShort(result)
        Else
            intDefaultCharset = CShort(Trim(GetSetting(My.Application.Info.Title, USER_SETTINGS, "Default charset", CStr(CHARSET_WESTERN_EUROPEAN))))
        End If
        result = modIniFile.GetString("Internationalisation", "Default locale", "-1", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        If result <> "-1" Then
            lngDefaultLocale = CInt(result)
        Else
            lngDefaultLocale = CShort(Trim(GetSetting(My.Application.Info.Title, USER_SETTINGS, "Default locale", CStr(LOCALE_WESTERN_EUROPEAN))))
        End If
        timing = timing & "AT 4 " & (GetTickCount - timingStart) / 1000 & vbNewLine
        result = modIniFile.GetString("Internationalisation", "Always use user-default language", "-1", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        'blnAlwaysUseUserDefaultLanguage determines if the browser
        'should override the determined language setting. Useful for
        'non-English people who are frequently served pages incorrectly
        'marked as english
        If result <> "-1" Then
            blnAlwaysUseUserDefaultLanguage = CBool(result)
        Else
            blnAlwaysUseUserDefaultLanguage = CBool(Trim(GetSetting(My.Application.Info.Title, USER_SETTINGS, "blnAlwaysUseUserDefaultLanguage", "false")))
        End If

        'Load data structures
        Call LoadDataStructures()

        'TODO Do we need to set charset?
        'If blnAlwaysUseUserDefaultLanguage Then
        'txtText.Font = VB6.FontChangeGdiCharSet(txtText.Font, intDefaultCharset)
        'End If
        'cboAddress.Font = VB6.FontChangeGdiCharSet(cboAddress.Font, intDefaultCharset)
        'Me.Font = VB6.FontChangeGdiCharSet(Me.Font, intDefaultCharset)

        'Load forms.
        DownloadProgressForm = New frmDownloadProgress

        GoogleForm = New frmGoogle
        GoogleForm.targetForm = Me
        LanguageForm = New frmLanguage
        LanguageForm.targetForm = Me
        LinksForm = New frmLinks
        LinksForm.targetForm = Me
        SelectForm = New frmSelect
        SelectForm.targetForm = Me
        TextareaInputForm = New frmTextareaInput
        TextareaInputForm.targetForm = Me
        TextViewForm = New frmTextView
        TextViewForm.targetForm = Me
        modHTTPGetter.gTargetForm = Me
        modCommandProcessor.targetForm = Me

        'now every form has loaded we can set-up the language
        Call modGlobals.Initialise()
        'Debug.Print "It's now: " & frmGoogle.cmdAddress.FontName
        Call SetupShortcutKeys()

50:     ToolTip1.SetToolTip(_picBusyAnimation_0, " " & modI18N.GetText("If this is changing then WebbIE is busy downloading a page for you.") & " ")
        ToolTip1.SetToolTip(_picBusyAnimation_1, " " & modI18N.GetText("If this is changing then WebbIE is busy downloading a page for you.") & " ")
        ToolTip1.SetToolTip(_picBusyAnimation_2, " " & modI18N.GetText("If this is changing then WebbIE is busy downloading a page for you.") & " ")
        ToolTip1.SetToolTip(_picBusyAnimation_3, " " & modI18N.GetText("If this is changing then WebbIE is busy downloading a page for you.") & " ")
        staMain.Items.Item(0).Text = modI18N.GetText("Idle")
        staMain.Items.Item(2).Text = modI18N.GetText("Offline")

        mobjNavigationRecord = New System.Collections.Generic.Dictionary(Of String, Integer)

        timing = timing & "AT 6 " & (GetTickCount - timingStart) / 1000 & vbNewLine

        'get the font and colour details
        result = modIniFile.GetString("User settings", "Font size", "16", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        gintFontSize = CShort(result)

        'Ajax support on or off
        'UPGRADE_WARNING: App property App.EXEName has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
        mnuOptionsAllowajax.Checked = CBool(modPath.GetSettingIni(My.Application.Info.AssemblyName, "User Settings", "AjaxSupport", CStr(True)))
        'Javascript-only elements shown
        'UPGRADE_WARNING: App property App.EXEName has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
        mnuOptionsJavascriptonlyitems.Checked = CBool(modPath.GetSettingIni(My.Application.Info.AssemblyName, "User Settings", "JavascriptOnlyItems", CStr(False)))

        txtText.Font = VB6.FontChangeSize(txtText.Font, gintFontSize)
        result = modIniFile.GetString("User settings", "Font name", "Arial", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        txtText.Font = VB6.FontChangeName(txtText.Font, result)
        cboAddress.Font = VB6.FontChangeName(cboAddress.Font, txtText.Font.Name)
        result = modIniFile.GetString("User settings", "Font bold", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        txtText.Font = VB6.FontChangeBold(txtText.Font, CBool(result))
        cboAddress.Font = VB6.FontChangeBold(cboAddress.Font, txtText.Font.Bold)
        result = modIniFile.GetString("User settings", "Invert text area colours", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        If CBool(result) Then
            Me.mnuOptionsInvertcolours.Checked = True
            Call InvertColours(True)
        End If

        'Now do Windows non-client metrics and apply to forms.
        'Set gobjNCMetrics = New cNCMetrics
        'Call gobjNCMetrics.ApplyWindowsSettingsToNonClientControls(Me)

60:     timing = timing & "AT 7 " & (GetTickCount - timingStart) / 1000 & vbNewLine
        'User Preferences
        'determine whether images are on or off in IE
        If GetImagesOnOrOffInIE() Then
            Me.TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Checked = True
            Me.TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Checked = False
        Else
            Me.TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Checked = False
            Me.TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Checked = True
        End If

        'Get whether images are on or off
        result = modIniFile.GetString("User settings", "Show images", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsImages.Checked = CBool(result)
        'get whether popups allowed
        result = modIniFile.GetString("User settings", "Allow popups", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsAllowPopups.Checked = CBool(result)
        result = modIniFile.GetString("User settings", "Load welcome page", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        blnLoadWelcomePage = CBool(result)
        result = modIniFile.GetString("User settings", "Allow messages", "True", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsAllowmessages.Checked = CBool(result)
        mWebBrowser.ScriptErrorsSuppressed = Not mnuOptionsAllowmessages.Checked
        result = modIniFile.GetString("User settings", "Error URL", "", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
70:     If Len(result) > 0 Then
            mstrErrorURL = result
        Else
            mstrErrorURL = GetSetting(My.Application.Info.Title, SYSTEM_SETTINGS, "mstrErrorURL", "")
        End If
        'sounds
        result = modIniFile.GetString("User settings", "NavigationSounds", "True", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsNavigationsounds.Checked = CBool(result)
        'quick keys
        result = modIniFile.GetString("User settings", "QuickKeys", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsUsequickkeys.Checked = CBool(result)
        'get pdfs from google
        result = modIniFile.GetString("User settings", "FetchPDFFromGoogle", "True", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsFetchPDFfromGoogle.Checked = CBool(result)
        'Get numbers on links.
        result = modIniFile.GetString("User settings", "NumberLinks", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsNumberlinksandotheritems.Checked = CBool(result)
        mNumberLinks = mnuOptionsNumberlinksandotheritems.Checked
        'toolbar
        result = modIniFile.GetString("User settings", "Toolbar captions", "True", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsToolbarcaptions.Checked = CBool(result)
        Call LoadToolbarCaptionsAndResizeToolbar()
        result = modIniFile.GetString("User settings", "Toolbar visible", "True", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mToolbarVisible = CBool(result)
        If mToolbarVisible Then
            'show toolbar
            mnuOptionsHideToolbar.Text = modI18N.GetText("Hide &Toolbar")
        Else
            'make it invisible
            txtText.Height = CInt(VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - VB6.PixelsToTwipsY(cboAddress.Height) - 50))
            txtText.Top = CInt(VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(cboAddress.Height) + 50))
            mnuOptionsHideToolbar.Text = modI18N.GetText("Show &Toolbar")
        End If
        'set the default cut and paste permissions
        mnuEditPaste.Enabled = False
        mnuEditCut.Enabled = False
        mnuEditSelectall.Enabled = False
        'query the registry for the current IE homepage
        If modPath.runningLocal Then
            result = modIniFile.GetString("User settings", "Homepage URL", "http://www.webbie.org.uk/" & modI18N.GetLanguage & "/home.htm", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
            gstrCurrentHomepage = result
        Else
            gstrCurrentHomepage = RetrieveStartPage()
        End If
        ToolTip1.SetToolTip(cmdHome, gstrCurrentHomepage) 'create a tooltip for home button

        NBSP = Chr(160)
        'check for command line query
        commandLine = VB.Command()
        If InStr(1, commandLine, "-?", CompareMethod.Text) > 0 Then
            'MsgBox "WebbIE command line options: Use 'WebbIE [url]' to go somewhere, 'WebbIE -iefavorites' to make WebbIE use IE favorites (default) and 'WebbIE -webbiefavorites' to make WebbIE use simple bookmarks, useful if you're having trouble running WebbIE on a networked machine.", vbOKOnly, "WebbIE command line options"
            commandLine = Replace(commandLine, "-?", "")
        End If
        'Bookmark handling: this used to have two alternative approaches, but from
        '3.2.0 I've dropped the old mechanism because it's non-standard and people
        'sometimes get stuck in it.
        '3.2.3 Okay, so now I'm going to rewrite the simple bookmark system to
        'allow for people to keep their bookmarks on a pen drive. This is determined
        'by whether the bookmark file is there
        'nope, use the IE websites
        mblnIEFavorites = True
        'now carry on processing bookmark functions on the setting obtained. IE favorites are switched on last,
        'so see later in
        If mblnIEFavorites Then
            'Loading bookmarks took about about eight seconds, but fixed use of RegOpenKey in 3.12.2:
            'TODO Fix bookmarks Call LoadBookmarks
            mnuBookmarksAddbookmark.Enabled = False
        End If

        If mblnIEFavorites Then
            'Activate the menu processor: this is the bit that might crash some machines, so changed the
            'registry setting to simple and back to ie only if successful: thus, if started again,
            'the setting is for simple bookmarks
            'TODO
        End If
        Call Me.Show()
        'check to see if we should start up with IE showing: text view is the default,
        'so hit the "change" button iff we have ie showing
        'DEV: I believe that many users accidentally turn on the web page view,
        'probably because the shortcut is similar (less the shift key) to the Search
        'Google view. So, the IE/WebbIE state should always be WebbIE when loaded,
        'in case the user has got confused.
        'In 3.6.0 I'm adding a commandline switch "-IEView" that starts WebbIE in IE view this
        'time only.
        'OK, so if (1) the commandline switch "-IEView" -> start in IE view.
        '       elseif (2) "AllowStartupInIE" is enabled AND "Show IE at startup" is 1 -> start in IE view
        '       else (3) start in text view.
        '3.12.2: okay, some VI users want to see the web view all the time, so make it possible but not easy.
        result = ""
        result = modIniFile.GetString("User settings", "AllowStartupInIE", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        mnuOptionsAlwaysstartintextview.Checked = Not (CBool(result))
        If InStr(1, " " & commandLine & " ", " -IEView ", CompareMethod.Text) > 0 Then
            result = "True"
            commandLine = Replace(commandLine, "-ieview", "", , 1, CompareMethod.Text)
        ElseIf Not mnuOptionsAlwaysstartintextview.Checked Then
            result = modIniFile.GetString("User settings", "Show IE at startup", "False", modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Else
            result = "False"
        End If
        If CBool(result) Then
            'IE should be shown
            mWebBrowser.Left = txtText.Left
            mWebBrowser.Width = txtText.Width
            mWebBrowser.Top = txtText.Top
            mWebBrowser.Height = txtText.Height
            mWebBrowser.TabStop = True
            If mnuOptionsToolbarcaptions.Checked Then
                cmdViewIE.Text = modI18N.GetText("Hide webpage")
            End If
            mnuViewIE.Text = modI18N.GetText("Hide &webpage")
            mblnIEVisible = True
            cmdMagnify.Visible = True
            cmdShrink.Visible = True
            mnuViewMagnify.Enabled = True
            mnuViewShrink.Enabled = True
            cmdSkiplinks.Visible = False
            cmdHeading.Visible = False
            'disable irrelevant menu items
            mnuNavigateGotoform.Enabled = False
            mnuNavigateGotoheadline.Enabled = False
        Else
            cmdMagnify.Visible = False
            cmdShrink.Visible = False
            mnuViewMagnify.Enabled = False
            mnuViewShrink.Enabled = False
            cmdSkiplinks.Visible = True
            cmdHeading.Visible = True
            cmdSkiplinks.BringToFront() 'otherwise doesn't appear!
        End If
        timing = timing & "AT 10 " & (GetTickCount - timingStart) / 1000 & vbNewLine

        Call cboAddress.Items.Clear()
        timing = timing & "AT 10.1 " & (GetTickCount - timingStart) / 1000 & vbNewLine
        'check for commandline request to go somewhere.
        If Trim(commandLine) <> "" Then
            'goody, we have an address already
            'strip off any "" first
            If InStr(1, commandLine, """", CompareMethod.Binary) = 1 Then
                commandLine = VB.Right(commandLine, Len(commandLine) - 1)
            End If
            If InStrRev(commandLine, """", Len(commandLine), CompareMethod.Binary) = Len(commandLine) Then
                commandLine = VB.Left(commandLine, Len(commandLine) - 1)
            End If
            'remove ActiveX command
            commandLine = Replace(commandLine, "-Embedding", "", , , CompareMethod.Text)
            'is this an absolute path (e.g. "D:\page.htm") or a relative one (e.g. "page.htm")
            If fso.FileExists(commandLine) Then
                filePath = commandLine
            ElseIf fso.FileExists(My.Application.Info.DirectoryPath & "\" & commandLine) Then
                filePath = My.Application.Info.DirectoryPath & "\" & commandLine
            ElseIf fso.FileExists(My.Application.Info.DirectoryPath & commandLine) Then
                filePath = My.Application.Info.DirectoryPath & commandLine
            End If
            'Does file indicated by commandline exist?
            If Len(filePath) > 0 Then
                'yes!
                f = fso.GetFile(filePath)
                startedNavigating = True
                If StrComp(VB.Right(f.Path, 4), ".chm", CompareMethod.Text) = 0 And InStr(1, f.Path, "\") > 0 Then
                    'local help file
                    Call Me.Show()
                    frmParseHTMLHelp = New frmParseHTMLHelp
                    helpIndex = frmParseHTMLHelp.ConvertHTMLHelp(f.Path)
                    If Len(helpIndex) > 0 Then
                        'Call StartNavigating(helpIndex)
                        cboAddress.Text = helpIndex
                        startedNavigating = True
                    End If
                Else
                    'just a file
                    cboAddress.Text = f.Path
                    startedNavigating = True
                End If
            Else
                'nope!
                'web page
                timing = timing & "AT 10.2 " & (GetTickCount - timingStart) / 1000 & vbNewLine
                cboAddress.Text = commandLine 'set the address to the command line argument
                timing = timing & "AT 10.3 " & (GetTickCount - timingStart) / 1000 & vbNewLine
                timing = timing & "AT 10.4 " & (GetTickCount - timingStart) / 1000 & vbNewLine
                startedNavigating = True
            End If

        End If

        timing = timing & "AT 11 " & (GetTickCount - timingStart) / 1000 & vbNewLine
        mnuOptionsUsefavouritesforhomepage.Checked = CBool(GetSettingIni("WebbIE", "Homepage", "UseFavourites", "false"))
        If startedNavigating = True Then
            'okay, we've started going somewhere from the command prompt
        Else
            'not decided what to do yet:
            If blnLoadWelcomePage Then
                'oh, we've just run the program for the first time: load a welcome page
                cboAddress.Text = "http://www.webbie.org.uk/" & modI18N.GetLanguage & "/welcome.htm"
            Else
                ''go to IE homepage if we're online or the file is local
                'scratched this idea - user probably not happy with MSN...
                'DEV: but going to the home page when the browser starts is
                'what browsers do. Reinstate this.
                If mnuOptionsUsefavouritesforhomepage.Checked Then
                    'TODO Call ts.write(gBookmarksHTML)
                    'cboAddress.Text = tempPath
                Else
                    'go to homepage
                    cboAddress.Text = gstrCurrentHomepage
                End If
            End If
            startedNavigating = True
        End If
        mnuLinksFollowlinkaddress.Text = mnuLinksFollowlinkaddress.Text & vbTab & "Ctrl+Enter"
        Me.mnuLinksDownloadlink.Text = mnuLinksDownloadlink.Text & vbTab & "Shift+Enter"
        timing = timing & "FINISH " & (GetTickCount - timingStart) / 1000 & vbNewLine
        If startedNavigating Then tmrStartNavigating.Enabled = True
    End Sub

    Private Sub LoadDataStructures()
        Dim i As Integer

        For i = 0 To MAX_NUMBER_BUTTON_INPUTS_SUPPORTED - 1
            Call selects(i).Initialize()
        Next i
    End Sub

    Private Sub frmMain_FormClosed(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed

        'indicate we should stop operations
        gExiting = True
        'save user settings to registry
        Call modIniFile.WriteString("User settings", "WindowState", CStr(Me.WindowState), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        If Me.WindowState = System.Windows.Forms.FormWindowState.Normal Then 'save all the window sizes for next load up
            Call modIniFile.WriteString("User settings", "Width", CStr(VB6.PixelsToTwipsX(Me.Width)), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
            Call modIniFile.WriteString("User settings", "Height", CStr(VB6.PixelsToTwipsY(Me.Height)), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
            Call modIniFile.WriteString("User settings", "Left", CStr(VB6.PixelsToTwipsX(Me.Left)), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
            Call modIniFile.WriteString("User settings", "Top", CStr(VB6.PixelsToTwipsY(Me.Top)), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        End If
        Call modIniFile.WriteString("User settings", "Font size", CStr(gintFontSize), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Font name", txtText.Font.Name, modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Font old", CStr(txtText.Font.Bold), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Show images", CStr(mnuOptionsImages.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Allow popups", CStr(mnuOptionsAllowPopups.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Load welcome page", CStr(False), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Allow messages", CStr(mnuOptionsAllowmessages.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Error URL", CStr(mstrErrorURL), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Toolbar captions", CStr(mnuOptionsToolbarcaptions.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Toolbar visible", CStr(mToolbarVisible), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Default charset", CStr(intDefaultCharset), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Default locale", CStr(lngDefaultLocale), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Always use user default language", CStr(blnAlwaysUseUserDefaultLanguage), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "AllowStartupInIE", CStr(Not CBool(mnuOptionsAlwaysstartintextview.Checked)), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Show IE at startup", CStr(mblnIEVisible), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Homepage URL", gstrCurrentHomepage, modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "Invert text area colours", CStr(Me.mnuOptionsInvertcolours.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "NavigationSounds", CStr(mnuOptionsNavigationsounds.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "QuickKeys", CStr(mnuOptionsUsequickkeys.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        Call modIniFile.WriteString("User settings", "FetchPDFFromGoogle", CStr(mnuOptionsFetchPDFfromGoogle.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        'Ajax support on or off
        'UPGRADE_WARNING: App property App.EXEName has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
        Call modPath.SaveSettingIni(My.Application.Info.AssemblyName, "User Settings", "AjaxSupport", CStr(mnuOptionsAllowajax.Checked))
        'Javascript-only items
        'UPGRADE_WARNING: App property App.EXEName has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
        Call modPath.SaveSettingIni(My.Application.Info.AssemblyName, "User Settings", "JavascriptOnlyItems", CStr(Me.mnuOptionsJavascriptonlyitems.Checked))
        'Numbering links
        Call modIniFile.WriteString("User settings", "NumberLinks", CStr(mnuOptionsNumberlinksandotheritems.Checked), modPath.settingsPath & "\" & My.Application.Info.Title & ".ini")
        'Restore script debugging settings
        Call RestoreScriptErrors()
        'Whether we load favourites as our homepage
        Call SaveSettingIni("WebbIE", "Homepage", "UseFavourites", CStr(mnuOptionsUsefavouritesforhomepage.Checked))
        'unload forms
        Call frmDownloadProgress.Close()
        Call frmGoogle.Close()
        Call frmLanguage.Close()
        Call frmLinks.Close()
        Call frmLocationGetter.Close()
        Call frmParseHTMLHelp.Close()
        Call frmRSS.Close()
        Call frmSelect.Close()
        Call frmTextareaInput.Close()
        Call frmTextView.Close()
        'UPGRADE_NOTE: Object modHTTPGetter.gTargetForm may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        modHTTPGetter.gTargetForm = Nothing
        'UPGRADE_NOTE: Object modCommandProcessor.targetForm may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        modCommandProcessor.targetForm = Nothing
        If mblnIEFavorites Then
            'restore normal command function
            'TODO 
        End If
    End Sub



























































    '===========================================================================================
    ' MENU OPTIONS
    ' Handle the menu bar clicks
    '===========================================================================================

    Public Sub mnuOptionsSethome_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsSethome.Click


        'Update the home page to the current url
        Call SetStartPage((cboAddress.Text))
        'update our global variable: gstrCurrentHomepage
        gstrCurrentHomepage = cboAddress.Text
        'update tooltip
        ToolTip1.SetToolTip(cmdHome, gstrCurrentHomepage)
        'Tell the user what we've done
        MsgBox(modI18N.GetText("Home page changed. WebbIE will come here when it starts or you select Home from the Navigate menu."), MsgBoxStyle.OkOnly)
    End Sub

    Public Sub mnuHelpAbout_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuHelpAbout.Click

        'DEV the About form is inaccessible. Sigh.
        'Call frmAbout.Show(vbModal, Me)  'show the about form
        'Right, that's all the original code gone, I reckon!
        Call MsgBox("WebbIE " & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & "." & My.Application.Info.Version.Revision & vbNewLine & "WebbIE Suite " & modVersion.GetPackageVersion & vbNewLine & "www.webbie.org.uk" & vbNewLine & "Copyright 2002 Gareth Evans and Paul Blenkhorn, 2007 Alasdair King" & vbNewLine & "Free Software released under the GNU Public Licence version 3" & vbNewLine & "This product includes software developed by vbAccelerator (http://vbaccelerator.com/).", MsgBoxStyle.Information, "WebbIE")
    End Sub

    Public Sub mnuOptionsAllowPopups_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsAllowPopups.Click
        'change whether popups are allowed - user setting

        mnuOptionsAllowPopups.Checked = (Not mnuOptionsAllowPopups.Checked)
    End Sub

    Public Sub mnuNavigateBack_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuNavigateBack.Click
        'User selects back option from menu

        Call cmdBack_Click(cmdBack, New System.EventArgs())
    End Sub

    Public Sub mnuBookmarksAddbookmark_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuBookmarksAddbookmark.Click
        'adds a bookmark to the IE favorites list
        'TODO 
        'Call LoadBookmarks
    End Sub

    Private Function GetValidFilename(ByRef inputFilename As String) As String
        'Convert invalid filenames into valid DOS names.

        Dim outputFilename As String

        outputFilename = VB.Left(inputFilename, 255)
        outputFilename = Replace(outputFilename, vbNewLine, "")
        outputFilename = Replace(outputFilename, vbCr, "")
        outputFilename = Replace(outputFilename, vbLf, "")
        outputFilename = Replace(outputFilename, vbTab, "")
        outputFilename = Replace(outputFilename, "\", "_")
        outputFilename = Replace(outputFilename, "/", "_")
        outputFilename = Replace(outputFilename, ":", "_")
        outputFilename = Replace(outputFilename, "*", "_")
        outputFilename = Replace(outputFilename, "?", "_")
        outputFilename = Replace(outputFilename, """", "_")
        outputFilename = Replace(outputFilename, "<", "_")
        outputFilename = Replace(outputFilename, ">", "_")
        outputFilename = Replace(outputFilename, "|", "_")
        outputFilename = Trim(outputFilename)
        GetValidFilename = outputFilename
    End Function

    Public Sub mnuBookmarksOrganisebookmarks_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuBookmarksOrganisebookmarks.Click
        'access the IE bookmark organiser
    End Sub


    Public Sub mnuOptionsChangeFont_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsChangefont.Click
        'user asks to change the font - show appropriate dialogue
        On Error GoTo errorHandler
        'TODO Font
        Exit Sub
errorHandler:
        Resume Next
        Exit Sub
    End Sub

    Public Sub mnuEditCopy_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditCopy.Click
        'process user menu command copy

        'can only copy from address bar and main text box
        If mnuEditCopy.Enabled Then
            Select Case Me.ActiveControl.Name
                Case "txtText"
                    If txtText.SelectedText <> "" Then ' only copy if we have something selected
                        Call My.Computer.Clipboard.Clear()
                        Call My.Computer.Clipboard.SetText(txtText.SelectedText)
                    End If
                Case "cboAddress"
                    If cboAddress.SelectedText <> "" Then ' only copy if we have something selected
                        Call My.Computer.Clipboard.Clear()
                        Call My.Computer.Clipboard.SetText(cboAddress.SelectedText)
                    End If
            End Select
        End If
    End Sub

    Public Sub mnuEditCut_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditCut.Click
        'process user menu command Cut

        Dim selStart As Integer ' position of the cursor in the text to be cut from
        'only works in address bar
        If mnuEditCut.Enabled Then
            If Me.ActiveControl.ToString() = cboAddress.Text And cboAddress.SelectedText <> "" Then
                Call My.Computer.Clipboard.Clear()
                Call My.Computer.Clipboard.SetText(cboAddress.SelectedText)
                selStart = cboAddress.SelectionStart
                cboAddress.Text = VB.Left(cboAddress.Text, cboAddress.SelectionStart) & VB.Right(cboAddress.Text, Len(cboAddress.Text) - cboAddress.SelectionStart - cboAddress.SelectionLength)
                cboAddress.SelectionStart = selStart
            End If
        End If
    End Sub

    Public Sub mnuEditPaste_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditPaste.Click
        'process use clicking paste button in menu

        Dim start As Integer
        Dim length As Integer
        'only works in the address bar
        If mnuEditPaste.Enabled Then
            If Me.ActiveControl.ToString() = cboAddress.Text Then
                start = cboAddress.SelectionStart
                length = Len(My.Computer.Clipboard.GetText)
                cboAddress.Text = VB.Left(cboAddress.Text, cboAddress.SelectionStart) & My.Computer.Clipboard.GetText & VB.Right(cboAddress.Text, Len(cboAddress.Text) - cboAddress.SelectionStart - cboAddress.SelectionLength)
                cboAddress.SelectionStart = start + length
            End If
        End If
    End Sub

    Public Sub mnuEditSelectall_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditSelectall.Click
        'select everything on the text panel current

        If Me.ActiveControl Is txtText Then
            txtText.SelectionStart = 0
            txtText.SelectionLength = Len(txtText.Text)
            'Call ScrollToCursor(txtText)
        ElseIf Me.ActiveControl Is cboAddress Then
            cboAddress.SelectionStart = 0
            cboAddress.SelectionLength = Len(cboAddress.Text)
        End If
    End Sub

    Public Sub mnuFileExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileExit.Click
        'respond to user exiting WebbIE

        '    Dim EndCall As VbMsgBoxResult
        '    'if the user is dialled up on program exit
        '    If (ActiveConnection() = True And gblnModem = True) Then
        '        'prompt for disconnection
        '        EndCall = MsgBox("Would you like to disconnect your Internet connection as well as leave WebbIE?", vbYesNo, "Active Internet connection")
        '    End If
        '    'follow request as above
        '    If EndCall = vbYes Then
        '        Call HangUp
        '    End If
        'unload form
        Me.Close()
    End Sub

    Public Sub mnuFileOpen_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileOpen.Click
        'open an html file on disk or internet if a url

        Dim Path As String
        Dim fso As New Scripting.FileSystemObject
        Dim url As String

        If My.Application.Info.Version.Minor > 5 Then
            'UPGRADE_WARNING: Filter has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
            cdlgOpen.Filter = modI18N.GetText("HTML file") & " (*.htm, *.html)|*.htm;*.xhtm;*.html;*.xhtml;*.mht|" & modI18N.GetText("HTML Help files") & " (*.chm)|*.chm|" & modI18N.GetText("PDF Files") & " (*.pdf)|*.pdf|" & modI18N.GetText("All files") & " (*.*)|*.*;"
        Else
            'UPGRADE_WARNING: Filter has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
            cdlgOpen.Filter = modI18N.GetText("HTML file") & " (*.htm, *.html)|*.htm;*.xhtm;*.html;*.xhtml;*.mht|" & modI18N.GetText("HTML Help files") & " (*.chm)|*.chm|" & modI18N.GetText("All files") & " (*.*)|*.*;"
        End If
        cdlgOpen.Title = modI18N.GetText("Load HTML file")
        On Error GoTo cancelError
        'UPGRADE_WARNING: MSComDlg.CommonDialog property cdlg.Flags was upgraded to cdlgOpen.ShowReadOnly which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
        'UPGRADE_WARNING: FileOpenConstants constant FileOpenConstants.cdlOFNHideReadOnly was upgraded to OpenFileDialog.ShowReadOnly which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
        cdlgOpen.ShowReadOnly = False
        Call cdlgOpen.ShowDialog()
        'if we have a valid filename, try to load it...
        Dim w As IWshRuntimeLibrary.WshShell
        Dim cmdline As String
        Dim outputFile As String
        If cdlgOpen.FileName <> "" Then
            'okay, is this a valid file?
            If fso.FileExists(cdlgOpen.FileName) Then
                'Compiled HTML help file?
                If StrComp(VB.Right(cdlgOpen.FileName, 3), "chm", CompareMethod.Text) = 0 Then
                    'compiled html help
                    frmParseHTMLHelp = New frmParseHTMLHelp
                    Path = frmParseHTMLHelp.ConvertHTMLHelp((cdlgOpen.FileName))
                    If Len(Path) > 0 Then
                        Call StartNavigating(Path)
                    End If
                ElseIf LCase(VB.Right(cdlgOpen.FileName, 4)) = ".pdf" Then
                    'PDF file!
                    outputFile = Replace(cdlgOpen.FileName, ".pdf", "", , , CompareMethod.Text)
                    cmdline = """" & My.Application.Info.DirectoryPath & "\pdftohtml.exe"" """ & cdlgOpen.FileName & """ """ & outputFile & """ -c -p -noframes"
                    w = New IWshRuntimeLibrary.WshShell
                    'MsgBox "Running: [" & outputFile & "]"
                    Call w.Run(cmdline, , True)
                    'UPGRADE_NOTE: Object w may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
                    w = Nothing
                    outputFile = outputFile & ".html"
                    Call StartNavigating(outputFile)
                Else
                    'html
                    Call StartNavigating((cdlgOpen.FileName))
                End If
                'Call mWebBrowser.Navigate2(cdlg.FileName)
                'cboAddress.Text = cdlg.FileName
                'Call cmdGo_Click
            Else
                'nope: is it a url?
                'Remove .htm at the end - 3.7.0.
                'UPGRADE_WARNING: CommonDialog property cdlg.FileTitle was upgraded to cdlg.FileName which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
                If InStr(1, cdlgOpen.FileName, ".") > 0 Then
                    'UPGRADE_WARNING: CommonDialog property cdlg.FileTitle was upgraded to cdlg.FileName which has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="DFCDE711-9694-47D7-9C50-45A99CD8E91E"'
                    url = cdlgOpen.FileName
                    If Len(url) > 4 Then
                        If LCase(VB.Right(url, 4)) = ".htm" Then
                            url = VB.Left(url, Len(url) - 4)
                        End If
                    End If
                    If Len(url) > 5 Then
                        If LCase(VB.Right(url, 5)) = ".html" Then
                            url = VB.Left(url, Len(url) - 5)
                        End If
                    End If
                    Call StartNavigating(url)
                Else
                    Call PlayErrorSound()
                End If
            End If
        End If
        Exit Sub
cancelError:
        'user clicked cancel
        Exit Sub
    End Sub

    Private Function CalculateWebpageFilename() As String
        'works out what we should call a webpage we save to disk
        On Error GoTo defaultName
        'first check to see we have loaded a page
        If mWebBrowser.ReadyState = System.Windows.Forms.WebBrowserReadyState.Uninitialized Then
            'not gone anywhere yet!
            CalculateWebpageFilename = ""
        Else
            'okay, we have a page
            'TODO Can't do this without late binding. 
            'Use page title for now.
            CalculateWebpageFilename = mWebBrowser.Document.Title

            '         'CalculateWebpageFilename = mWebBrowser.Document.DomDocument.location.pathname
            '         'Set to "/" instead to force creation of new filename from title.
            '         CalculateWebpageFilename = "/"

            'If CalculateWebpageFilename = "/" Then
            '	'no path in url: use the page name, converted into ansi, if any
            '	'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.title. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            '	If Len(mWebBrowser.Document.DomDocument.title) > 0 Then
            '                 CalculateWebpageFilename = mWebBrowser.Document.DomDocument.title.ToString
            '             Else
            '                 'okay, no page title: use the domain name with stops replaced by hyphens
            '                 'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.location. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            '                 CalculateWebpageFilename = Replace(mWebBrowser.Document.DomDocument.location.hostName, ".", "-")
            '	End If
            'Else
            '	'there is a path in the url: use the actual filename
            '	CalculateWebpageFilename = VB.Right(CalculateWebpageFilename, Len(CalculateWebpageFilename) - InStrRev(CalculateWebpageFilename, "/"))
            '	'check for a backslash in case we have a local file
            '	If InStr(1, CalculateWebpageFilename, "\", CompareMethod.Binary) > 0 Then
            '		CalculateWebpageFilename = VB.Right(CalculateWebpageFilename, Len(CalculateWebpageFilename) - InStrRev(CalculateWebpageFilename, "\"))
            '	End If
            'End If
            'replace any invalid characters
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, "\", "-")
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, "/", "-")
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, ":", "-")
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, "*", "-")
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, "?", "-")
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, """", "-")
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, "<", "-")
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, ">", "-")
            CalculateWebpageFilename = Replace(CalculateWebpageFilename, "|", "-")
        End If
        Exit Function
defaultName:
        CalculateWebpageFilename = "webpage"
    End Function

    Public Sub mnuFileSave_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileSave.Click
        ''save the current webpage
        '     
        '     If Len(mstrCurrentPageFilename) > 0 Then
        '        'we've already saved this page with Save As, so we can just quickly
        '        'save it with the same name and location
        '        Dim fso As Variant ' As new FileSystemObject
        '        Set fso = CreateObject("Scripting.FileSystemObject")
        '        Dim fil As Variant 'As File
        '        Set fil = fso.CreateTextFile(mstrCurrentPageFilename, True)
        '        Call fil.write("<html><head><title>" & mWebBrowser.LocationName & _
        ''            "</title></head>" & mWebBrowser.Document.body.innerHTML & "</html>")
        '        Set fil = Nothing
        '        Set fso = Nothing
        '    Else
        '        'not already saved page, call save as
        Call mnuFileSaveas_Click(mnuFileSaveas, New System.EventArgs())
        '    End If
    End Sub

    Public Sub mnuFileSaveas_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileSaveas.Click
        'saves the current webpage as an html file

        '3.5.2 All that crap about saving, none of it works, and no-one much has complained. So just
        'use SaveAs on WebBrowser.
        'TODO Can't use late binding. Not sure what to do?
        'Call mWebBrowser.ActiveXInstance.ExecCommand(Exec.OLECMDID_SAVEAS, ExecOpt.OLECMDEXECOPT_PROMPTUSER)

        '    cdlg.DefaultExt = "htm"
        '    cdlg.Filter = modi18n.GetText("HTML file") & " (*.htm)|*.htm|" & modi18n.GetText("Text file") & " (*.txt)|*.txt"
        '    cdlg.DialogTitle = modi18n.GetText("Save webpage")
        '    cdlg.Flags = cdlOFNOverwritePrompt Or cdlOFNPathMustExist
        '    'work out the default filename for the file
        '    cdlg.fileName = CalculateWebpageFilename
        '    On Error GoTo cancelError
        '    Call cdlg.ShowSave
        '    
        '    If cdlg.fileName <> "" Then
        '        If cdlg.FilterIndex = 1 Then
        '            'html
        '            Call DoSaveWebpage(cdlg.fileName)
        '            mstrCurrentPageFilename = cdlg.fileName
        '        ElseIf cdlg.FilterIndex = 2 Then
        '            'text
        '            Dim fso As Variant ' As new FileSystemObject
        '            Set fso = CreateObject("Scripting.FileSystemObject")
        '            Dim fil As Variant 'As File
        '            Set fil = fso.CreateTextFile(cdlg.fileName, True)
        '            Call fil.write(txtText.text)
        '            Set fil = Nothing
        '            Set fso = Nothing
        '        End If
        '    End If
        '    Exit Sub
        'cancelError:
        '    'user clicked "Cancel"
        '    Exit Sub
    End Sub

    Private Sub DoSaveWebpage(ByRef pathname As String)
        'saves the current page, if any, to the pathname indicated by pathname
        'preconditions: mWebBrowser.Document is a loaded document, and pathname is a valid pathname

        Dim content As String
        Dim fso As New Scripting.FileSystemObject
        Dim fil As Scripting.TextStream
        Dim mshtmlDoc As mshtml.HTMLDocument

        'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.documentElement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        mshtmlDoc = CType(mWebBrowser.Document.DomDocument, mshtml.HTMLDocument)
        content = mshtmlDoc.documentElement.outerHTML
        fil = fso.OpenTextFile(cdlgOpen.FileName, Scripting.IOMode.ForWriting, True, Scripting.Tristate.TristateUseDefault)
        Call fil.Write(content)
        'Call fil.write("<html><head><title>" & mWebBrowser.LocationName & _
        '"</title></head>" & mWebBrowser.Document.body.innerHTML & "</html>")
        Call fil.Close()
        'UPGRADE_NOTE: Object fil may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        fil = Nothing
        'UPGRADE_NOTE: Object fso may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        fso = Nothing

    End Sub

    Public Sub mnuEditFindnext_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditFindnext.Click
        'Find the next instance of a word searched for by the user

        Dim where As Integer
        Dim originalPos As Integer
        Dim searchIn As String
        
        If findText <> "" Then
            originalPos = txtText.SelectionStart 'go to start of the found word
            'make lower case and search onwards from the existing word
            searchIn = Mid(txtText.Text, originalPos + 2, Len(txtText.Text) - txtText.SelectionStart - 2)
            where = InStr(1, searchIn, findText, CompareMethod.Text)
            If (where > 0) Then 'if found
                where = where + originalPos
                'startLine = GetCurrentLineIndex(txtText)
                txtText.SelectionStart = where
                txtText.SelectionLength = Len(findText) 'highlight the word
                'endLine = GetCurrentLineIndex(txtText)
                'Call Scroll(txtText, endLine - startLine)
                'Call ScrollToCursor(txtText)
            Else
                'if unfound, display a warning
                MsgBox(modI18N.GetText("No further occurrences found"), MsgBoxStyle.Information, modI18N.GetText("Word not found"))
            End If
        Else 'if there is no text to search
            Call mnuEditFindtext_Click(mnuEditFindtext, New System.EventArgs())
        End If
    End Sub

    Public Sub mnuEditFindtext_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditFindtext.Click
        'Find a word looked for in the main text box

        Dim where As Integer
        'Dim startLine As Long
        'Dim endLine As Long

        'Are we in IE view?
        If mblnIEVisible Then
            'do search in IE, somehow.
            Dim wb As SHDocVw.WebBrowser
            wb = CType(mWebBrowser.ActiveXInstance, SHDocVw.WebBrowser)
            Call wb.ExecWB(SHDocVw.OLECMDID.OLECMDID_FIND, SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_DODEFAULT)
        Else
            'in text view
            findText = InputBox(modI18N.GetText("Enter text to find"), modI18N.GetText("Search string"), findText)
            'if OK is clicked
            If findText <> "" Then
                ' Find string in text
                where = InStr(txtText.SelectionStart + 2, txtText.Text, findText, CompareMethod.Text)
                If where > 0 Then ' If found..
                    Debug.Print("Found first time")
                    Call txtText.Focus()
                    'startLine = GetCurrentLineIndex(txtText)

                    txtText.SelectionStart = where - 1 ' set selection start and
                    txtText.SelectionLength = Len(findText) ' set selection length
                    'endLine = GetCurrentLineIndex(txtText)
                    'Call ScrollToCursor(txtText)
                    'Call Scroll(txtText, endLine - startLine)
                    'we've found something, we can try to find it again...
                Else
                    'try from start
                    where = InStr(1, txtText.Text, findText, CompareMethod.Text)
                    If where > 0 Then
                        'found it: is it where we started?
                        If where = txtText.SelectionStart + 1 Then
                            'whoops, already there
                            'Debug.Print "Already there"
                            MsgBox(modI18N.GetText("No more") & " " & findText, MsgBoxStyle.Information, modI18N.GetText("Word not found"))
                        Else
                            'nope, go there
                            Call txtText.Focus()
                            txtText.SelectionStart = where - 1
                            txtText.SelectionLength = Len(findText)
                        End If
                    Else
                        'not found at all
                        MsgBox(modI18N.GetText("Cannot find") & " " & findText, MsgBoxStyle.Information, modI18N.GetText("Word not found"))
                    End If
                End If
            End If
        End If
    End Sub

    Public Sub mnuNavigateForward_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuNavigateForward.Click

        cmdForward_Click(cmdForward, New System.EventArgs())
    End Sub

    Private Sub mnuOptionsLanguage_Click()
        'call the set language form for setting the default homepage

        Call VB6.ShowForm(frmLanguage, VB6.FormShowConstants.Modal, Me)
    End Sub

    Public Sub mnuhelpcontents_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuHelpContents.Click
        'displays simple text boxes with help information depending on index

        'TODO
    End Sub


    Public Sub mnuNavigateHome_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuNavigateHome.Click

        cmdHome_Click(cmdHome, New System.EventArgs())
    End Sub

    Public Sub mnuOptionsImages_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuOptionsImages.Click
        'turn on or off the display of images

        mnuOptionsImages.Checked = Not mnuOptionsImages.Checked
        Call RefreshCurrentPage()
    End Sub

    Public Sub mnuLinksNextLink_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuLinksNextlink.Click

        Dim lineNumber As Integer
        Dim linkFound As Boolean

        If Me.txtText.Text <> "" Then
            lineNumber = GetCurrentLineIndex(txtText) + 1
            linkFound = False
            While lineNumber < GetNumberOfLines(txtText) And Not linkFound
                If StrComp(VB.Left(GetNumberedLine(txtText, lineNumber), Len(ID_LINK)), ID_LINK, CompareMethod.Text) = 0 Then
                    'found a link
                    linkFound = True
                Else
                    lineNumber = lineNumber + 1
                End If
            End While
            If linkFound Then
                txtText.SelectionStart = GetCharacterIndexOfLine(txtText, lineNumber)
                'Don't set length of link.
                'txtText.SelLength = Len(Trim(GetCurrentLine(txtText)))
                'Call ScrollToCursor(txtText)
            Else
                Call PlayErrorSound()
            End If
        End If
    End Sub

    Public Sub mnuFilePrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFilePrint.Click
        'print the webpage

        Dim output As String
        Dim fso As New Scripting.FileSystemObject
        Dim tempFile As String

        'The following doesn't always (second time) show the cdlg, so I can't use it - don't know why.
        ''    On Error GoTo cancelError:
        ''    Call cdlg.ShowPrinter
        ''    'ASSERTION: the user has selected a printer
        ''    
        ''    Printer.Copies = cdlg.Copies  'the number of copies required
        ''    Printer.CurrentX = 100
        ''    Printer.CurrentY = 100
        ''    Printer.Print (txtText.Text)               'print the text box on the main form
        ''    Call Printer.EndDoc 'tell printer the end of the document has been reached
        ''    Exit Sub
        ''cancelError:
        ''    Exit Sub
        'if we're in IE view, print that: otherwise, print the text contents
        If mblnIEVisible Then
            'browser contents
            Dim wb As SHDocVw.WebBrowser
            wb = CType(mWebBrowser.ActiveXInstance, SHDocVw.WebBrowser)
            Call wb.ExecWB(SHDocVw.OLECMDID.OLECMDID_PRINT, SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER)
        Else
            'text
            'change text into HTML and use workBrowser to print it
            output = txtText.Text
            output = Replace(txtText.Text, vbNewLine, "<br>")
            output = "<html><head><title>" & Me.Text & "</title><style type=""text/css"">* { font-family:" & txtText.Font.Name & ";font-size:" & txtText.Font.SizeInPoints & ";}</style></head><body>" & output & "</body></html>"
            tempFile = System.IO.Path.GetTempPath & "\" & System.IO.Path.GetTempFileName & ".htm"
            Dim sw As System.IO.StreamWriter = New System.IO.StreamWriter(tempFile)
            Call sw.Write(output)
            Call sw.Close()
            Call workBrowser.Navigate(New System.Uri(tempFile))
        End If
    End Sub

    Public Sub mnuNavigateRefresh_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuNavigateRefresh.Click

        cmdRefresh_Click(cmdRefresh, New System.EventArgs())
    End Sub

    Public Sub mnuNavigateStop_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuNavigateStop.Click

        Call cmdStop_Click(cmdStop, New System.EventArgs())
    End Sub

    Public Sub mnuViewIE_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuViewIE.Click

        Call cmdViewIE_Click(cmdViewIE, New System.EventArgs())
    End Sub

    Public Sub mnuLinksViewLinks_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuLinksViewlinks.Click

        Dim i As Integer
        Dim j As Integer
        Dim tempLinks As linkStruct
        Dim swapping As Boolean 'whether bubble sorting is complete

        'Sort links into alphabetical order
        For i = 1 To numLinks
            'UPGRADE_WARNING: Couldn't resolve default property of object sortedLinks(i). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            sortedLinks(i) = links(i)
        Next i

        'initialise swapping to ensure loop entry
        swapping = True

        'start bubble (up) sort
        While swapping
            'ensures the until loop breaks when swapping finishes
            swapping = False
            'count through the links
            For i = 1 To (numLinks - 1)
                j = i + 1 'let i lag j by one place
                'if swapping is needed, perform the swap
                If (StrComp(sortedLinks(i).description, sortedLinks(j).description, CompareMethod.Text) > 0) Then
                    'UPGRADE_WARNING: Couldn't resolve default property of object tempLinks. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    tempLinks = sortedLinks(j) 'save the later item
                    'UPGRADE_WARNING: Couldn't resolve default property of object sortedLinks(j). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    sortedLinks(j) = sortedLinks(i) 'overwrite the later item with the earlier one
                    'UPGRADE_WARNING: Couldn't resolve default property of object sortedLinks(i). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    sortedLinks(i) = tempLinks 'make the later item, the earlier one
                    'indicate that swapping still occurs
                    swapping = True
                End If
            Next i
        End While
        Call frmLinks.PopulateList()
        frmLinks.cmdGo.Enabled = False
        Call VB6.ShowForm(frmLinks, VB6.FormShowConstants.Modal, Me) 'display the links form
    End Sub

    Public Sub mnuEditWebsearch_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditWebsearch.Click
        'pop up a box to prompt user for a search phrase for google

        If Not frmGoogle.Visible Then
            Call VB6.ShowForm(frmGoogle, VB6.FormShowConstants.Modal, Me)
        End If
    End Sub




























































    '============================================================================================
    ' TIMER FUNCTIONS
    ' The events and updates driven by timer activity
    '============================================================================================
    Private Sub tmrConnectionPoller_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrConnectionPoller.Tick
        'check to see if we're online and update status bar

        If gExiting Then
            tmrConnectionPoller.Enabled = False
        Else
            'TODO 
            'If GetOnlineStatus Then
            '	staMain.Items.Item("txtconnection").Text = modI18N.GetText("Connected")
            'Else
            '	staMain.Items.Item("txtconnection").Text = modI18N.GetText("Disconnected")
            'End If
        End If
    End Sub

    Private Sub tmrBusyAnimation_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles tmrBusyAnimation.Tick

        'every 0.3 second, move the animation. Play working sound
        Static intcounter As Integer 'static retains value on each call

        Call picBusyDone.SendToBack()
        Call picBusyDoneSmall.SendToBack()

        If mWebBrowser.IsBusy Then
            Select Case intcounter
                Case 0
                    _picBusyAnimation_0.Visible = mToolbarVisible
                    _picBusySmall_0.Visible = mToolbarVisible
                    _picBusyAnimation_3.Visible = False
                    _picBusySmall_3.Visible = False
                    intcounter = 1
                    Call PlayWorkingSound()
                Case 1
                    _picBusyAnimation_1.Visible = mToolbarVisible
                    _picBusySmall_1.Visible = mToolbarVisible
                    _picBusyAnimation_0.Visible = False
                    _picBusySmall_0.Visible = False
                    intcounter = 2
                Case 2
                    _picBusyAnimation_2.Visible = mToolbarVisible
                    _picBusySmall_2.Visible = mToolbarVisible
                    _picBusyAnimation_1.Visible = False
                    _picBusySmall_1.Visible = False
                    intcounter = 3
                Case 3
                    _picBusyAnimation_3.Visible = mToolbarVisible
                    _picBusySmall_3.Visible = mToolbarVisible
                    _picBusyAnimation_2.Visible = False
                    _picBusySmall_2.Visible = False
                    intcounter = 0
            End Select
        End If
    End Sub






















































    '==========================================================================================
    ' UTILITY ROUTINES
    ' Used for common or esoteric things that are best put in their own routines
    '==========================================================================================

    Private Sub ClearPageData()
        'Clears the page arrays

        numForms = 0
        numFileInputs = 0
        numTextInputs = 0
        numLinks = 0
        numTargets = 0
        numTables = 0
        numSelects = 0
        numImages = 0
        numPassInputs = 0
        numSubmitInputs = 0
        numResetInputs = 0
        numCheckboxInputs = 0
        numRadioInputs = 0
        numButtonInputs = 0
        numTextAreaInputs = 0
        numObjects = 0
        Call modFormLabelHandler.Clear()
        imageHrefs = New Collection
        gstrRSSFeedURL = ""
    End Sub

    Private Sub DisplayObject(ByRef itemNumber As Integer)
        'displays the item indicated by itemNumber (index to objects array) in a pop-up browser

        Dim element As mshtml.IHTMLElement
        Dim element2 As mshtml.IHTMLElement2
        Dim element3 As mshtml.IHTMLElement3
        
        element = objects(itemNumber)
        element2 = CType(element, mshtml.IHTMLElement2)
        element3 = CType(element, mshtml.IHTMLElement3)
        'okay, now change focus to this object in the IE view
        If mblnIEVisible Then
            'already visible, don't need to do anything
        Else
            'oops, IE not visible: make it so by clicking on the button
            cmdViewIE_Click(cmdViewIE, New System.EventArgs())
        End If
        'the below works if this is Flash, but Java never gets focus. Oh well.
        'Hope the user's screen reader can get at it...
        'now set focus on element
        element2.tabIndex = 0
        'UPGRADE_WARNING: Couldn't resolve default property of object element.scrollIntoView. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        Call element.scrollIntoView()
        Call element2.focus()
        element3.setActive()
    End Sub

    Private Sub DisplayOutput(ByRef output As String)
        'displays the contents of output in the txtText text box but strips out any blank lines along
        'the way


        'Variables for Method 1 of removing blank lines
        Dim splitOutput() As String
        Dim i As Integer
        Dim numberSplitStrings As Integer
        Dim writtenBlank As Boolean
        Dim gotLine As String
        Dim nextLine As String
        '    'Variables for Method 2 of removing blank lines
        '    Dim doubleNewline As String
        '    Dim lineWithSpace As String
        '    'Variables for Method 3 of removing blank lines
        '    Dim aRegExp As New RegExp
        '    aRegExp.Pattern = "\r\n\s*\r\n"
        '    aRegExp.Global = True

        Dim doc As mshtml.HTMLDocument
        doc = CType(mWebBrowser.Document.DomDocument, mshtml.HTMLDocument)
        If doc.title.ToString = "" Then
            'No use telling the user there is no title...
            txtText.Text = ""
        Else
            txtText.Text = modI18N.GetText("WEBPAGE:") & " " & mWebBrowser.Document.Title
        End If
        txtText.Text = txtText.Text & vbNewLine & vbNewLine
        'Removing blank lines in the text output: three problems, (1) should we do it?
        '(2) how thoroughly do we do it (3) how do we make it efficient for big files?
        'One option is to check the size of the html file and if too big, simply
        'skip this process. Another might be to parse a big chunk and display that
        'while getting on with the rest - but appending would be messy.

        'Method 3
        'txtText.Text = txtText.Text & aRegExp.Replace(output, vbNewLine)

        '    'Method 2
        '    'This new approach doesn't get every single line, but should be faster.
        '    lineWithSpace = vbNewLine & " " & vbNewLine
        '    While InStr(1, output, lineWithSpace, vbBinaryCompare) > 0
        '        output = Replace(output, lineWithSpace, vbNewLine)
        '    Wend
        '    doubleNewline = vbNewLine & vbNewLine
        '    While InStr(1, output, doubleNewline, vbBinaryCompare) > 0
        '        output = Replace(output, doubleNewline, vbNewLine, 1)
        '    Wend
        '    If InStr(1, output, vbNewLine) = 1 Then
        '        'don't want to have a blank line at the beginning:
        '        output = Left(output, Len(output) - 1)
        '    End If
        '    txtText.Text = txtText.Text & output

        'Method 1
        'This is the previous method, which is slower for lots of lines but much
        'more thorough than the above method.
        splitOutput = Split(output, vbNewLine)
        output = txtText.Text
        numberSplitStrings = -1
        numberSplitStrings = UBound(splitOutput)
        If numberSplitStrings < 4000 And numberSplitStrings > -1 Then
            nextLine = Trim(splitOutput(0))
            For i = 0 To numberSplitStrings - 1
                gotLine = nextLine
                nextLine = Trim(splitOutput(i + 1))
                If Len(gotLine) > 0 Then
                    If gotLine = "hytghytg" Then
                        If Not writtenBlank Then
                            output = output & vbNewLine
                            writtenBlank = True
                        End If
                    Else
                        If i < numberSplitStrings Then
                            If Len(gotLine) < 3 Then
                                If VB.Left(nextLine, Len(ID_LINK)) = ID_LINK Then
                                    'we have a line of text where we have a line immediately following but
                                    'the current line is only two characters: typically this is where we
                                    'have something like [edit] on Wikipedia. This will let us have
                                    'LINK 1: [edit]
                                    'rather than
                                    '[
                                    'LINK1: edit]
                                    nextLine = VB.Left(nextLine, InStr(1, nextLine, ":") + 1) & gotLine & " " & VB.Right(nextLine, Len(nextLine) - InStr(1, nextLine, ":") - 1)
                                    gotLine = ""
                                End If
                            End If
                        End If
                        If Len(gotLine) > 0 Then
                            output = output & gotLine & vbNewLine
                            writtenBlank = False
                        End If
                    End If
                End If
            Next i
        Else
            output = Join(splitOutput, vbNewLine)
            output = Replace(output, "hytghytg" & vbNewLine, "")
        End If
        txtText.Text = output
        'If we have any content, let the user select it.
        If Len(output) > 0 Then
            mnuEditSelectall.Enabled = True
        Else
            mnuEditSelectall.Enabled = False
        End If
    End Sub

    Private Sub SaveImage()
        'saves the image on the current line to disk: user presses ctrl+shift+k to get here...

        Dim currentLine As String
        Dim lines() As String
        Dim imageCount As Integer
        Dim target As Integer
        Dim charCount As Integer
        Dim i As Integer

        currentLine = Trim(GetCurrentLine(txtText))
        currentLine = VB.Left(currentLine, Len(currentLine) - 1)
        If InStr(1, currentLine, modI18N.GetText("IMAGE:"), CompareMethod.Binary) = 1 Then
            'we're on an image line okay, so we can save it
            'first we have to identify it: count to find out which image this is
            target = txtText.SelectionStart ' this is the cursor position on the current line: when we go past this,
            'we've counted all the images up to and including the current one
            lines = Split(txtText.Text, vbNewLine)
            imageCount = 0
            i = 0
            charCount = 0
            While charCount < target ' repeat until we've gone past the cursor
                If InStr(1, lines(i), modI18N.GetText("IMAGE:"), CompareMethod.Binary) = 1 Then
                    'this is an image!
                    imageCount = imageCount + 1
                End If
                charCount = charCount + Len(lines(i)) + 1
                i = i + 1
            End While
            'assertion: imageCount = index of image in imageHref collection
            'Debug.Print "href=" & imageHrefs(imageCount)
            'UPGRADE_WARNING: Couldn't resolve default property of object imageHrefs(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            Call workBrowser.Navigate(New System.Uri(imageHrefs.Item(imageCount).ToString))
        End If
    End Sub

    Private Function ExtractHREFLink(ByRef href As String) As String
        'strips out the functional parts of a URL (href) to the file or domain name - so it takes
        'off ports, get information, protocol information etc.

        Dim link As String ' the href of the link
        Dim postProtocolStart As Integer ' the position of the first character after the
        ' "whateverprototol://" bit
        Dim slashPosition As Integer ' the position of the last filename delimiter found
        Dim newSlashPosition As Integer ' the next one found
        Dim firstQuestionMark As Integer ' the position of a question mark,
        ' indicating the arguments passed to a page.  These will excised
        Dim linkLength As Integer ' the length of the bit we want to use

        link = Trim(href)
        firstQuestionMark = InStr(1, link, "?") ' the start of a query string
        If firstQuestionMark = 0 Then firstQuestionMark = Len(link) + 1
        'now excise any query string
        link = Mid(link, 1, firstQuestionMark - 1)

        postProtocolStart = InStr(1, link, "//") ' to start of // if any

        If postProtocolStart > 0 Then
            'it's an absolute link - e.g. "http://site.com"
            'take off ending / if any
            If VB.Right(link, 1) = "/" Then link = VB.Left(link, Len(link) - 1)
            postProtocolStart = postProtocolStart + 2
            slashPosition = postProtocolStart
            'ASSERTION: slashPosition is the first character after the protocol
            'now find the possible filename
            newSlashPosition = InStr(slashPosition, link, "/")
            While newSlashPosition > 0
                'ASSERTION: we've found a(nother) "/"
                slashPosition = newSlashPosition + 1
                newSlashPosition = InStr(slashPosition, link, "/")
            End While
            'ASSERTION: there is no (other) "/" character after slashPosition
            'if the position has moved on from the "//" then we've got a
            'local file, _unless_
            'it is also the end of the string.
            If slashPosition > postProtocolStart And slashPosition < Len(link) Then
                'hurrah, we have a local file: it'll run from slashPosition to the end
                linkLength = Len(link) - slashPosition + 1 ' plus one includes the character marked by
                'slashPosition - I hate not counting from zero... ruddy VB...
                link = Mid(link, slashPosition, linkLength)
            Else
                'nope, we don't have a local file: the slash must be the end of the link,
                'OR we haven't moved at all from the // bit
                'e.g. "www.yahoo.com/" or "http://www.yahoo.com", so just use the host: get this by
                'going from the end of the "(ht)tp://" bit to the character
                'before the end, which is a "/".
                If Len(link) = 0 Then
                    link = modI18N.GetText("Unidentified link")
                Else
                    link = Mid(link, InStr(1, link, "tp://") + 5, Len(link) - (InStr(1, link, "tp://") + 4))
                End If
            End If
        Else
            'it's a relative link - e.g. "nextpage.htm" - and might have an argument
            'try just using the link itself, less any argument
            'get rid of any directories
            slashPosition = 1
            newSlashPosition = InStr(slashPosition, link, "/")
            While newSlashPosition > 0
                'ASSERTION: we've found a(nother) "/"
                slashPosition = newSlashPosition + 1
                newSlashPosition = InStr(slashPosition, link, "/")
            End While
            linkLength = Len(link) - slashPosition + 1 ' plus one includes the character marked by
            'slashPosition - I hate not counting from zero... ruddy VB...
            link = Mid(link, slashPosition, linkLength)
        End If
        link = VB.Left(link, 64)
        'now strip off filename extensions for known file types
        If LCase(VB.Right(link, 4)) = ".htm" Then link = VB.Left(link, Len(link) - 4)
        If LCase(VB.Right(link, 5)) = ".html" Then link = VB.Left(link, Len(link) - 5)
        If LCase(VB.Right(link, 4)) = ".php" Then link = VB.Left(link, Len(link) - 4)
        If LCase(VB.Right(link, 4)) = ".asp" Then link = VB.Left(link, Len(link) - 4)
        If LCase(VB.Right(link, 5)) = ".shtm" Then link = VB.Left(link, Len(link) - 5)
        If LCase(VB.Right(link, 6)) = ".shtml" Then link = VB.Left(link, Len(link) - 6)
        ExtractHREFLink = link
    End Function

    Private Function GetDomainFromURL(ByRef url As String) As String
        'returns just the domain from a url (e.g. from http://www.yahoo.com/news/today.htm returns http://www.yahoo.com

        Dim slashPosition As Integer
        slashPosition = InStr(1, url, "//") + 2 ' get past protocol:// section
        slashPosition = InStr(slashPosition, url, "/") ' find the next /
        If slashPosition = 0 Then
            GetDomainFromURL = url ' if there is no other, just use the whole thing
        Else
            GetDomainFromURL = VB.Left(url, slashPosition - 1) ' use domain (less slash)
        End If
    End Function

    Private Function GetDomainWithoutURL(ByRef url As String) As String
        'strips off the protocol information for a url

        If InStr(1, url, "//") > 0 Then
            GetDomainWithoutURL = VB.Right(url, Len(url) - InStr(1, url, "//") - 1)
        Else
            GetDomainWithoutURL = url
        End If
    End Function

    Private Sub ParseDocument()
        'process through the website to create the text output

        Dim output As String
        Dim got As String = ""
        Dim doc As mshtml.HTMLDocument
        Dim node As mshtml.IHTMLDOMNode

        'tell user we've progressed from downloading to processing
        staMain.Items.Item(0).Text = modI18N.GetText("Examining")
        'Dev: I'm going to take out this page update since it might make things
        'slicker, fewer updates, less flicker and speech restarting.
        'txtText.text = modi18n.GetText("Examining")
        'display update in browser text box
        'Don't change the page until we've done loading and displaying.
        'Update the number of nodes we're going to process for our Ajax processing
        mAjaxNodeCount = -1
        If mWebBrowser.Document.Body Is Nothing Then
        Else
            mAjaxNodeCount = mWebBrowser.Document.Body.All.Count
        End If
        'Reset the terminate flag
        mTerminateParsing = False
        'check for an error page
        If mblnErrorPage Then
            'oh no, error page!
            mblnErrorPage = False
            output = mWebBrowser.Document.Body.InnerText
        Else
            'parse the document into txtText
            output = ""
            mblnJustDidLink = False
            mstrnewline = ""
            'TODO handle non-HTML document types by checking document.mimeType.
            'process HTML if that is what we have
            'check to see if this document contains (or should contain)
            'the target id found, if any
            'TODO Handle frames for headings.
            doc = CType(mWebBrowser.Document.DomDocument, mshtml.HTMLDocument)
            node = CType(doc.body, mshtml.IHTMLDOMNode)
            'TODO Handle frames for labels.
            Call modFormLabelHandler.ProcessWebpageForLabels(doc)
            Call IdentifyHeadings(CType(node, mshtml.IHTMLElement))
            got = ParseNode(node)
            If Len(got) > 0 Then
                output = output & got & vbNewLine
            End If
        End If
        'Replace form count with final tally
        If mShowFormsOnly Then output = Replace(output, "LKJLKJLKJLKJLKJLKJLKJ", CStr(numForms))
        Call DisplayOutput(output)
        cmdStop.Enabled = False
        cmdRefresh.Enabled = True
        staMain.Items.Item(0).Text = modI18N.GetText("Done") 'once parsing is complete, change status to idle
        Call picBusyDone.BringToFront()
        Call picBusyDoneSmall.BringToFront()
        mnuLinksViewlinks.Enabled = True 'allow the links to be viewed in a seperate form
        cboAddress.SelectionLength = 0 ' don't select any of the text in the address bar
        cboAddress.SelectionStart = 1 ' put the cursor at the beginning
        Call cboAddress.Refresh() ' redraw it

        'DEV: moved all this stuff to Documentcomplete because I don't want it
        'firing when I just click refresh.
        '    'linemarker stuff: determine where we're going to put the caret
        '    'lineNumber = gobjBackForwardsHandler.GetLineNumberAndClear
        '    Debug.Print "Looking for [" & mWebBrowser.LocationURL & "]: " & mobjNavigationRecord.Exists(mWebBrowser.LocationURL)
        '    If mobjNavigationRecord.Exists(mWebBrowser.LocationURL) Then
        '        lineNumber = mobjNavigationRecord.item(mWebBrowser.LocationURL)
        '        Debug.Print "Got line: " & lineNumber
        '    End If
        '    If lineNumber > 0 Then
        '        'okay, we have to go somewhere
        '        txtText.selStart = GetCharacterIndexOfLine(txtText, lineNumber)
        '        txtText.SelLength = 0
        '    Else
        '        'not gone back/forwards: try going to internal link
        '        Call MoveCursorToInternalLink(Me)
        '    End If
        If mblnIEVisible Then
            'don't do any focus changing if we're looking at the IE box
        Else
            'Call cboAddress.SetFocus      ' change focus to main box and back: helps trigger screen reader to read
            'DoEvents
            'Call txtText.SetFocus
            '3.8.0 Assuming that txtDummyBox will sort it, save all those changes - see txtDummyBox_GotFocus
            Call txtText.Focus()
        End If
        'get timing information for development
        'timingDisplayFinished = GetTickCount
        'Debug.Print "Time for IE to load = " & timingmWebBrowserFinished - timingStart & " WebbIE to process = " & timingDisplayFinished - timingWebBrowserFinished & " for " & mWebBrowser.LocationName
        'IE appears to play this anyway - not any more! Oct 2009
        tmrBusyAnimation.Enabled = False
        Call PlayDoneSound()
        Exit Sub
        'AccessDenied:
        'There appears no way (for obvious security reasons) to get anything out of o, so we would have to flag
        'this as a problem then use MSAA to navigate to the offending frame in the browser object. Ugh. Let's leave
        'that for the moment as unsupported.
        'Debug.Print Err.Number & " Error in ParseDocument()" ' if 70 then Access Denied.
        'Resume ResumeAccessDenied
    End Sub

    Private Function ParseNode(ByRef node As mshtml.IHTMLDOMNode, Optional ByRef orderedListPrefix As String = "") As String
        'processes a document html node and all of its children and siblings (by calling itself.
        'Outputs results to output, which it returns
        ' mstrNewLine is either Empty or vbNewline, and should be set accordingly


        Dim tagname As String ' the HTML node name
        Dim label As String
        Dim output As String = "" ' the result of the parsing
        'Dim htmlE As IHTMLElement ' the node as an IHTMLElement object, lets us get more stuff
        Dim linkContent As String = "" ' the content of an a node to display
        Dim nodeIterator As mshtml.IHTMLDOMNode ' used to iterate through any further node collections
        Dim nodeIterator2 As mshtml.IHTMLDOMNode ' used to iterate again
        Dim elementIterator As mshtml.IHTMLElement
        Dim i As Integer ' counter
        Dim trimmedText As String ' used to strip spare spaces out of text
        Dim labelText As String = ""
        Dim notLabelText As String = ""
        Dim controlToBeLabelled As mshtml.IHTMLElement
        Dim href As String = ""
        Dim element As mshtml.IHTMLElement
        Dim element2 As mshtml.IHTMLElement2
        Dim element3 As mshtml.IHTMLElement3
        Dim ni As mshtml.IHTMLDOMChildrenCollection

        Dim labelToUse As String
        Dim objectContent As String
        Dim src As String
        Dim ob As mshtml.IHTMLObjectElement
        Dim validityCount As Integer

        Dim hasDisplayNone As Boolean
        Dim hasOnClick As Boolean
        Dim hasId As Boolean
        Dim hasName As Boolean
        Dim hasAccessKey As Boolean
        Dim isElement As Boolean
        Dim hasAlt As Boolean

        If mTerminateParsing Then
            'Stop parsing immediately. This is usually because we have some kind of error condition.
            Return ""
        Else
            tagname = node.nodeName
            If node.nodeType = ELEMENT_NODE Then
                isElement = True
                element = CType(node, mshtml.IHTMLElement)
                If element.getAttribute("onclick") Is Nothing Then
                    hasOnClick = False
                Else
                    hasOnClick = (element.getAttribute("onclick").ToString <> "")
                End If
                If element.getAttribute("id") Is Nothing Then
                    hasId = False
                Else
                    hasId = (element.id <> "")
                End If
                If element.getAttribute("name") Is Nothing Then
                    hasName = False
                Else
                    hasName = (element.getAttribute("name").ToString <> "")
                End If
                If element.getAttribute("accesskey") Is Nothing Then
                    hasAccessKey = False
                Else
                    hasAccessKey = (element.getAttribute("accesskey").ToString <> "")
                End If
                If element.getAttribute("alt") Is Nothing Then
                    hasAlt = False
                Else
                    hasAlt = (element.getAttribute("alt").ToString <> "")
                End If
                element2 = CType(element, mshtml.IHTMLElement2)
                element3 = CType(element, mshtml.IHTMLElement3)
                If element2.currentStyle.display Is Nothing Then
                    hasDisplayNone = False
                Else
                    hasDisplayNone = (element2.currentStyle.display = "none")
                End If
            Else
                isElement = False
                element = Nothing
                element2 = Nothing
                element3 = Nothing
                hasOnClick = False ' can only apply to an Element node.
                hasDisplayNone = False ' can only apply to an Element node.
                hasId = False
                hasName = False
                hasAccessKey = False
                hasAlt = False
            End If
            'Check for onclick
            If hasOnClick Then
                If tagname = "A" Or tagname = "INPUT" Or tagname = "APPLET" Or tagname = "BUTTON" Or tagname = "LABEL" Or tagname = "MAP" Or tagname = "OPTION" Or tagname = "OPTGROUP" Or tagname = "SELECT" Then
                    'already handled by normal node processing
                    'Debug.Print "A with onclick: " & node.getAttribute("onclick")
                Else
                    'Need to add link: hey, let's do this by faking an A node!
                    'But NOT for body nodes, because that would be bad!
                    If tagname <> "BODY" Then
                        tagname = "A"
                    End If
                End If
            End If
            'attempt to speed things up
            'Debug.Print "Nodetype:" & node.nodeType
            If mSeekingInternalTarget And isElement Then
                If hasId Then
                    If element.id = mInternalTarget Then
                        output = output & TARGET_MARKER
                        mSeekingInternalTarget = False
                    End If
                End If
                If hasName Then
                    'If we don't have a matching id check for a matching name.
                    If element.getAttribute("name").ToString = mInternalTarget Then
                        output = output & TARGET_MARKER
                        mSeekingInternalTarget = False
                    End If
                End If
            End If
            If mSeekingFocusElement And isElement Then
                If node Is mElementWithFocus Then
                    output = output & AJAX_TARGET_MARKER
                    mSeekingFocusElement = False
                End If
            End If
            If tagname = "H1" Or tagname = "H2" Or tagname = "H3" Or tagname = "H4" Or tagname = "H5" Or tagname = "H6" Then
                output = output & vbNewLine & "hytghytg" & vbNewLine
                mstrnewline = ""
            End If
            If tagname = "FORM" And mShowFormsOnly Then
                    mInForm = True
                numForms = numForms + 1
                output = output & mstrnewline & "hytghytg" & vbNewLine & GetText("Form") & ": " & numForms & " " & GetText("of") & " " & "LKJLKJLKJLKJLKJLKJLKJ" & vbNewLine
                mstrnewline = ""
                If node.hasChildNodes Then
                    nodeIterator = node.firstChild
                    While Not nodeIterator Is Nothing And Not mTerminateParsing
                        output = output & ParseNode(nodeIterator)
                        nodeIterator = nodeIterator.nextSibling
                    End While
                End If
                output = output & mstrnewline & "hytghytg" & vbNewLine & vbNewLine
                mstrnewline = ""
                mInForm = False
            ElseIf mShowFormsOnly And Not mInForm Then
                'Do no output, but process children
                If node.hasChildNodes Then
                    nodeIterator = node.firstChild
                    While Not nodeIterator Is Nothing And Not mTerminateParsing
                        output = output & ParseNode(nodeIterator)
                        nodeIterator = nodeIterator.nextSibling
                    End While
                End If
            ElseIf node.nodeType = TEXT_NODE Then
                'get rid of whitespace at end/start of line, INCLUDING non-breaking whitespace (Unicode
                '   value 160, NBSP)
                '3.10.5 Try RTrim instead of Trim.
                trimmedText = RTrim(Replace(node.nodeValue.ToString, NBSP, " "))
                trimmedText = Replace(trimmedText, vbCr, vbNewLine)
                If trimmedText <> "" Then
                    If Len(trimmedText) > NUMBER_CHARS_AFTER_LINK_PERMITTED And mblnJustDidLink Then
                        output = output & vbNewLine & orderedListPrefix & trimmedText & " "
                    Else
                        output = output & orderedListPrefix & trimmedText & " "
                    End If
                    mJustDidHeading = False ' did the heading text fine.
                    mblnJustDidLink = False
                    mstrnewline = vbNewLine
                End If
            ElseIf hasDisplayNone Then  'check displayed
                '3.7.4.
                'No longer hide Display:None sections, because that's not compliant with the W3C standards.
                'don't display this node at all! And don't do kids!
                '3.8.0
                'No, still hide Display:None sections, because people - like the BBC and Facebook - use it to hide error messages,
                'and I don't want to show these to users. Damn the W3C.
                'No, also, .display="none" does not mean "don't appear in the output" - it means "don't render" - I think.
                'UPGRADE_WARNING: Couldn't resolve default property of object element.outerhtml. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                Debug.Print("Not displaying: " & element.outerHTML)

                'Aaargh, this stop the Google search box from displaying! June 2011.

            ElseIf tagname = "TEXTAREA" Or element3.contentEditable = "true" Then
                'a multi-space text area, TEXTAREA
                '            OR
                'The "contentEditable" attribute is set, so this is a rich text edit area (from
                'IE 5.5 onwards, and in HTML5) -> Treat as a TEXTAREA
                Debug.Print("TEXTAREA or equivalent")
                numTextAreaInputs = numTextAreaInputs + 1
                If numTextAreaInputs > MAX_NUMBER_TEXT_AREA_INPUTS_SUPPORTED Then
                    mTerminateParsing = True
                Else
                    textAreaInput(numTextAreaInputs) = element
                    output = output & mstrnewline
                    'check for a label
                    'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    label = Trim(modFormLabelHandler.GetDescriptiveText(element.id))
                    If label <> "" Then
                        If VB.Right(label, 1) <> ":" Then label = label & ":"
                        label = label & " "
                        'output = output & label & vbNewLine
                    Else
                        If hasName Then
                            label = Trim(modFormLabelHandler.GetDescriptiveText(element.getAttribute("name").ToString))
                        End If
                        If label <> "" Then
                            If VB.Right(label, 1) <> ":" Then label = label & ":"
                            'output = output & label & vbNewLine
                            label = label & " "
                        End If
                    End If
                    output = output & ID_TEXTAREA & IIf(mNumberLinks, " " & numTextAreaInputs, "").ToString & ": "
                    If Len(label) > 0 Then output = output & label
                    If node.hasChildNodes Then
                        'some content already provided for textarea, add it. Now, this might be a rich
                        'text area, meaning that it has HTML content - links, etc. So need to parse contents.
                        nodeIterator = node.firstChild
                        While Not nodeIterator Is Nothing And Not mTerminateParsing
                            output = output & ParseNode(nodeIterator)
                            output = output & vbNewLine
                            mstrnewline = ""
                            nodeIterator = nodeIterator.nextSibling
                        End While
                    Else
                        'nothing there
                        output = output & modI18N.GetText("("")")
                    End If
                    output = output & vbNewLine
                    mstrnewline = ""
                End If
            ElseIf tagname = "A" Then

                'Debug.Print "Got A: " & node.tagname & vbTab & left(element.innertext, 100)
                'If mblnShowLinks Then 'check we're showing links normally, not non-processing them
                'Dev: element.getattribute("href").tostring == node.href for As
                'Also, we always get the complete canonical url UNLESS there is no href attribute at all.
                If element.getAttribute("href") Is Nothing Then
                    If tagname <> "A" Then
                        href = "FAKEA!"
                    End If
                Else
                    href = element.getAttribute("href").ToString
                End If
                If href <> "" Or hasOnClick Then
                    'okay, this is a standard href link node - that is, it is an anchor to another
                    'location, not a target for another link like <a name="scroll_here">
                    'OR it's a link that is powered by Javascript (3.8.0) such as the Search button on Facebook.
                    'conversely, if it _is_ just a target, the generic picking up of id and name will
                    'catch it
                    If numLinks > MAX_NUMBER_LINKS_SUPPORTED - 1 Then
                        'danger will robinson! Hangs WebbIE (3.2.3). Ameliorate,
                        'but don't fix, by exiting
                        'UPGRADE_WARNING: Couldn't resolve default property of object element.innertext. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If Len(Trim(element.innerText)) > 0 Then
                            'got some text, though, so return that.
                            ParseNode = orderedListPrefix & element.innerText & " "
                            mstrnewline = vbNewLine
                        End If
                        mTerminateParsing = True
                    Else
                        '3.7.4
                        'okay, now parse the link content to get its text content.
                        linkContent = modParseA.ParseAnchor(node)
                        If linkContent = "" Then
                            'we've failed to find anything to put in the link - use the url
                            If href = "FAKEA!" Then
                                linkContent = modI18N.GetText("Javascript")
                                'This really sucks on pages like YouTube that have loads of these. Maybe I should
                                'skip them?
                                'Debug.Print "OH:" & element.outerhtml
                            Else
                                'Try to get title of page from database of visited links, if we have it.
                                linkContent = GetLocationTitle(href)
                                'If failed, use filename.
                                If linkContent = "" Then linkContent = ExtractHREFLink(href)
                            End If
                        End If
                        If linkContent = modI18N.GetText("Javascript") And Not mnuOptionsJavascriptonlyitems.Checked Then
                            'Bleh, only Javascript. Dump it.
                        Else
                            numLinks = numLinks + 1
                            links(numLinks).element = element 
                            links(numLinks).description = linkContent
                            links(numLinks).address = href
                            'Debug.Print "Link :" & links(numLinks).address
                            If mJustDidHeading Then
                                'we've put "PAGE HEADING: " on the previous line all ready for the page headline,
                                'it's turned out to be a link. Put the link text in so there is some text.
                                output = output & Trim(linkContent)
                                mJustDidHeading = False
                            End If
                            output = output & mstrnewline & ID_LINK & IIf(mNumberLinks, " " & numLinks, "").ToString & ": " & orderedListPrefix
                            output = output & Trim(linkContent) '& " " I'm not sticking a " " at the end of the output because of the prevalence
                            '   of links like this: <a>London</a>, <a>New York</a>, <a>Manchester</a>. Don't want that to be London , New York , etc.
                            mstrnewline = vbNewLine
                            mblnJustDidLink = True
                        End If
                    End If
                Else
                    'okay, this is an a node with no href AND no onclick, so it's simply acting as a target for
                    'another link
                    'This means we have to display the contents, if there are any,
                    'which means going through the child nodes.
                    If node.hasChildNodes Then
                        nodeIterator = node.firstChild
                        While Not nodeIterator Is Nothing And Not mTerminateParsing
                            output = output & ParseNode(nodeIterator)
                            nodeIterator = nodeIterator.nextSibling
                        End While
                    End If
                End If
                'check for an accesskey on this link
                If hasAccessKey Then
                    Call modAccesskeys.AddAccessKey(CType(node, mshtml.IHTMLAnchorElement))
                End If
            ElseIf tagname = "IMG" Then
                Dim imgElement As mshtml.IHTMLImgElement
                Dim imgElement2 As mshtml.IHTMLImgElement2
                imgElement = CType(element, mshtml.IHTMLImgElement)
                imgElement2 = CType(element, mshtml.IHTMLImgElement2)
                If hasOnClick Then
                    'Treat it like an A element.
                    numLinks = numLinks + 1
                    If numLinks > MAX_NUMBER_LINKS_SUPPORTED Then
                        'danger will robinson! Hangs WebbIE (3.2.3). Ameliorate,
                        'but don't fix, by exiting
                        If imgElement.alt <> "" Then
                            ParseNode = imgElement.alt & " "
                            mstrnewline = vbNewLine
                        End If
                        mTerminateParsing = True
                    Else
                        'Create new link.
                        links(numLinks).element = element
                        Dim doc As Windows.Forms.HtmlDocument
                        doc = CType(element.document, Windows.Forms.HtmlDocument)
                        If imgElement2.longDesc <> "" Then
                            'TODO What? This doesn't seem to make sense.
                            links(numLinks).address = ConstructHREF(imgElement2.longDesc, doc.Url.ToString)
                        End If
                        output = output & mstrnewline & ID_LINK & IIf(mNumberLinks, " " & numLinks, "").ToString & ": "
                        If imgElement.alt = "" Then
                            output = output & modI18N.GetText("Unnamed link or button.")
                        Else
                            output = output & imgElement.alt
                        End If
                        output = output & vbNewLine
                        mstrnewline = ""
                        End If
                ElseIf imgElement2.longDesc <> "" Then
                    'okay, we have a longdesc set: since this is an accessibility feature, better support it
                    'we'll add a link to the URI, labelling it "IMAGE DESCRIPTION" and add the alt tag
                    numLinks = numLinks + 1
                    If numLinks > MAX_NUMBER_LINKS_SUPPORTED Then
                        'danger will robinson! Hangs WebbIE (3.2.3). Ameliorate,
                        'but don't fix, by exiting
                        If imgElement.alt <> "" Then
                            'got some text, though, so return that.
                            ParseNode = imgElement.alt & " "
                            mstrnewline = vbNewLine
                        End If
                        mTerminateParsing = True
                    Else
                        links(numLinks).element = element
                        links(numLinks).address = imgElement2.longDesc
                        output = output & mstrnewline & ID_LINK & IIf(mNumberLinks, " " & numLinks, "").ToString & modI18N.GetText(": IMAGE DESCRIPTION")
                        links(numLinks).description = modI18N.GetText("IMAGE DESCRIPTION")
                        If imgElement.alt <> "" Then
                            output = output & " " & modI18N.GetText("FOR") & " " & imgElement.alt
                            links(numLinks).description = modI18N.GetText("IMAGE DESCRIPTION FOR") & " " & imgElement.alt
                        End If
                        output = output & vbNewLine
                        mstrnewline = ""
                    End If
                Else
                    If mnuOptionsImages.Checked Then
                        'okay, we're displaying images and we've found one: present the alt info UNLESS
                        'the alt tag is "*", " " or ""
                        If imgElement.alt <> "" And imgElement.alt <> "*" Then
                            output = output & mstrnewline & modI18N.GetText("IMAGE:") & " " & imgElement.alt & vbNewLine
                            If imgElement.src <> "" Then
                                Call imageHrefs.Add(element.getAttribute("src").ToString)
                            End If
                            mstrnewline = ""
                        End If
                    End If
                End If
            ElseIf tagname = "SELECT" Then
                'A select node - has option and optgroup child nodes
                numSelects = numSelects + 1
                If numSelects > MAX_NUMBER_SELECTS_SUPPORTED Then
                    'Whoops! Too many selects for WebbIE. 3.8.0
                    mTerminateParsing = True
                Else
                    If hasName Then
                        selects(numSelects).name = element.getAttribute("name").ToString 'store name of menu
                    End If
                    'now go through the options in the select node
                    nodeIterator = node.firstChild
                    selects(numSelects).node = CType(element, mshtml.IHTMLSelectElement)
                    i = 0
                    While Not (nodeIterator Is Nothing)
                        'got a node - check it's an option
                        If nodeIterator.nodeName = "OPTION" Then
                            'got an option node
                            i = i + 1
                            'Debug.Print "option id=" & nodeIterator.attributes.getNamedItem("id").nodeValue
                            'Debug.Print "option value=" & nodeIterator.attributes.getNamedItem("selected").nodeValue
                            If nodeIterator.hasChildNodes Then
                                selects(numSelects).options(i) = nodeIterator.firstChild.nodeValue.ToString 'save menu items
                            Else
                                selects(numSelects).options(i) = ""
                            End If
                            elementIterator = CType(nodeIterator, mshtml.IHTMLElement)
                            If element.getAttribute("selected") Is Nothing Then
                            Else
                                If CBool(elementIterator.getAttribute("selected").ToString) Then selects(numSelects).selected = CShort(i)
                            End If
                        ElseIf nodeIterator.nodeName = "OPTGROUP" Then  ' check for option groups
                            'we have an option group - have to find the children of this one
                            nodeIterator2 = nodeIterator.firstChild
                            While Not (nodeIterator2 Is Nothing)
                                'got a node or option group
                                If nodeIterator2.nodeName = "OPTION" Then
                                    'got an option node
                                    i = i + 1
                                    'Debug.Print "option id=" & nodeIterator2.attributes.getNamedItem("id").nodeValue
                                    'Debug.Print "option value=" & nodeIterator2.attributes.getNamedItem("selected").nodeValue
                                    elementIterator = CType(nodeIterator2, mshtml.IHTMLElement)
                                    selects(numSelects).options(i) = elementIterator.innerText
                                    If elementIterator.getAttribute("selected") Is Nothing Then
                                    Else
                                        If CBool(elementIterator.getAttribute("selected").ToString) Then selects(numSelects).selected = i
                                    End If
                                End If
                                nodeIterator2 = nodeIterator2.nextSibling
                            End While
                            'go back to the parent option groups
                        End If
                        nodeIterator = nodeIterator.nextSibling
                    End While
                    selects(numSelects).size = i ' size of the menu
                    'now do the display
                    output = output & mstrnewline
                    'check for a label
                    If hasId Then
                        label = modFormLabelHandler.GetDescriptiveText(element.id)
                    Else
                        label = ""
                    End If
                    If label <> "" Then
                        output = output & label & vbNewLine
                    Else
                        'Check for a title attribute.
                        If element.title <> "" Then
                            label = element.title
                        End If
                        If label = "" Then
                            If hasName Then
                                label = modFormLabelHandler.GetDescriptiveText(element.getAttribute("name").ToString)
                            End If
                        End If
                        If label <> "" Then
                            output = output & label & vbNewLine
                        End If
                    End If
                    If element.getAttribute("disabled") Is Nothing Then
                    Else
                        If CBool(element.getAttribute("disabled").ToString) Then output = output & ID_DISABLED
                        output = output & ID_SELECT & IIf(mNumberLinks, " " & numSelects, "").ToString & ": ("
                        'display the currently-selected item
                        If selects(numSelects).selected > 0 Then
                            output = output & selects(numSelects).options(selects(numSelects).selected)
                        End If
                        output = output & ")" & vbNewLine
                        mstrnewline = ""
                    End If
                End If
            ElseIf tagname = "INPUT" Then
                'an input feature, the type of which is to be determined
                Dim inputElement As mshtml.IHTMLInputElement
                inputElement = CType(element, mshtml.IHTMLInputElement)
                Select Case inputElement.type
                    Case "button" 'an input button
                        numButtonInputs = numButtonInputs + 1
                        output = output & mstrnewline
                        'check for a label
                        If element.id <> "" Then
                            label = modFormLabelHandler.GetDescriptiveText(element.id)
                        Else
                            label = ""
                        End If
                        If label <> "" Then
                            output = output & label & vbNewLine
                        Else
                            If element.title <> "" Then
                                'UPGRADE_WARNING: Couldn't resolve default property of object node.getAttribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                label = element.title
                            ElseIf hasName Then
                                label = modFormLabelHandler.GetDescriptiveText(element.getAttribute("name").ToString)
                            End If
                            If label <> "" Then
                                output = output & label & vbNewLine
                            End If
                        End If
                        'If element.getattribute("disabled").nodeValue Then output = output & ID_DISABLED
                        'If element.getattribute("readonly").nodeValue Then output = output & ID_READONLY
                        output = output & ID_BUTTON & IIf(mNumberLinks, " " & numButtonInputs, "").ToString & ": ("
                        If inputElement.value = "" Then
                            If Len(Trim(Replace(element.innerText, vbNewLine, ""))) = 0 Then
                                output = output & GetText("Button")
                            Else
                                output = output & Trim(Replace(element.innerText, vbNewLine, ""))
                            End If
                        Else
                            output = output & inputElement.value
                        End If
                        output = output & ")" & vbNewLine
                        mstrnewline = ""
                        buttonInput(numButtonInputs) = element
                    Case "checkbox" ' a checkbox
                        numCheckboxInputs = numCheckboxInputs + 1
                        checkboxInput(numCheckboxInputs) = inputElement
                        'display the checkbox
                        output = output & mstrnewline
                        'check for a label
                        label = modFormLabelHandler.GetDescriptiveText(element.id)
                        label = Trim(label)
                        If label <> "" Then
                            If VB.Right(label, 1) <> ":" Then label = label & ":"
                        Else
                            label = modFormLabelHandler.GetDescriptiveText(inputElement.name)
                            label = Trim(label)
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                            End If
                        End If
                        'If element.getattribute("disabled").nodeValue Then output = output & ID_DISABLED
                        'If element.getattribute("readonly").nodeValue Then output = output & ID_READONLY
                        output = output & ID_CHECKBOX & IIf(mNumberLinks, " " & numCheckboxInputs, "").ToString & ": "
                        If Len(label) > 0 Then output = output & label
                        'display whether it's checked
                        If inputElement.checked Then
                            output = output & " " & ID_CHECKED
                        Else
                            output = output & " " & ID_NOTCHECKED
                        End If
                        mstrnewline = vbNewLine
                    Case "radio" ' a radio button
                        numRadioInputs = numRadioInputs + 1
                        radioInput(numRadioInputs) = element
                        output = output & mstrnewline
                        'check for a label
                        label = modFormLabelHandler.GetDescriptiveText(element.id)
                        label = Trim(label)
                        If label <> "" Then
                            If VB.Right(label, 1) <> ":" Then label = label & ":"
                        Else
                            'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            label = modFormLabelHandler.GetDescriptiveText(inputElement.name)
                            label = Trim(label)
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                            End If
                        End If
                        'If element.getattribute("disabled").nodeValue Then output = output & ID_DISABLED
                        'If element.getattribute("readonly").nodeValue Then output = output & ID_READONLY
                        output = output & ID_RADIO & IIf(mNumberLinks, " " & numRadioInputs, "").ToString & ": "
                        If Len(label) > 0 Then output = output & label & " "
                        'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If inputElement.checked Then
                            output = output & ID_SELECTED
                        Else
                            output = output & ID_NOTSELECTED
                        End If
                        mstrnewline = vbNewLine
                    Case "text" ' a text input box
                        'normal text input
                        numTextInputs = numTextInputs + 1
                        If numButtonInputs > MAX_NUMBER_TEXT_INPUTS_SUPPORTED Then
                            mTerminateParsing = True
                        Else
                            textInput(numTextInputs) = element
                            output = output & mstrnewline
                            'check for a label
                            If element.id = "" Then
                                label = ""
                            Else
                                label = modFormLabelHandler.GetDescriptiveText(element.id)
                            End If
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                            Else
                                label = modFormLabelHandler.GetDescriptiveText(inputElement.name)
                                If label <> "" Then
                                    If VB.Right(label, 1) <> ":" Then label = label & ":"
                                End If
                            End If
                            'If element.getattribute("disabled").tostring Then output = output & ID_DISABLED
                            'If element.getattribute("readonly").tostring Then output = output & ID_READONLY
                            output = output & ID_TEXTBOX & IIf(mNumberLinks, " " & numTextInputs, "").ToString & ": "
                            If Len(label) > 0 Then output = output & label & " "
                            'display contents if any
                            output = output & inputElement.value
                            output = output & vbNewLine
                            mstrnewline = ""
                        End If
                    Case "password" ' password input box
                        numPassInputs = numPassInputs + 1 'number of password inputs on page
                        If numPassInputs > MAX_NUMBER_PASSWORD_INPUTS_SUPPORTED Then
                            mTerminateParsing = True
                        Else
                            'store the password entry box
                            passwordInput(numPassInputs) = element
                            output = output & mstrnewline
                            'check for a label
                            label = modFormLabelHandler.GetDescriptiveText(element.id)
                            label = Trim(label)
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                                output = output & label & vbNewLine
                            Else
                                label = modFormLabelHandler.GetDescriptiveText(inputElement.name)
                                label = Trim(label)
                                If label <> "" Then
                                    If VB.Right(label, 1) <> ":" Then label = label & ":"
                                    output = output & label & vbNewLine
                                End If
                            End If
                            'If element.getattribute("disabled").tostring Then output = output & ID_DISABLED
                            'If element.getattribute("readonly").tostring Then output = output & ID_READONLY
                            output = output & ID_PASSWORD & IIf(mNumberLinks, " " & numPassInputs, "").ToString & ": "
                            output = output & New String(CChar("*"), Len(inputElement.value)) & vbNewLine
                            mstrnewline = ""
                        End If
                    Case "submit" ' a submit button
                        numSubmitInputs = numSubmitInputs + 1 'increase submit box counter
                        If numSubmitInputs > MAX_NUMBER_SUBMITS_SUPPORTED Then
                            mTerminateParsing = True
                        Else
                            output = output & mstrnewline
                            'check for a label
                            label = modFormLabelHandler.GetDescriptiveText(element.id)
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                                output = output & label & vbNewLine
                            Else
                                label = Trim(modFormLabelHandler.GetDescriptiveText(inputElement.name))
                                If label <> "" Then
                                    If VB.Right(label, 1) <> ":" Then label = label & ":"
                                    output = output & label & vbNewLine
                                End If
                            End If
                            'TODO If element.getattribute("disabled").tostring Then output = output & ID_DISABLED
                            'TODO if element.getattribute("readonly").tostring Then output = output & ID_READONLY
                            output = output & ID_SUBMIT & IIf(mNumberLinks, " " & numSubmitInputs, "").ToString & ": (" & inputElement.value
                            output = output & ")" & vbNewLine
                            submitInput(numSubmitInputs) = element
                            mstrnewline = ""
                        End If
                    Case "hidden" ' hidden input information
                        'don't display anything!
                    Case "image" ' an image
                        numSubmitInputs = numSubmitInputs + 1 'increase submit box counter
                        If numSubmitInputs > MAX_NUMBER_SUBMITS_SUPPORTED Then
                            mTerminateParsing = True
                        Else
                            submitInput(numSubmitInputs) = element
                            output = output & mstrnewline
                            'check for a label
                            label = Trim(modFormLabelHandler.GetDescriptiveText(element.id))
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                                output = output & label & vbNewLine
                            Else
                                label = Trim(modFormLabelHandler.GetDescriptiveText(inputElement.name))
                                If label <> "" Then
                                    If VB.Right(label, 1) <> ":" Then label = label & ":"
                                    output = output & label & vbNewLine
                                End If
                            End If
                            'TODO If element.getattribute("disabled").tostring Then output = output & ID_DISABLED
                            'TODO If element.getattribute("readonly").tostring Then output = output & ID_READONLY
                            output = output & ID_SUBMIT & IIf(mNumberLinks, " " & numSubmitInputs, "").ToString & ": ("
                            'we _could_ check the alt tag to see if were blank, but if it were we wouldn't
                            'be able to put any more useful information in anyway (except possibly the file
                            'name of the image, which might be a forty-character absolute URL...)
                            output = output & inputElement.alt & ")" & vbNewLine
                            submitInput(numSubmitInputs) = element
                            mstrnewline = ""
                        End If
                    Case "file" ' browse-to and select file option
                        numFileInputs = numFileInputs + 1
                        If numFileInputs > MAX_NUMBER_FILE_INPUTS_SUPPORTED Then
                            mTerminateParsing = True
                        Else
                            fileInput(numFileInputs) = element
                            output = output & mstrnewline
                            'check for a label
                            label = Trim(modFormLabelHandler.GetDescriptiveText(element.id))
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                                output = output & label & vbNewLine
                            Else
                                'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                label = Trim(modFormLabelHandler.GetDescriptiveText(inputElement.name))
                                If label <> "" Then
                                    If VB.Right(label, 1) <> ":" Then label = label & ":"
                                    output = output & label & vbNewLine
                                End If
                            End If
                            'If element.getattribute("disabled").tostring Then output = output & ID_DISABLED
                            'If element.getattribute("readonly").tostring Then output = output & ID_READONLY
                            output = output & ID_FILE & IIf(mNumberLinks, " " & numFileInputs, "").ToString & ": ("
                            If inputElement.value = "" Then
                                output = output & modI18N.GetText("No file selected)") & vbNewLine
                            Else
                                output = output & inputElement.value
                                output = output & ")" & vbNewLine
                            End If
                            mstrnewline = ""
                        End If
                End Select
            ElseIf tagname = "BUTTON" Then
                'an input button
                Select Case element.getAttribute("type").ToString
                    Case "button"
                        numButtonInputs = numButtonInputs + 1
                        If numButtonInputs > MAX_NUMBER_BUTTON_INPUTS_SUPPORTED Then
                            mTerminateParsing = True
                        Else
                            buttonInput(numButtonInputs) = element
                            output = output & mstrnewline
                            'check for a label
                            label = Trim(modFormLabelHandler.GetDescriptiveText(element.id))
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                                output = output & label & vbNewLine
                            Else
                                'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                label = Trim(modFormLabelHandler.GetDescriptiveText(element.getAttribute("name").ToString))
                                If label <> "" Then
                                    If VB.Right(label, 1) <> ":" Then label = label & ":"
                                    output = output & label & vbNewLine
                                End If
                            End If
                            If CBool(element.getAttribute("disabled").ToString) Then output = output & ID_DISABLED
                            output = output & ID_BUTTON & IIf(mNumberLinks, " " & numButtonInputs, "").ToString & ": ("
                            labelText = Parse(node)
                            If Len(labelText) = 0 Then
                                'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                output = output & element.getAttribute("value").ToString
                            Else
                                output = output & labelText
                            End If
                            output = output & ")" & vbNewLine
                            mstrnewline = ""
                        End If
                    Case "reset"
                        numResetInputs = numResetInputs + 1
                        If numResetInputs > MAX_NUMBER_RESET_INPUTS_SUPPORTED Then
                            mTerminateParsing = True
                        Else
                            resetInput(numResetInputs) = element
                            output = output & mstrnewline
                            'check for a label
                            label = Trim(modFormLabelHandler.GetDescriptiveText(element.id))
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                                output = output & label & vbNewLine
                            Else
                                'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                label = Trim(modFormLabelHandler.GetDescriptiveText(element.getAttribute("name").ToString))
                                If label <> "" Then
                                    If VB.Right(label, 1) <> ":" Then label = label & ":"
                                    output = output & label & vbNewLine
                                End If
                            End If
                            'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            If CBool(element.getAttribute("disabled").ToString) Then output = output & ID_DISABLED
                            '3.8.0 - some buttons don't have value attributes, they just have content to use.
                            output = output & ID_RESET & IIf(mNumberLinks, " " & numResetInputs, "").ToString & ": ("
                            labelText = Parse(node)
                            If Len(labelText) = 0 Then
                                'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                output = output & element.getAttribute("value").ToString
                            Else
                                output = output & labelText
                            End If
                            output = output & ")" & vbNewLine
                            mstrnewline = ""
                        End If
                    Case "submit"
                        numSubmitInputs = numSubmitInputs + 1 'increase submit box counter
                        If numSubmitInputs > MAX_NUMBER_SUBMITS_SUPPORTED Then
                            mTerminateParsing = True
                        Else
                            output = output & mstrnewline
                            'check for a label
                            'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            label = Trim(modFormLabelHandler.GetDescriptiveText(element.id))
                            If label <> "" Then
                                If VB.Right(label, 1) <> ":" Then label = label & ":"
                                output = output & label & vbNewLine
                            Else
                                'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                label = Trim(modFormLabelHandler.GetDescriptiveText(element.getAttribute("name").ToString))
                                If label <> "" Then
                                    If VB.Right(label, 1) <> ":" Then label = label & ":"
                                    output = output & label & vbNewLine
                                End If
                            End If
                            'TODO If element.getattribute("disabled").tostring Then output = output & ID_DISABLED
                            '3.8.0 Buttons may not have a .value attribute, they may have innerText instead.
                            output = output & ID_SUBMIT & IIf(mNumberLinks, " " & numSubmitInputs, "").ToString & ": ("
                            labelText = Parse(node)
                            If Len(labelText) = 0 Then
                                'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                output = output & element.getAttribute("value").ToString
                            Else
                                output = output & labelText
                            End If
                            output = output & ")" & vbNewLine
                            submitInput(numSubmitInputs) = element
                            mstrnewline = ""
                        End If
                End Select
                    '    ElseIf Len(element.getattribute("onclick").tostring) > 0 Then
                    'For Ajax support I should add onclick handling to the parsing tree.
                    '        output = output & "ONCLICK" & vbNewLine
            ElseIf tagname = "OL" Then
                    'an ordered list
                    i = 1
                    If node.hasChildNodes Then
                        ni = CType(node.childNodes, mshtml.IHTMLDOMChildrenCollection)
                        For Each nodeIterator In ni
                            '      output = output & i & " "
                            '     mstrnewline = vbNewLine
                            output = output & mstrnewline
                            output = output & ParseNode(nodeIterator, Trim(orderedListPrefix) & i & ". ")
                            output = output & vbNewLine
                            mstrnewline = ""
                            i = i + 1
                            If mTerminateParsing Then Exit For
                        Next nodeIterator
                    End If
            ElseIf tagname = "HR" Then
                    'a horizontal rule
                    output = output & "___________________________________________________________________________________"
                    output = output & vbNewLine
                    mstrnewline = ""
            ElseIf tagname = "AREA" Then
                    ' client-side image map - treat like a collection of links
                    ' first check it has an href - if not, discard it
                    If (element.getAttribute("nohref").ToString <> "" Or element.getAttribute("href").ToString = "") Then
                        'TODO Check nohref attribute is supported
                        'no href - just an image - skip it
                    Else
                        'okay, we have an href
                        numLinks = numLinks + 1
                        'check for alt tag
                        'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If element.getAttribute("alt").ToString <> "" Then
                            'use the alt tag
                            'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            linkContent = Trim(element.getAttribute("alt").ToString)
                        Else
                            'no alt tag - use address
                            'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            linkContent = ExtractHREFLink(element.getAttribute("href").ToString)
                        End If
                        'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        links(numLinks).address = element.getAttribute("href").ToString
                        output = output & mstrnewline
                        output = output & ID_LINK & IIf(mNumberLinks, " " & numLinks, "").ToString & ":   " & Trim(linkContent) & " "
                        mstrnewline = vbNewLine
                    End If
            ElseIf tagname = "BLOCKQUOTE" Then
                    'a quotation
                    output = output & mstrnewline & modI18N.GetText("[quotation marks]")
                    mstrnewline = vbNewLine
                    If node.hasChildNodes Then
                        ni = CType(node.childNodes, mshtml.IHTMLDOMChildrenCollection)
                        For Each nodeIterator In ni
                            output = output & ParseNode(nodeIterator)
                            If mTerminateParsing Then Exit For
                        Next nodeIterator
                    End If
                    If VB.Right(output, 1) = " " Then output = VB.Left(output, Len(output) - 1)
                    output = output & modI18N.GetText("[quotation marks]") & vbNewLine
                    mstrnewline = ""
            ElseIf tagname = "OBJECT" Or tagname = "APPLET" Then
                    numObjects = numObjects + 1
                    If numObjects > MAX_NUMBER_OBJECTS_SUPPORTED Then
                        mTerminateParsing = True
                    Else
                        objects(numObjects) = element

                        'UPGRADE_WARNING: Couldn't resolve default property of object element.outerhtml. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If InStr(1, element.outerHTML, FLASH_INDICATOR) > 0 Then
                            'flash item
                            labelToUse = ID_FLASHOBJECT
                        Else
                            labelToUse = ID_OBJECT
                        End If
                        objectContent = modParseHTML.Render(element.innerHTML)
                        '        If InStr(1, mWebBrowser.Document.url, "iplayer", vbTextCompare) > 0 Then
                        ''            'We're on the BBC website. Let's put on a play button!
                        '            output = output & mstrnewline & modI18N.GetText("Play BBC Programme") & vbNewLine
                        '            mstrnewline = ""
                        '            Set mBBCIPlayer = node



                        'UPGRADE_WARNING: Couldn't resolve default property of object e.getAttribute(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If Len(Trim(element.getAttribute("title").ToString)) > 0 Then
                            'UPGRADE_WARNING: Couldn't resolve default property of object e.getAttribute(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            output = output & mstrnewline & labelToUse & IIf(mNumberLinks, " " & numObjects, "").ToString & ": " & element.getAttribute("title").ToString & vbNewLine
                            'UPGRADE_WARNING: Couldn't resolve default property of object e.getAttribute(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        ElseIf Len(Trim(element.getAttribute("alt").ToString)) > 0 Then
                            'UPGRADE_WARNING: Couldn't resolve default property of object e.getAttribute(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            output = output & mstrnewline & labelToUse & IIf(mNumberLinks, " " & numObjects, "").ToString & ": " & element.getAttribute("alt").ToString & vbNewLine
                        Else
                            '3.7 No HTML content of OBJECT, just put in the object content if we have any.
                            output = output & mstrnewline & labelToUse & IIf(mNumberLinks, " " & numObjects, "").ToString
                            If Len(objectContent) > 0 Then
                                'Got some text, use that.
                                output = output & ": " & objectContent & vbNewLine
                                objectContent = ""
                            Else
                                '3.11.0 Try to make more of an effort to rename objects.
                                'No object content, label as "unnammed"
                                src = element.innerHTML
                                If InStr(1, src, " src=", CompareMethod.Text) > 0 Then
                                    'Found a src node, use that
                                    src = VB.Right(src, Len(src) - InStr(1, src, " src=", CompareMethod.Text) - Len(" src="))
                                    If InStr(1, src, "/") > 0 Then
                                        src = VB.Right(src, Len(src) - InStrRev(src, "/", Len(src)))
                                    End If
                                    If InStr(1, src, " ") > 0 Then
                                        src = VB.Left(src, InStr(1, src, " ") - 1)
                                    End If
                                    If VB.Right(src, 1) = """" Then src = VB.Left(src, Len(src) - 1)
                                    If VB.Right(src, 1) = "'" Then src = VB.Left(src, Len(src) - 1)
                                    src = Replace(src, ".swf", "", , , CompareMethod.Text)
                                    If Len(src) > 20 Then src = VB.Left(src, 20)
                                Else
                                    src = ""
                                    ob = CType(element, mshtml.IHTMLObjectElement)
                                    If ob.data <> "" Then
                                        src = ob.data
                                        If InStr(1, src, "/", CompareMethod.Binary) > 0 Then
                                            src = VB.Right(src, Len(src) - InStrRev(src, "/"))
                                            src = Replace(src, ".swf", "", , , CompareMethod.Text)
                                            If Len(src) > 20 Then src = VB.Left(src, 20)
                                        Else
                                            src = ""
                                        End If
                                    End If

                                End If
                                If Len(src) > 0 Then
                                    output = output & ": " & src & vbNewLine
                                Else
                                    output = output & modI18N.GetText(": Unnamed object") & vbNewLine
                                End If
                            End If
                        End If
                        If Len(objectContent) > 0 Then
                            '3.7. The OBJECT node has some internal text. If this is present, render it (just use innerText)
                            'This is compliant with the HTML spec. Note, however, that WebBrowser doesn't seem to provide
                            'the internal contents through the DOM, so might never get here.
                            'output = output & mstrnewline & labelToUse & " " & numObjects & ": " & element.innertext & vbNewLine
                            '3.6.6 (!) OK, use my new text parsing routine.
                            'And we haven't used the objectContent yet.
                            output = output & objectContent & vbNewLine
                        End If

                        '            If element.getattribute("data").tostring <> "" Then
                        '                output = output & " (" & element.getattribute("data").tostring & ")" & vbNewLine
                        '            ElseIf element.getattribute("classid").tostring <> "" Then
                        '                output = output & " (" & element.getattribute("classid").tostring & ")" & vbNewLine
                        '            Else
                        '                output = output & vbNewLine
                        '            End If
                        mstrnewline = ""
                    End If
            ElseIf tagname = "STYLE" Then
                    'content for browser - not intended for user to see
            ElseIf tagname = "CAPTION" Then
                    'Table caption
                    'UPGRADE_WARNING: Couldn't resolve default property of object element.innertext. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    output = output & mstrnewline & modI18N.GetText("Table Caption") & ": " & element.innerText & vbNewLine
                    mstrnewline = ""
            ElseIf tagname = "DEL" Then
                    'deleted content - don't do any of it or it's child nodes!
            ElseIf tagname = "LABEL" Then
                    'okay, this is a label node, so either (1) it contains information
                    'relating to a control node or (2) it contains a control node.
                    'If (1) don't display it: it'll be displayed when we do the control
                    'node. If (2) process normally. However, 3.8.0, we must check that it
                    'does not itself contain a control node, or else it won't be rendered.
                    'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    'UPGRADE_WARNING: Couldn't resolve default property of object node. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    If ContainsInputElement(element) Or element.getAttribute("for").ToString = "" Then
                        'This contains content including the input control, so we have to parse it normally. OR
                        'This does not have a "for" attribute, so it must refer to the contents of the LABEL
                        'node, so we do kids.
                        'DEV: This might be messy, but otherwise lots of LABEL action
                        'doesn't work.
                        'record non-form text and use it
                        'as the label for any form nodes
                        If node.hasChildNodes Then
                            Dim foundControlToBeLabelled As Boolean
                            controlToBeLabelled = element ' To keep the compiler happy: don't use it unless
                            'the correct control has been found below and foundControlToBeLabelled has been set.
                            ni = CType(node.childNodes, mshtml.IHTMLDOMChildrenCollection)
                            For Each nodeIterator In ni
                                If nodeIterator.nodeName <> "INPUT" And nodeIterator.nodeName <> "SELECT" And nodeIterator.nodeName <> "BUTTON" And nodeIterator.nodeName <> "TEXTAREA" Then
                                    'not-an-input
                                    If nodeIterator.nodeName = "#text" Then
                                        labelText = labelText & Trim(nodeIterator.ToString) & " "
                                    End If
                                Else
                                    'is-an-input
                                    notLabelText = notLabelText & ParseNode(nodeIterator)
                                    controlToBeLabelled = CType(nodeIterator, mshtml.IHTMLElement)
                                    foundControlToBeLabelled = True
                                End If
                                If mTerminateParsing Then Exit For
                            Next nodeIterator
                            If foundControlToBeLabelled Then
                                'right, so hope that by this point labelText contains all the
                                'text of the label and notLabelText contains all the input item
                                'text and controlToBeLabelled is the control itself
                                labelText = Trim(labelText)
                                If Len(labelText) > 0 Then
                                    If VB.Right(labelText, 1) <> ":" Then labelText = labelText & ":"
                                    If VB.Right(notLabelText, Len(vbNewLine)) = vbNewLine Then notLabelText = VB.Left(notLabelText, Len(notLabelText) - Len(vbNewLine))
                                    notLabelText = Replace(notLabelText, ":", ": " & labelText, , 1) & vbNewLine
                                    output = output & notLabelText
                                Else
                                    output = output & notLabelText & vbNewLine
                                End If
                                'Apply label text to the control we should already have got:
                                Call modFormLabelHandler.AddLabel(labelText, controlToBeLabelled)
                            End If
                        End If
                    End If
            ElseIf tagname = "IFRAME" Then
                    'internal frame - used for non-frame-supporting browsers - WebbIE does support frames,
                    'so don't show any content (see HTML4.0 spec)
            ElseIf tagname = "BDO" Then
                    'set-direction text - right-to-left or left-to-right
                    'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    If element.getAttribute("dir").ToString = "ltr" Then
                        '"normal" left-to-right direction - process as "normal" text
                        If node.hasChildNodes Then
                            ni = CType(node.childNodes, mshtml.IHTMLDOMChildrenCollection)
                            For Each nodeIterator In ni
                                output = output & ParseNode(nodeIterator)
                                If mTerminateParsing Then Exit For
                            Next nodeIterator
                        End If
                    Else
                        'reversed right-to-left direction
                        linkContent = ""
                        If node.hasChildNodes Then
                            ni = CType(node.childNodes, mshtml.IHTMLDOMChildrenCollection)
                            For Each nodeIterator In ni
                                linkContent = linkContent & ParseNode(nodeIterator)
                                If mTerminateParsing Then Exit For
                            Next nodeIterator
                        End If
                        i = Len(linkContent)
                        While i > 0
                            If Mid(linkContent, i, 1) = vbLf Then
                                'we've found a newline (CR + LF)
                                output = output & vbNewLine
                                mstrnewline = ""
                                i = i - 2
                            Else
                                'normal character - add to output
                                output = output & Mid(linkContent, i, 1)
                                mstrnewline = vbNewLine
                                i = i - 1
                            End If
                        End While
                    End If
            ElseIf tagname = "LI" And node.parentNode.nodeName = "OL" Then
                    'ordered/numbered list: don't newline. Do iterate through kids.
                    ni = CType(node.childNodes, mshtml.IHTMLDOMChildrenCollection)
                    For Each nodeIterator In ni
                        output = output & ParseNode(nodeIterator, orderedListPrefix)
                        If mTerminateParsing Then Exit For
                    Next nodeIterator
                    'don't do the sub-kids of an A node, an INPUT node, a FRAME node, an IMG node...
            Else
                    If tagname = "LI" Or tagname = "DD" Then
                        'We're not in an ordered list, that's handled above. So just stick on a newline
                        output = output & mstrnewline '& "- " ' DEV: don't put the - in because it might be
                        'a list of links following, and this produces lots of erroneous lines with - on them
                        mstrnewline = ""
                    ElseIf tagname = "Q" Then
                        output = output & modI18N.GetText("[quotation marks]")
                        mstrnewline = vbNewLine
                    ElseIf tagname = "TABLE" Then
                        'OK, we've got a table node. Do we apply our exciting new table system? Most tables will simply be
                        'markup tables. So we don't want to confuse pages with all the crap.
                        'Let's assume, 3.8.0, Dec 2008, that having any two of caption, summary and TH nodes means it's
                        'a real table.
                        'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If element.getAttribute("summary").ToString <> "" Then validityCount = validityCount + 1
                        'UPGRADE_WARNING: Couldn't resolve default property of object element.innerhtml. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If InStr(1, element.innerHTML, "<caption", CompareMethod.Text) > 0 Then validityCount = validityCount + 1
                        'Some tables are just layout tables but use th:
                        'UPGRADE_WARNING: Couldn't resolve default property of object element.innerhtml. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If InStr(1, element.innerHTML, "<th", CompareMethod.Text) > 0 And InStr(1, element.innerHTML, "<td", CompareMethod.Text) > 0 Then validityCount = validityCount + 1
                        If validityCount > 1 Then
                            numTables = numTables + 1
                            'UPGRADE_WARNING: Couldn't resolve default property of object element.getattribute. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            output = output & mstrnewline & ID_TABLE & IIf(mNumberLinks, " " & numTables, "").ToString & ": " & element.getAttribute("summary").ToString & vbNewLine
                            tables(numTables) = element
                            mstrnewline = ""
                        End If
                        '            ElseIf tagname = mHeadingLevel Then
                        '                'Debug.Print "Matched tagname:" & tagname
                        '                output = output & mstrnewline & vbNewLine & SECTION_MARKER_H1 & ": "
                        '                mJustDidHeading = True
                        '                mstrnewline = vbNewLine
                        '            ElseIf tagname = "H1" Or tagname = "H2" Or tagname = "H3" Or tagname = "H4" Or tagname = "H5" Or tagname = "H6" Then
                        '                output = output & mstrnewline
                        '                mstrnewline = vbNewLine
                    ElseIf tagname = "H1" Then
                        output = output & mstrnewline & SECTION_MARKER_H1 & ": "
                        mstrnewline = vbNewLine
                    ElseIf tagname = "H2" Then
                        output = output & mstrnewline & SECTION_MARKER_H2 & ": "
                        mstrnewline = vbNewLine
                    ElseIf tagname = "H3" Then
                        output = output & mstrnewline & SECTION_MARKER_H3 & ": "
                        mstrnewline = vbNewLine
                    ElseIf tagname = "H4" Then
                        output = output & mstrnewline & SECTION_MARKER_H4 & ": "
                        mstrnewline = vbNewLine
                    ElseIf tagname = "H5" Then
                        output = output & mstrnewline & SECTION_MARKER_H5 & ": "
                        mstrnewline = vbNewLine
                    ElseIf tagname = "H6" Then
                        output = output & mstrnewline & SECTION_MARKER_H6 & ": "
                        mstrnewline = vbNewLine
                    End If
                    If node.hasChildNodes Then
                        ni = CType(node.childNodes, mshtml.IHTMLDOMChildrenCollection)
                        For Each nodeIterator In ni
                            output = output & ParseNode(nodeIterator)
                            If mTerminateParsing Then Exit For
                        Next nodeIterator
                    End If
                    'UPGRADE_NOTE: Object nodeIterator may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
                    nodeIterator = Nothing
                    'do newline if the node is one requiring a newline
                    If (tagname = "BR" Or tagname = "H1" Or tagname = "H2" Or tagname = "H3" Or tagname = "H4" Or tagname = "H5" Or tagname = "H6" Or tagname = "ADDRESS" Or tagname = "CENTER" Or tagname = "PRE" Or tagname = "LI" Or tagname = "DD" Or tagname = "DT" Or tagname = "TR" Or tagname = "LEGEND" Or tagname = "FIELDSET" Or tagname = "DIV") And mstrnewline = vbNewLine Then
                        output = output & vbNewLine
                        mstrnewline = ""
                        mblnJustDidLink = False
                    ElseIf (tagname = "P" Or tagname = "DL" Or tagname = "OL" Or tagname = "UL" Or tagname = "TABLE") And mstrnewline = vbNewLine Then
                        output = output & vbNewLine & "hytghytg" & vbNewLine
                        mstrnewline = ""
                        mblnJustDidLink = False
                    ElseIf tagname = "TD" Or tagname = "TH" Then
                        If VB.Right(output, 1) <> " " And VB.Right(output, 2) <> vbNewLine Then
                            output = output & " "
                            mstrnewline = vbNewLine
                        End If
                    ElseIf tagname = "Q" Then
                        If VB.Right(output, 1) = " " Then output = VB.Left(output, Len(output) - 1)
                        output = output & modI18N.GetText("[quotation marks]")
                        mstrnewline = vbNewLine
                    End If
            End If
            ParseNode = output
        End If
    End Function

    Public Sub StopBrowsers()
        'stops all browser activity

        'Debug.Print "StopBrowsers is clearing mNavigatingObject"
        If mWebBrowser.IsBusy Then Call mWebBrowser.Stop()
        Call PlayDoneSound()
        staMain.Items.Item("txtbusy").Text = modI18N.GetText("Done") 'once parsing is complete, change status to done
        cmdStop.Enabled = False
        'update location bar with actual URL (inc. http://etc.)
        cboAddress.Text = mWebBrowser.Url.ToString()
        'check and see if we have anything to display
        Call ProcessPage()
        'Call DisplayOutput(WebBrowser.Document.body.innerText)
    End Sub

    Public Sub RefreshCurrentPage()
        'Call this when you want to redisplay the current page without reloading it from the server -
        'for example when you've amended the DOM and want to show the differences

        Dim i As Integer ' counter
        Dim caretPosition As Integer ' position of caret
        'Dim lineNumber As Long ' position of line

        Debug.Print("REFRESH CURRENT PAGE")
        'clear data
        Call ClearPageData()
        Call modAccesskeys.ClearAccessKeys() ' clear any access keys
        'store the caret position and line number
        caretPosition = txtText.SelectionStart
        'lineNumber = GetCurrentLineIndex(txtText)
        'clear text box
        txtText.Text = ""
        'check if we have frames
        Call ParseDocument()
        'Do zoom
        Call ZoomIE(mAlldocs, 0)
        'If Not mblnFollowingInternalLink Then
        If mElementWithFocus Is Nothing Then
            'simple refresh, restore the caret position
            txtText.SelectionStart = caretPosition
            txtText.SelectionLength = 0
        Else
            'we had an element that took the focus, need to move to it.
            'UPGRADE_NOTE: Object mElementWithFocus may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
            mElementWithFocus = Nothing
            i = InStr(1, txtText.Text, AJAX_TARGET_MARKER)
            If i > 0 Then
                txtText.SelectionStart = i - 1
                txtText.SelectionLength = Len(AJAX_TARGET_MARKER)
                txtText.SelectedText = ""
            Else
                'failed to find marker for ajax element, for some reason.
                'Leave the cursor where it was.
                txtText.SelectionStart = caretPosition
                txtText.SelectedText = ""
            End If
        End If
        'Call Scroll(txtText, lineNumber)
        'Call ScrollToCursor(txtText)
        'End If
        'mblnFollowingInternalLink = False
    End Sub

    Private Sub SkipToForm(ByRef direction As Integer)

        If GotoLineStarting(GetText("Form"), direction) Then
            'Don't select - stops screenreaders reading line, they read the document instead.
            'Call SelectCurrentParagraph
        End If
    End Sub

    Private Sub SkipLinks(ByRef direction As Integer, Optional ByRef reverse As Boolean = False)

        'Causes the cursor to jump to the start of the next paragraph over any links
        'If reverse is set then goes to the first line that IS a link or whatever.
        Dim lineNumber As Integer
        Dim found As Boolean
        Dim line As String
        Dim numberLines As Integer
        Dim startPreviousLine As Integer
        Dim endThisLine As Integer
        Dim foundNewline As Integer

        lineNumber = GetCurrentLineIndex(txtText) + direction
        numberLines = GetNumberOfLines(txtText)
        found = False
        While lineNumber < numberLines And lineNumber >= 0 And Not found
            'Debug.Print "Linenumber:" & lineNumber
            line = Trim(GetNumberedLine(txtText, lineNumber))
            'Debug.Print "Line:[" & line & "]"
            If InStr(1, line, ID_LINK, CompareMethod.Text) <> 1 And InStr(1, line, ID_SELECT, CompareMethod.Text) <> 1 And InStr(1, line, ID_BUTTON, CompareMethod.Text) <> 1 And InStr(1, line, ID_CHECKBOX, CompareMethod.Text) <> 1 And InStr(1, line, ID_RADIO, CompareMethod.Text) <> 1 And InStr(1, line, ID_TEXTBOX, CompareMethod.Text) <> 1 And InStr(1, line, ID_PASSWORD, CompareMethod.Text) <> 1 And InStr(1, line, ID_SUBMIT, CompareMethod.Text) <> 1 And InStr(1, line, ID_FILE, CompareMethod.Text) <> 1 And InStr(1, line, ID_RESET, CompareMethod.Text) <> 1 And InStr(1, line, ID_TEXTAREA, CompareMethod.Text) <> 1 And InStr(1, line, ID_OBJECT, CompareMethod.Text) <> 1 Then
                'ASSERTION: The current line is none of the "focusable" items on the page, like a link.
                'Debug.Print "Structural"
                If reverse Then
                    'Not any of the types we're looking for, definitely not found.
                    found = False
                Else
                    'hurrah, it's not a WebbIE structural item!  Now check it has some content
                    If UBound(Split(Trim(line), " ")) > 1 Then
                        'And some content: finally, the question is whether this line is
                        'the start of a paragraph or just some text.
                        'Debug.Print "content:" & line
                        If lineNumber > 0 Then
                            startPreviousLine = modAPIFunctions.GetCharacterIndexOfLine(txtText, lineNumber - 1)
                            If startPreviousLine = 0 Then startPreviousLine = 1
                            endThisLine = modAPIFunctions.GetCharacterIndexOfLine(txtText, lineNumber) + Len(line) - 2
                            foundNewline = InStr(startPreviousLine, txtText.Text, vbNewLine)
                            If (foundNewline > 0) And (foundNewline < endThisLine) Then
                                'okay, this line is directly preceded by a newline
                                found = True
                            Else
                                'nope, no newline: this is part of a paragraph, or end of the page, so skip
                                lineNumber = lineNumber + direction
                            End If
                        Else
                            'okay, we're at the start of the text, so call it found
                            found = True
                        End If
                    End If
                End If
            Else
                If reverse Then
                    'Found a link etc., good!
                    found = True
                Else
                    'Nope, keep looking.
                    lineNumber = lineNumber + direction
                End If
            End If
            If Not found Then
                lineNumber = lineNumber + direction
            End If
        End While
        If found Then
            txtText.SelectionStart = 1
            txtText.SelectionLength = 0
            txtText.SelectionStart = GetCharacterIndexOfLine(txtText, lineNumber)
            txtText.SelectionLength = 0
            'We don't call SelectCurrentParagraph because the selection stops screenreaders (Thunder,
            'Narrator) from reading the line. Instead they read the whole document.
            'Call SelectCurrentParagraph
            'Call ScrollToCursor(txtText)
        Else
            Call PlayErrorSound()
        End If
    End Sub

    Private Sub SetPageCharset()
        'TODO Don't know if I need to do this at all. 
        ''works out the charset to use for the page, based on the user settings and the reported
        ''page charset from the IE object (which will be Windows-1252 if it doesn't know, by the way,
        ''so that result indicates it should be changed to the user's setting)
        '
        'Dim i As Integer ' counter
        'Dim ieCharset As String

        ''Switch to alternative character sets if necessary to display webpage
        '      txtText.Font = VB6.FontChangeGdiCharSet(txtText.Font, CType(intDefaultCharset, Byte)) ' set the default to the user's normal charset
        'lngPageLocale = lngDefaultLocale ' set the locale to the default
        ''lngPageLocale = CHARSET_WESTERN_EUROPEAN
        'If blnAlwaysUseUserDefaultLanguage Then
        '	'always use default user language: leave things as they are
        'Else
        '	'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.charSet. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        '          ieCharset = mWebBrowser.Document.DomDocument.charSet
        '	For i = 1 To numberLanguageCharsetMappings
        '		'set the text box font to the correct character set
        '		If ieCharset = languageCharsetMappings(i).ieDescription Then
        '			txtText.Font = VB6.FontChangeGdiCharSet(txtText.Font, languageCharsetMappings(i).windowsCharset)
        '			lngPageLocale = languageCharsetMappings(i).localeID
        '			'Debug.Print "Charset used: " & txtText.Font.charset & " Locale: " & lngPageLocale & " IE reports: " & languageCharsetMappings(i).ieDescription
        '			Exit For
        '		End If
        '	Next i
        '	'ASSERTION: either a match was found and the charset and locale updated or we're on the default - so the values are valid
        '	'if we're in ISO8859-1 (Western European) or Windows-1252 (Western European), switch to the user's chosen
        '	'encoding instead
        '	If txtText.Font.GdiCharSet() = CHARSET_WESTERN_EUROPEAN Then
        '		txtText.Font = VB6.FontChangeGdiCharSet(txtText.Font, intDefaultCharset)
        '		lngPageLocale = lngDefaultLocale
        '		'Debug.Print "Back to default."
        '		'Debug.Print "Charset used: " & txtText.Font.charset & " Locale: " & lngPageLocale & " IE reports: " & webBrowser.Document.charset
        '	End If
        'End If
        ''update the other components
        'staMain.Font = VB6.FontChangeGdiCharSet(staMain.Font, txtText.Font.GdiCharSet())
        'cboAddress.Font = VB6.FontChangeGdiCharSet(cboAddress.Font, txtText.Font.GdiCharSet())
    End Sub


    Public Sub UpdateTextarea(ByRef elementText As String, ByRef node As mshtml.IHTMLDOMNode)
        'update the current text area

        Dim e As mshtml.IHTMLElement3
        Dim i As Integer

        If Not mblnIEVisible Then
            node.nodeValue = elementText
            e = CType(node, mshtml.IHTMLElement3)
            Call e.setActive()

            mblnIEVisible = True
            Call mWebBrowser.Focus()
            For i = 1 To 100 : System.Windows.Forms.Application.DoEvents() : Next i
            mblnIEVisible = False
            Call txtText.Focus()
            For i = 1 To 100 : System.Windows.Forms.Application.DoEvents() : Next i
        End If
        Call RefreshCurrentPage()
    End Sub

    Public Sub UpdateSelection(ByRef selectNumber As Integer, ByRef optionNumber As Integer)
        'updates the selected item with the selected option.

        'Debug.Print "sN:" & selectNumber & " oN:" & optionNumber
        Dim aNode As mshtml.IHTMLDOMNode ' used to iterate through the option nodes
        Dim bNode As mshtml.IHTMLDOMNode ' ditto
        Dim selectNode As mshtml.IHTMLDOMNode
        Dim htmlE As mshtml.IHTMLElement
        Dim nodeCount As Integer ' used to track which of the select's option nodes we're up to
        Dim charPos As Integer ' position of the caret
        Dim htmlE3 As mshtml.IHTMLElement3 'used to fire DHTML event
        Dim childNodeCollection As mshtml.IHTMLDOMChildrenCollection
        Dim grandChildNodeCollection As mshtml.IHTMLDOMChildrenCollection

        charPos = GetCharacterIndexOfLine(txtText, GetCurrentLineIndex(txtText)) ' store the position of the caret
        txtText.Text = "" 'clear text box
        staMain.Items.Item(0).Text = modI18N.GetText("Busy")
        'update the DOM with which item is selected: first clear all the items
        selectNode = CType(selects(selectNumber).node, mshtml.IHTMLDOMNode)
        childNodeCollection = CType(selectNode.childNodes, mshtml.IHTMLDOMChildrenCollection)
        'of the select at least)
        nodeCount = 0 ' start counting nodes
        For Each aNode In childNodeCollection
            If aNode.nodeName = "OPTION" Then
                'we have an option node
                htmlE = CType(aNode, mshtml.IHTMLElement)
                Call htmlE.setAttribute("selected", False) ' make it not-selected
                nodeCount = nodeCount + 1 ' increase the count
                'If we have the newly selected node, set the selected attribute
                If nodeCount = optionNumber Then ' really? it's 1-based array? TODO check this!
                    'this node is the selected one
                    Call htmlE.setAttribute("selected", True) ' make it selected
                End If
                'Debug.Print ("Just did " & nodeCount)
            ElseIf aNode.nodeName = "OPTGROUP" Then
                'we have an option group
                grandChildNodeCollection = CType(aNode.childNodes, mshtml.IHTMLDOMChildrenCollection)
                For Each bNode In grandChildNodeCollection
                    If bNode.nodeName = "OPTION" Then
                        htmlE = CType(bNode, mshtml.IHTMLElement)
                        htmlE.setAttribute("selected", False) ' make it not-selected
                        nodeCount = nodeCount + 1 'increase the count
                        'If we have the newly selected node, set the selected attribute
                        If nodeCount = optionNumber Then ' Again, really? 1-based? TODO check!
                            'this node is the selected one
                            'Debug.Print bNode.attributes.getNamedItem("id").nodeValue
                            'Debug.Print bNode.attributes.getNamedItem("selected").nodeValue
                            Call htmlE.setAttribute("selected", True) ' make it selected
                            'Debug.Print bNode.attributes.getNamedItem("selected").nodeValue
                        End If
                    End If
                Next bNode
            End If
        Next aNode

        'activate appropriate script events
        htmlE3 = CType(selects(selectNumber).node, mshtml.IHTMLElement3)
        Call htmlE3.FireEvent("onchange")
        ''    'now update the display
        Call RefreshCurrentPage()
        txtText.SelectionStart = charPos 'set the position of the caret
        txtText.SelectionLength = 0
        'Call ScrollToCursor(txtText)
        staMain.Items.Item(0).Text = modI18N.GetText("Done")
    End Sub

    Public Sub StartNavigating(ByRef url As String)
        'called when WebbIE needs to go somewhere new

        'First, stop the getting of locations for urls
        Call StopGettingLocations()
        'Now reset the "we're only showing forms" mode
        mShowFormsOnly = False
        If StrComp(VB.Right(url, 3), "pdf", CompareMethod.Text) = 0 And Me.mnuOptionsFetchPDFfromGoogle.Checked Then
            ' got a pdf file that we should get from Google
            Call GetPDFFromGoogle(url)
        Else
            'Might be XML or HTML
            'finally send WebBrowser on its way, it's a normal file
            'Not going to just do this, going to count stuff.

            Call AddURLToRecent(url)
            cboAddress.Text = url ' update display
            Call PlayStartSound()
            Call mWebBrowser.Navigate(url)
        End If
    End Sub

    Private Sub mWebBrowser_Navigating(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.WebBrowserNavigatingEventArgs) Handles mWebBrowser.Navigating
        Dim url As String = eventArgs.Url.ToString()
        Dim TargetFrameName As String = eventArgs.TargetFrameName
        Dim Cancel As Boolean = CType(eventArgs.Cancel, Boolean)
        'This fires when navigation commences, and fires for each frame or page.

        Dim base As String
        Dim urlBase As String
        Dim hasInternalLinkPart As Boolean

        Dim webBrowserMain As WebBrowser = CType(eventSender, WebBrowser)

        'Note that a page action HAS been triggered.
        mNoPageActionSoRefresh = False

        'DEV: putative adblock code. Seems to make http://www.free-codecs.com/real_Alternative_download.htm
        'never finish loading, so needs a bit more work.
        '    If InStr(1, url, ".doubleclick.net") > 0 Or InStr(1, url, ".atdmt.com") > 0 Then
        '        Debug.Print "Skipped ad"
        '        Cancel = True
        '        Exit Sub
        '    End If

        'First, stop the getting of locations for urls
        Call StopGettingLocations()
        'Now reset the "we're only showing forms" mode
        mShowFormsOnly = False

        'Is there an internal link?
        '3.11.0 - not an internal link if ends with #!
        hasInternalLinkPart = (InStr(1, url, "#") > 0) And VB.Right(url, 1) <> "#"

        'Is it on this page, or on a different page?
        'Our current url is mWebBrowser.Url
        'The target url is url.

        'First, work out our current URL without any internal target
        base = modInternalTargets.ExtractNonInternalTargetFromURL(mWebBrowser.Url.ToString())
        'ASSERTION: base is now the current location without any internal target.

        'work out the new URL without any internal target
        urlBase = modInternalTargets.ExtractNonInternalTargetFromURL(url)

        'base should now contain the current URL without target. We can now determine
        'if the navigation is a within-page internal link by checking to see if base
        'is identical to url without the internal target: if so, it is in the same page, and we should stop
        'mWebBrowser and just move the cursor directly.
        'Debug.Print "BASE [" & base & "]"
        'Debug.Print "URL  [" & urlBase & "]"
        '3.7.4 But always do a page navigation if mForceNavigation is set, because it might be a form submission
        'that happens to point to an internal link of the same page (e.g. submit.php/#comment on MetaFilter)
        '3.8.8 Made this Instr(1, urlBase, base) instead of StrComp(urlBase, base) so that parts are matched.
        If Len(base) > 0 And InStr(1, urlBase, base, CompareMethod.Text) = 1 And hasInternalLinkPart And Not mForceNavigation Then
            'aha, this is an internal link on the same page: don't process, just
            'move the pointer. Won't fire _DocumentComplete
            'TODO Need pass cancel back, probably as an object.
            Cancel = True ' to stop navigation
            'remember where we started.
            mInternalLinkNavigationStart = modAPIFunctions.GetCurrentLineIndex(txtText)
            cboAddress.Text = url
            txtText.Text = "" 'clear the main text, stops screen readers reading
            'We should perhaps process pDisp rather than mWebBrowser, but it
            'doesn't work very well. So use mWebBrowser, even though internal links
            'won't work on frame pages. Also, we're not clicking on links in pages,
            'we're calling mWebBrowser.Nav, so we're probably breaking the frames
            'mechanism anyway.
            mInternalTarget = modInternalTargets.ExtractInternalTargetFromURL(url)
            mSeekingInternalTarget = True
            Debug.Print("Got internal target: " & mInternalTarget)
            'Check that the current web page CAN be refreshed, by checking there is a body.
            'If not, then cancel.
            'TODO Maybe we should not do this, but reload the page?
            Dim mshtmlDoc As mshtml.HTMLDocument
            mshtmlDoc = CType(mWebBrowser.Document.DomDocument, mshtml.HTMLDocument)
            If mshtmlDoc.body Is Nothing Then
                'nothing to parse (strangely: frames?)
            Else
                Call RefreshCurrentPage()
                Call MoveCursorToInternalTarget()
            End If
        Else
            If hasInternalLinkPart Then
                'still have to determine internal link
                mSeekingInternalTarget = True
                mInternalTarget = modInternalTargets.ExtractInternalTargetFromURL(url)
            End If

            'Dev: you'll see at this point that I tried to be clever and use pDisp as the navigating object
            'to catch navigation. This led, eventually, to an enormous memory leak and a pretty non-functional
            'WebbIE. So fall back to relying on ReadyState, and worry about it breaking another time.
            'TODO Work out what is best in .Net land.

            '3.11.0 OK, repeated loads of the same page - that is, loading objects within the same page like in Gmail
            'may repeatedly load with just a # at the end of the url.
            '5.11.0 Check that this is a new URL, or don't abandon the current set of documents.
            If webBrowserMain Is mWebBrowser And mWebBrowser.Url.ToString() & "#" <> url And mWebBrowser.Url.ToString() <> url Then
                'It is!
                'Debug.Print "Top-level navigation started"
                mProcessNextDocumentComplete = False
            Else
                'no, this is a frame navigation. Might be new, might not.
                mProcessNextDocumentComplete = True
                'check what we have already.
                Call RefreshCurrentPage()
            End If
            'txtText.text = "" 'clear the main text, stops screen readers reading
            'txtText.Text = modi18n.GetText("Navigating...") Why not give the user a helpful
            'message? Because webBrowser keeps grabbing the focus, and if we don't
            'get it back all sort of rubbish gets read out. We need to grab it back to
            'the main text display, and to keep the extraneous text to a minimum,
            'we keep it blank.
            cmdStop.Enabled = True 'enable toolbar buttons
            tmrBusyAnimation.Enabled = True 'start animation
            staMain.Items.Item("txtbusy").Text = modI18N.GetText("Downloading")
            mnuBookmarksAddbookmark.Enabled = True 'enable adding a bookmark option
            'Well, what do we put in the address bar? Well, I've updated StartNavigating
            'to do the updating, so we'll leave it there. Otherwise we get every
            'advert url (if we use URL here) or the old url (if we use mWebBrowser.LocationURL)
            'cboAddress.text = mWebBrowser.LocationURL ' so we don't get all the nasty
            'advert links shown
            'Call cboAddress.AddItem(Replace(cboAddress.text, "http://", "")) 'add to drop down combo
            Call AddURLToRecent(cboAddress.Text)
            mnuLinksViewlinks.Enabled = False 'allow the links to be viewed in a separate form
        End If
        'Reset one-time "Must navigate" flag. 3.7.4
        mForceNavigation = False
    End Sub

    'TODO No _Enter event on WebBrowser now.
    'Private Sub mWebBrowser_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mWebBrowser.Enter
    '	'okay, we probably shouldn't have the focus: if we have, and we shouldn't, change focus to the text box.
    '	'Debug.Print "mWebBrowser has focus"
    '	
    '	If mblnIEVisible Then
    '		'well, that's fine
    '	Else
    '		'whoops! Go back to text box
    '		Call txtDummyBox.Focus()
    '	End If
    'End Sub

    '=============================================================================================
    ' WEBBROWSER EVENTS
    ' Handle the important mWebBrowser events, notably when it's finished getting a page.
    '=============================================================================================

    'UPGRADE_ISSUE: SHDocVw.WebBrowser event mWebBrowser.NavigateError was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="ABD9AF39-7E24-4AFF-AD8D-3675C1AA3054"'
    Private Sub mWebBrowser_NavigateError(ByVal pDisp As Object, ByRef url As Object, ByRef Frame As Object, ByRef StatusCode As Object, ByRef Cancel As Boolean)


        'Cancel = True ' Don't do Cancel=True, it means we never get any error pages load - just keeps
        'navigating. 3.7.7. See below as well.
        'mblnErrorPage = True ' don't try to parse what we'll get: it'll be an error page
        'DEV: note that this variable as written only applies at the site level: for sites
        'where there are frames, this gets set to true even where the problem lies in
        'only one frame. This means that the whole page fails to parse. This is clearly
        'wrong, so I've commented out the mblnErrorPage = True, so it'll never happen:
        'it means that error pages will be parsed, but I don't care about that at present,
        'it is more important that the frame pages (e.g. slashdot.org) are rendered.
        Debug.Print("NavigateError")
    End Sub

    Private Sub mWebBrowser_NewWindow(ByVal eventSender As System.Object, ByVal eventArgs As System.ComponentModel.CancelEventArgs) Handles mWebBrowser.NewWindow
        Dim Cancel As Boolean = eventArgs.Cancel

        'This is intended to ask the user if they want to allow a pop-up Window.  However, pop-up
        'windows are almost certainly advertisements.  So, there is a user setting "mnuAllowpopups",
        'which defaults to unchecked.  If this is the case, a pop-up window will be suppressed.
        'If it is true, then a popup is allowed but the user is asked to okay it.
        'See http://support.microsoft.com/kb/q184876/ for more information.
        If mnuOptionsAllowPopups.Checked Then
            ''        'Let's do a new frmMain and pass this to it. Again, see http://support.microsoft.com/kb/184876.
            ''        'Set frmNew = New frmMain
            ''        'frmNew.Visible = True
            ''        'frmNew.mWebBrowser.RegisterAsBrowser = True
            ''        'Set ppDisp = frmNew.mWebBrowser.object
            'This is a lovely idea, but WebbIE is completely not designed for multiple windows. Each window
            'uses the same array of links etc. So different windows are actually representing the same page.
            'Lots of work to make pop-ups work properly.
            'Better idea: just shell WebbIE with url. May 2007
            'Call Shell(App.Path & "\" & App.EXEName & " " & ppDisp.LocationURL, vbNormalFocus)
            'Ah, this is also a great idea. But you can't get the location url from the ppDisp object because
            'it is Nothing when this event is called.
            'So just let the popup happen. 3.12.2.
        Else
            'popups are not permitted by the user settings
            Call PlayErrorSound()
            staMain.Items.Item("txttitle").Text = modI18N.GetText("Pop-up window blocked")
            Cancel = True
        End If
    End Sub

    Private Sub mWebBrowser_DocumentCompleted(ByVal sender As Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles mWebBrowser.DocumentCompleted
        Dim url As String = e.Url.ToString()
        'replacement for using the change in the status bar to indicate download status...!

        'I'm so bored of handling the odd behaviour of WebBrowser. This allows me to use the IDE more effectively.
        If String.Compare(url, "") = 0 Or String.Compare(url, "http:///") = 0 Then
            tmrBusyAnimation.Enabled = False
            Exit Sub
        End If

        'DEV: okay, so sometimes web pages don't load. Maybe this is because
        'we spend too long processing things for events before READYSTATE_COMPLETE?
        'I'll try taking things out.

        'Don't display the name of the page. It might be an IFRAME loading, in which case
        'you will delete the display of the already-loaded parent page.

        'Has navigation ceased? There are two approaches to determining this: first,
        'we can check readyState, but this fires READYSTATE_COMPLETE (4) not only
        'when a page finishes for the first time, but when a frame page loads a
        'new page. So we can't rely on it for handling frame pages BUT it does work
        'quite reliably. Second, we can check to see if the navigating pDisp we've
        'just got is the same pDisp as started navigating, and if so, navigation
        'has completed. This works with frames, BUT I'm concerned that sometimes it
        'doesn't work to trigger a page completion. I'm going to go with the latter
        'until I can determine experimentally what problems there are, if any.
        'If mWebBrowser.readyState = READYSTATE_COMPLETE Then ' So not using this.
        'If (pDisp Is mNavigatingObject) Or (mWebBrowser.LocationURL = pDisp.LocationURL) Then
        'MsgBox "2 Navigation is complete: original web browser object found: " & mWebBrowser.LocationURL
        'this is the  top-level navigating object: we've finished loading
        'OR for some reason the
        'url for this pDisp is the same as the mWebBrowser url, so it's
        'probably right. If we don't catch the latter situation, some pages
        'with ads or iframes (I think) don't load fully -see www.metafilter.com
        'for an example, load a bunch of pages, some won't load.

        'Aha! It's because we're doing the wrong comparison:
        'http://support.microsoft.com/kb/q180366/
        'We should be doing mWebBrowser.Object. Right then:

        'OK, so here's one of the problems. This might not be the last
        'complete event, because frames - all frames? No, IFRAMES, surely -
        'come after the navigating object. So we update the collection of
        'Documents and reprocess, surely. Well, let's not bother for the time being,
        'since they're probably adverts. Ah, here's one important website when we
        'need to get them: www.gmail.com. Arse. OK, let's call ProcessPage if this
        'happens.
        'If mNavigatingObject Is Nothing Then
        '3.6.1. We get here when a page has loaded and then another frame comes in.
        'If we uncomment this then we catch some IFRAMES we wouldn't otherwise.
        'BUT lots of pages (with ads) then load twice, which is crap and can make
        'screenreaders stutter or worse start again at the top of the page.
        'So for the time being we leave it commented.
        '3.7.4 However, we generally reset the mNavigatingObject just below, in the
        'If block under pDisp is mNavigatingObject. I've found that clicking an A element
        'with an onclick handler generates two navigations, so we only want to move on the
        'second (you can check this in the test scripts). I've also found that you can
        'check the .Document.readyState of the mWebBrowser, and if this isn't complete then
        'there is still navigation going on. See below.
        'Call ProcessPage
        'Debug.Print "mNavigatingObject is nothing"
        'End If
        '3.7.4 Added check for Document also being ready to load.
        'TODO For now, just do ReadyState on mWebBrowser
        If mWebBrowser.ReadyState = System.Windows.Forms.WebBrowserReadyState.Complete Then
            ''Nope, sometimes the url argument is wrong, notably strange pages with ads. So
            ''use the webBrowser url.
            'Assume this funky new mechanism is right.
            cboAddress.Text = mWebBrowser.Url.ToString()
            Dim docMSHTML As mshtml.HTMLDocument
            docMSHTML = CType(mWebBrowser.Document.DomDocument, mshtml.HTMLDocument)
            Call AddLocationTitle((mWebBrowser.Url.ToString()), docMSHTML.title)
            'Clear the internal link record
            mInternalLinkNavigationStart = -1

            'Get any RSS feed for the page: now, do we use pDisp or mWebBrowser?
            'Well, pDisp doesn't seem to work well, so use mWebBrowser.
            gstrRSSFeedURL = modRSS.CheckForRSSAlternate(CType(docMSHTML, mshtml.IHTMLDocument3))
            If Len(gstrRSSFeedURL) > 0 Then
                Call PlayRSSSound()
            End If
            'Debug.Print "gstrRSSFeedURL:" & gstrRSSFeedURL
            Call frmRSS.DisplayRSS(gstrRSSFeedURL)

            'apply user stylesheet if any
            '        If frmIEOptions.useUserStyle Then
            '            Call frmIEOptions.SetUserStyle(mWebBrowser.Document)
            '        End If

            'Do the processing if we have got a same-page navigation - 3.11.0
            'If mProcessNextDocumentComplete Then
            mProcessNextDocumentComplete = False
            'OK, our VB6 "do processing on Javascript onload" would handle processing, but we've lost
            'that in the transition to vb.net, so start the timer here.
            tmrProcessAfterLoad.Enabled = True
            'End If


            'Web-ARIA support - actually, no, this is pretty dumb...
            '        Dim b As IHTMLBodyElement
            '        Set b = mWebBrowser.Document.body
            '        If InStr(1, b.getAttribute("role"), "application", vbTextCompare) > 0 Then
            '            'This is a web page working as an application.
            '            If Not mblnIEVisible Then Call cmdViewIE_Click
            '        ElseIf InStr(1, b.getAttribute("role"), "document", vbTextCompare) > 0 Then
            '            'This is a web page working as a document.
            '            If mblnIEVisible Then Call cmdViewIE_Click
            '        End If

            '    ElseIf mNavigatingObject Is Nothing Then
            '        'Why would we get a DocumentComplete event when the browser is finished?
            '        'Because we have just got an IFRAME. Redisplay whole page.
            '        Debug.Print "Got IFRAME: " & pDisp.LocationURL
            '        Call ProcessPage
            '    ElseIf mWebBrowser.readyState = READYSTATE_COMPLETE Then
            '        'Finished navigating, but got a new frame: process
            '        Debug.Print "Got unknown:" & pDisp.LocationURL
            '        Call mNavigatingObjects.Add(pDisp, CStr(mNavigatingObjects.Count))
            '        Call ProcessPage
            '    Else
            '        'Not finished navigation, still have navigating object: must be
            '        'a frame: add to collection and carry on.
            '        Debug.Print "Got frame: " & pDisp.LocationURL
            '        Call mNavigatingObjects.Add(pDisp, CStr(mNavigatingObjects.Count))
        Else
            'Debug.Print "Not processing yet: " & url
        End If
    End Sub

    Private Sub ProcessPage()
        'call when page is loaded, including all frames

        'update location bar with actual URL (inc. http://etc.)
        cboAddress.Text = mWebBrowser.Url.ToString()
        If blnAlwaysUseUserDefaultLanguage Then
            'Get the correct charset for this page
            Call SetPageCharset()
        End If
        'now that the document is complete
        Call ClearPageData()
        mstrCurrentPageFilename = "" 'we haven't saved this page yet
        'okay, now go through all the loaded docs and display
        Call ParseDocument()
        'Get any unnamed links.
        If IsLocationsToGet() Then Call StartGettingLocations()
        'Assign the current element so we can see if it changes
        Dim doc As mshtml.HTMLDocument
        doc = CType(mWebBrowser.Document.DomDocument, mshtml.HTMLDocument)
        mActiveElement = doc.activeElement
        'Change display
        mnuFilePrint.Enabled = True
        mnuFileSave.Enabled = True
        mnuFileSaveas.Enabled = True
        mnuViewCroppage.Text = modI18N.GetText("&Crop page")
        cmdSkiplinks.Enabled = True
        cmdHeading.Enabled = True
        cmdMagnify.Enabled = True
        mnuViewMagnify.Enabled = mblnIEVisible
        mnuViewShrink.Enabled = mblnIEVisible
        cmdShrink.Enabled = True
        Call PlayAjaxSound()
    End Sub

    Private Sub mWebBrowser_StatusTextChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mWebBrowser.StatusTextChanged
        Dim text_Renamed As String = CType(eventSender, WebBrowser).StatusText

        staMain.Items.Item("txttitle").Text = text_Renamed
    End Sub

    Private Sub mWebBrowser_DocumentTitleChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mWebBrowser.DocumentTitleChanged
        Dim text_Renamed As String = CType(eventSender, WebBrowser).DocumentTitle

        Dim s As String

        s = Replace(text_Renamed, vbNewLine, " ")
        Me.Text = "WebbIE - " & s
    End Sub

    Private Sub Winsock_ConnectEvent(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Winsock.ConnectEvent

        Call modHTTPGetter.WinsockConnect()
    End Sub

    Private Sub Winsock_DataArrival(ByVal eventSender As System.Object, ByVal eventArgs As AxMSWinsockLib.DMSWinsockControlEvents_DataArrivalEvent) Handles Winsock.DataArrival

        Call modHTTPGetter.WinsockDataArrival(eventArgs.bytesTotal)
    End Sub

    Private Function ConstructHREF(ByRef destinationURL As String, ByRef urlPassed As String) As String
        'works out the correct href for any given HTML doc from the destinationURL for the doc
        ' and the current location (as passed in the url argument)

        Dim absoluteTest As Integer ' tests for the absolute reference
        Dim argumentTest As Integer ' tests for a GET query, e.g. lkjkj.com?what
        Dim frameHREF As String ' the result
        Dim currentURL As String 'the current base URL less any argument
        Dim url As String = "" ' the current Location
        Dim stringpos As Integer ' counter in text string
        Dim dFileDelimiter As String ' character that differentiates files and directories
        Dim cFileDelimiter As String ' character that differentiates files and directories for

        'Note that we don't handle what happens when the BASE element is used
        'to define the path of the current html file.
        'first, determine whether we should use \ or / as directory delimiters (/ on http sources,
        ' and \ on Windows paths).
        'TODO Clearly a bug here: url needs to be changed to urlPassed, maybe.
        If InStr(1, url, "\") > 0 Then
            'found a backslash - assume this is a Windows directory path
            cFileDelimiter = "\"
        Else
            'no backslash - assume this is an Internet url
            cFileDelimiter = "/"
        End If
        'do same for destination url
        If InStr(1, destinationURL, "\") > 0 Then
            'found a backslash - assume this is a Windows directory path
            dFileDelimiter = "\"
        Else
            'no backslash - assume this is an Internet url
            dFileDelimiter = "/"
        End If

        'check for the first flavour of url - absolute URLs with the authority (domain name)
        ' e.g. http://www.mysite.com/mypage.htm.  These are easiest since they require no
        'amendment.  We have to check though that the url is not a local address with a full
        'url in a query section, e.g. mypage.htm?goto=http://www.another.com
        absoluteTest = InStr(1, destinationURL, "://") ' location of the protocol
        argumentTest = InStr(1, destinationURL, "?") ' location of any query
        If absoluteTest > 0 And (argumentTest = 0 Or absoluteTest < argumentTest) Then
            'definitely an absolute URL with authority (domain name): we've found the protocol indicator
            '(://) before any queries (?).  Use src unaltered
            frameHREF = destinationURL
        Else 'it is a absolute or relative URL without the authority (domain name) (eg. page.htm or /page.htm)
            'now get the currentURL and excise any argument after ?
            argumentTest = InStr(1, url, "?")
            If argumentTest = 0 Then argumentTest = Len(url)
            currentURL = VB.Left(url, argumentTest)
            'now check for a slash at the beginning
            If VB.Left(destinationURL, 1) = cFileDelimiter Then
                'we have an absolute reference, e.g. /mypage.htm
                'find out if we have a file: or not
                If InStr(1, url, "file:") = 1 Then
                    'we have a file: type
                    stringpos = InStr(1, url, "://") + 3 'get past the ://
                    stringpos = InStr(stringpos, url, ":") ' get past the drive letter
                    'ASSERTION: stringpos plus / in destinationURL makes
                    ' e.g. file://c:/lsdjfkasjdlf
                    frameHREF = VB.Left(currentURL, stringpos) & destinationURL
                Else
                    'we have a webpage or other network resource
                    stringpos = InStr(1, currentURL, "://") + Len("://") 'get past the ://
                    stringpos = InStr(stringpos, currentURL, cFileDelimiter) - 1 ' to the first next /,
                    'then back one - remember that src starts with a /
                    'ASSERTION: stringpos is the first /, the end of the authority (domain name)
                    frameHREF = VB.Left(currentURL, stringpos) & destinationURL
                End If
            Else
                'we have a relative reference, e.g. mypage.htm
                'check if the main URL ends in a slash - if so, append straight to that
                'otherwise take off the current file and append
                If VB.Right(currentURL, 1) = cFileDelimiter Then
                    'ends in slash, just append relative path
                    frameHREF = currentURL & destinationURL
                Else
                    'doesn't, have to cut off the last filename
                    'get the last instance of a slash
                    stringpos = InStrRev(currentURL, cFileDelimiter)
                    'found the slash at the end of the address
                    frameHREF = VB.Left(currentURL, stringpos) & destinationURL
                End If
            End If
        End If
        'Debug.Print frameHREF
        ConstructHREF = frameHREF
    End Function

    Private Sub SelectCurrentParagraph()
        'Selects the current paragraph: call this after SkipLinks or similar
        'to give a visual representation of where we're up to.

        Dim foundEnd As Integer
        Dim foundStart As Integer
        Dim startFrom As Integer

        'Get the end point
        startFrom = txtText.SelectionStart
        If startFrom = 0 Then startFrom = 1
        foundEnd = InStr(startFrom, txtText.Text, vbNewLine, CompareMethod.Binary)
        If foundEnd = 0 Then
            foundEnd = Len(txtText.Text)
        End If
        foundStart = InStrRev(txtText.Text, vbNewLine, startFrom, CompareMethod.Binary)
        If foundStart > 0 Then
            foundStart = foundStart + 1 ' Dev: otherwise we select the newline.
            'You'd think it would be +len(vbnewline), but that goes too far!
        End If
        txtText.SelectionStart = foundStart
        txtText.SelectionLength = foundEnd - foundStart
    End Sub

    Private Sub SetupTabs()
        'corrects the tabstops on the main form. Call during Form_Load

        'stop web browser getting a tab
        mWebBrowser.TabStop = False
        workBrowser.TabStop = False
        'correct the tabs
        staMain.TabIndex = 0
        'tlbMain.TabIndex = 1
        lblAddress.TabIndex = 2
        cboAddress.TabIndex = 3
        'cmdGo.TabIndex = 4
        lblText.TabIndex = 4
        txtText.TabIndex = 5 '       alternate tabstop property
        mWebBrowser.TabIndex = 6 '    alternate tabstop property

    End Sub

    Private Sub SetupShortcutKeys()
        'update the shortcut keys on the main form

        mnuNavigateBack.Text = mnuNavigateBack.Text & vbTab & modI18N.GetText("Alt+Left")
        mnuNavigateForward.Text = mnuNavigateForward.Text & vbTab & modI18N.GetText("Alt+Right")
        mnuNavigateHome.Text = mnuNavigateHome.Text & vbTab & modI18N.GetText("Alt+Home")
        mnuLinksSkipup.Text = mnuLinksSkipup.Text & vbTab & modI18N.GetText("Ctrl+Up")
        mnuLinksNextlink.Text = mnuLinksNextlink.Text & vbTab & modI18N.GetText("Ctrl+Tab")
        mnuLinksPreviouslink.Text = mnuLinksPreviouslink.Text & vbTab & modI18N.GetText("Ctrl+Shift+Tab")
        mnuLinksSkiplinks.Text = mnuLinksSkiplinks.Text & vbTab & modI18N.GetText("Ctrl+Down")
        mnuNavigateStop.Text = mnuNavigateStop.Text & vbTab & modI18N.GetText("Escape")
    End Sub

    Private Sub GetPDFFromGoogle(ByRef url As String)

        cboAddress.Text = "http://www.google.com/search?q=cache:" & Replace(url, "http://", "")
        'UPGRADE_WARNING: Navigate2 was upgraded to Navigate and has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
        Call mWebBrowser.Navigate(New System.Uri(cboAddress.Text))
    End Sub

    Public Sub IdentifyHeadings(ByRef element As mshtml.IHTMLElement)
        'checks document for headings, if any, and populates headingLevel with the
        'tag to get for the highest-priority heading

        Dim doc As mshtml.IHTMLDocument3

        doc = CType(element.document, mshtml.IHTMLDocument3)
        If doc.getElementsByTagName("H1").length = 0 Then
            'no H1: try for H2.
            If doc.getElementsByTagName("H2").length = 0 Then
                'no H2: try for H3
                If doc.getElementsByTagName("H3").length = 0 Then
                    'no H3: try for H4
                    If doc.getElementsByTagName("H4").length = 0 Then
                        'no H4: try for H5
                        If doc.getElementsByTagName("H5").length = 0 Then
                            'No H5: try for H7
                            If doc.getElementsByTagName("H6").length = 0 Then
                                'No headings at all!
                                mHeadingLevel = "NO HEADING ELEMENT! SDFJSAFLKJSDLFJS K"
                            Else
                                mHeadingLevel = "H6"
                            End If
                        Else
                            mHeadingLevel = "H5"
                        End If
                    Else
                        mHeadingLevel = "H4"
                    End If
                Else
                    'h3 found
                    mHeadingLevel = "H3"
                End If
            Else
                'h2 found
                mHeadingLevel = "H2"
            End If
        Else
            'h1 found
            mHeadingLevel = "H1"
        End If
    End Sub

    Private Sub MoveCursorToInternalTarget()
        'moves the cursor to whereever TARGET_MARKER is in the text display and deletes
        'the marker

        Dim startAt As Integer
        startAt = InStr(1, txtText.Text, TARGET_MARKER, CompareMethod.Binary) - 1
        If startAt = -1 Then
            'TARGET_MARKER not found: no internal target (or a problem of some sort)
        Else
            'found target marker
            txtText.SelectionStart = startAt
            txtText.SelectionLength = Len(TARGET_MARKER)
            txtText.SelectedText = ""
        End If

    End Sub

    'TODO No _Enter event on WebBrowser now.
    'Private Sub workBrowser_Enter(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles workBrowser.Enter
    '	
    '	Debug.Print("Got workBrowser Focus")
    '	Call txtDummyBox.Focus()
    'End Sub

    Private Sub AddURLToRecent(ByVal url As String)

        Static recent As String
        url = Trim(url)
        If Len(url) > 0 Then
            url = Replace(url, "http://", "", , , CompareMethod.Text)
            url = Replace(url, "https://", "", , , CompareMethod.Text)
            If InStr(1, url, "?") > 0 Then
                url = VB.Left(url, InStr(1, url, "?", CompareMethod.Binary) - 1)
            End If
            If InStr(1, recent, url, CompareMethod.Text) > 0 Then
                'already in list
            Else
                'add to list
                Call cboAddress.Items.Add(url)
                recent = recent & "*" & url
            End If
        End If
    End Sub

    Private Function ContainsInputElement(ByRef e As mshtml.IHTMLElement) As Boolean
        'Returns whether this element, or its children, contains an input element - button, dir, input, textarea

        Dim childE As mshtml.IHTMLElement

        Select Case UCase(e.tagName)
            Case "INPUT"
                ContainsInputElement = True
            Case "DIR"
                ContainsInputElement = True
            Case "BUTTON"
                ContainsInputElement = True
            Case "ISINDEX"
                ContainsInputElement = True
            Case "MENU"
                ContainsInputElement = True
            Case "SELECT"
                ContainsInputElement = True
            Case "TEXTAREA"
                ContainsInputElement = True
            Case Else
                Dim ci As mshtml.IHTMLElementCollection
                ci = CType(e.children, mshtml.IHTMLElementCollection)
                For Each childE In ci
                    ContainsInputElement = ContainsInputElement(childE)
                    If ContainsInputElement Then Exit For
                Next childE
        End Select
    End Function

#If DEBUGGING Then
	'UPGRADE_NOTE: #If #EndIf block was not upgraded because the expression DEBUGGING did not evaluate to True or was not evaluated. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="27EE2C3C-05AF-4C04-B2AF-657B4FB6B5FC"'
	Public Sub DummyFunction()
	Debug.Print DummyFunctionPutInToStopYouCompilingAndReleasingWithDebuggingTurnedOn
	End Sub
#End If

    'UPGRADE_NOTE: tag was upgraded to tag_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
    Private Function GetItemIndex(ByRef s As String, ByRef position As Integer, ByVal tag_Renamed As String) As Integer

        Dim found As Integer
        Dim lastFound As Integer
        Dim counter As Integer

        lastFound = 1
        found = 1
        counter = 0
        tag_Renamed = vbNewLine & tag_Renamed
        On Error GoTo exitWhile
        While found > 0 And found < position And counter < 100000
            counter = counter + 1
            lastFound = found
            found = InStr(found + 1, s, tag_Renamed, CompareMethod.Binary)
        End While
exitWhile:

        GetItemIndex = counter - 1
    End Function

    Private Sub txtText_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtText.KeyDown
        Dim KeyCode As Integer = e.KeyCode
        Dim Shift As Integer = e.KeyData \ &H10000
        'allow users to follow a particular link by number

        Dim currentLine As String
        Dim itemNumber As Integer
        Dim prompt As String
        Dim title As String
        Static busy As Boolean

        If mIgnoreNextKeypress Then
            KeyCode = 0
            Exit Sub
        End If
        If busy Then
            Exit Sub
        End If
        busy = True
        mControlKeyPressed = ((Shift And VB6.ShiftConstants.CtrlMask) > 0)
        mShiftKeyPressed = ((Shift And VB6.ShiftConstants.ShiftMask) > 0)
        'Debug.Print "MCKP " & mControlKeyPressed
        Dim linkNumber As Integer
        'UPGRADE_NOTE: inputString was upgraded to inputString_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
        Dim inputString_Renamed As String
        If KeyCode = System.Windows.Forms.Keys.G And ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Then

            prompt = modI18N.GetText("Input link number:")
            title = modI18N.GetText("Follow link by number")
            inputString_Renamed = InputBox(prompt, title)
            If inputString_Renamed <> "" Then
                linkNumber = CType(Val(inputString_Renamed), Integer)
                'Debug.Print linkNumber
                If linkNumber > 0 And linkNumber <= numLinks Then
                    'cboAddress.Text = links(linkNumber).address
                    'Call cmdGo_Click
                    'Call WebBrowser.Navigate2(links(linkNumber).address)
                    Call StartNavigating(links(linkNumber).address)
                Else
                    prompt = modI18N.GetText("No link with that number")
                    title = modI18N.GetText("Link not found")
                    MsgBox(prompt, MsgBoxStyle.Exclamation, title)
                End If
            End If
        ElseIf KeyCode = System.Windows.Forms.Keys.F8 Then
            'pressed f8: if over link, show information

            currentLine = GetCurrentLine(txtText)
            If StrComp(VB.Left(currentLine, Len(ID_LINK)), ID_LINK, CompareMethod.Text) = 0 Then
                'move past the word "LINK" and grab the next 4 characters (up to 9999 links are possible - array can't take it though)
                'itemNumber = Val(Mid(currentLine, Len(ID_LINK) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_LINK)
                'Don't select - stops screenreaders reading line, they read the document instead.
                'Call SelectCurrentParagraph
                'UPGRADE_WARNING: Couldn't resolve default property of object GetUserFriendlyURL(links(itemNumber).address). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                MsgBox(modI18N.GetText("Link:") & vbTab & links(itemNumber).description & vbNewLine & modI18N.GetText("Address:") & " " & vbTab & GetUserFriendlyURL(links(itemNumber).address) & vbNewLine & modI18N.GetText("Full address:") & vbTab & links(itemNumber).address, MsgBoxStyle.OkOnly, modI18N.GetText("Link information"))
            Else
                Call PlayErrorSound()
            End If
        ElseIf KeyCode = System.Windows.Forms.Keys.F2 Then
            'Debug.Print "Line: & "; GetCurrentLineIndex(txtText) & vbNewLine & "Links: " & numLinks
        ElseIf KeyCode = System.Windows.Forms.Keys.Down And ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Then
            If mShowFormsOnly Then
                Call SkipToForm(SKIP_DOWN)
            Else
                Call SkipLinks(SKIP_DOWN)
            End If
        ElseIf (KeyCode = System.Windows.Forms.Keys.Tab And (Shift And VB6.ShiftConstants.CtrlMask) > 0) Then
            'Don't be tempted to put any SendKeys in here to encourage screenreaders to read the new line.
            'This will be keypress-handled and since Ctrl is down you'll get SkipLinks happening.
            If ((Shift And VB6.ShiftConstants.ShiftMask) = VB6.ShiftConstants.ShiftMask) Then
                Call SkipLinks(SKIP_UP, True)
            Else
                Call SkipLinks(SKIP_DOWN, True)
            End If
        ElseIf (KeyCode = System.Windows.Forms.Keys.Up And ((Shift And VB6.ShiftConstants.CtrlMask) > 0)) Then
            If mShowFormsOnly Then
                Call SkipToForm(SKIP_UP)
            Else
                Call SkipLinks(SKIP_UP)
            End If
        ElseIf ((Shift And VB6.ShiftConstants.AltMask) > 0) Then
            'pressed ALT and something: check for access key
            If Len(modAccesskeys.GetURL(KeyCode)) > 0 Then
                cboAddress.Text = modAccesskeys.GetURL(KeyCode)
                Call cmdGo_Click()
            End If
        ElseIf KeyCode = System.Windows.Forms.Keys.Space Then
            Call System.Windows.Forms.SendKeys.Send("{PGDN}")
            KeyCode = 0
            'DEV: Tried to implement a zoom in and out function like in Mozilla,
            'but didn't work: won't update text box. Don't know why.
            '    ElseIf KeyCode = 187 Then ' Magic number indicating "=" character
            '        If (Shift And vbCtrlMask) > 0 Then
            '            'Zoom in.
            '            #If UNICONTROL_STATE = USE_UNICONTROLS Then
            '                txtText.Font.size = txtText.Font.size + 2
            '                Call Me.Refresh
            '            #Else
            '                txtText.Font.size = txtText.Font.size + 2
            '                Call txtText.Refresh
            '            #End If
            '        End If
            '    Else
            '        Debug.Print "KeyCode:" & KeyCode
        ElseIf KeyCode = System.Windows.Forms.Keys.D1 And ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Then
            'Jump to next/previous Header 1
            Call GotoLineStarting(SECTION_MARKER_H1, CType(IIf((Shift And VB6.ShiftConstants.ShiftMask) > 0, -1, 1), Integer), False)
        ElseIf KeyCode = System.Windows.Forms.Keys.D2 And ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Then
            'Jump to next/previous Header 2
            Call GotoLineStarting(SECTION_MARKER_H2, CType(IIf((Shift And VB6.ShiftConstants.ShiftMask) > 0, -1, 1), Integer), False)
        ElseIf KeyCode = System.Windows.Forms.Keys.D3 And ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Then
            'Jump to next/previous Header 3
            Call GotoLineStarting(SECTION_MARKER_H3, CType(IIf((Shift And VB6.ShiftConstants.ShiftMask) > 0, -1, 1), Integer), False)
        ElseIf KeyCode = System.Windows.Forms.Keys.D4 And ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Then
            'Jump to next/previous Header 4
            Call GotoLineStarting(SECTION_MARKER_H4, CType(IIf((Shift And VB6.ShiftConstants.ShiftMask) > 0, -1, 1), Integer), False)
        ElseIf KeyCode = System.Windows.Forms.Keys.D5 And ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Then
            'Jump to next/previous Header 5
            Call GotoLineStarting(SECTION_MARKER_H5, CType(IIf((Shift And VB6.ShiftConstants.ShiftMask) > 0, -1, 1), Integer), False)
        ElseIf KeyCode = System.Windows.Forms.Keys.D6 And ((Shift And VB6.ShiftConstants.CtrlMask) > 0) Then
            'Jump to next/previous Header 6
            Call GotoLineStarting(SECTION_MARKER_H6, CType(IIf((Shift And VB6.ShiftConstants.ShiftMask) > 0, -1, 1), Integer), False)
        End If
        busy = False
    End Sub

    Private Sub txtText_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtText.KeyPress
        Dim KeyAscii As Integer = Asc(e.KeyChar)
        'response to user pressing a key

        Dim currentLine As String 'the line to search for elements
        Dim itemNumber As Integer ' the index number of the element clicked upon
        Dim i As Integer ' counter
        Dim currentPosition As Integer ' position of curson on the line
        Dim htmlE As mshtml.IHTMLElement ' used to allow access to the convenience functions
        Dim lineNumber As Integer

        If mIgnoreNextKeypress Then
            KeyAscii = 0
            GoTo EventExitSub
        End If
        currentPosition = txtText.SelectionStart 'position of cursor on the line
        Dim targetURL As String
        Dim newPassword As String
        Dim passwordPrompt As String
        Dim inputE As mshtml.IHTMLInputElement
        Dim newText As String
        If KeyAscii = CInt(System.Windows.Forms.Keys.Return) Or (mControlKeyPressed And (KeyAscii = Asc(vbLf))) Then 'if return or control-and-return pressed...
            currentLine = GetCurrentLine(txtText)
            'find out what this line actually contains:
            If StrComp(VB.Left(currentLine, Len(ID_LINK)), ID_LINK, CompareMethod.Text) = 0 Then
                'move past the word "LINK" and grab the next 4 characters (up to 9999 links are possible - array can't take it though)
                'itemNumber = Val(Mid(currentLine, Len(ID_LINK) + 2, 4))
                'MsgBox "Got: " & GetItemIndex(txtText.Text, txtText.selStart, ID_LINK) & " should be " & itemNumber
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_LINK)
                'check it isn't a javascript link
                'Debug.Print "link:" & links(itemNumber).address
                'MsgBox links(itemNumber).address
                If InStr(1, links(itemNumber).address, "javascript", CompareMethod.Text) = 1 Or VB.Right(links(itemNumber).address, 1) = "#" Then
                    'javascript, like href="javascript:GotoPage(4)".  Do a click event and refresh
                    currentPosition = txtText.SelectionStart
                    mForceNavigation = True ' 3.7.4
                    Call links(itemNumber).element.click()
                    '                Call ClearPageData
                    '                Call ParseDocument
                    '                txtText.selStart = currentPosition
                ElseIf InStr(1, links(itemNumber).address, "mailto:", CompareMethod.Text) = 1 Then
                    'it's a mailto link - open default mail client by clicking item
                    mForceNavigation = True ' 3.7.4
                    Call links(itemNumber).element.click()
                    Call RefreshCurrentPage()
                ElseIf InStr(1, links(itemNumber).address, "mail.yahoo.com", CompareMethod.Text) > 0 Then
                    '3.3.7 25 July 2007
                    'it's a Yahoo! mail link: click it.
                    mForceNavigation = True ' 3.7.4
                    Call links(itemNumber).element.click()
                ElseIf mForceDownloadLink Or mShiftKeyPressed Then
                    'Download link target to desktop instead of opening it.
                    targetURL = links(itemNumber).address
                    If InStr(1, targetURL, "?") > 0 Then
                        targetURL = VB.Right(targetURL, Len(targetURL) - InStrRev(targetURL, "?", Len(targetURL), CompareMethod.Binary))
                    End If
                    If InStr(1, targetURL, "/") > 0 Then
                        targetURL = VB.Right(targetURL, Len(targetURL) - InStrRev(targetURL, "/", Len(targetURL), CompareMethod.Binary))
                    End If
                    targetURL = Replace(targetURL, ":", "_")
                    targetURL = Replace(targetURL, "*", "_")
                    targetURL = Replace(targetURL, "/", "_")
                    targetURL = Replace(targetURL, "\", "_")
                    targetURL = Replace(targetURL, "?", "_")
                    Call modHTTPGetter.GetFile(links(itemNumber).address, modPath.GetSpecialFolderPath(CSIDL_DESKTOP) & "\" & targetURL)
                Else
                    'First, get the current line before we navigate - used
                    'for back and forward. Used to be in BeforeNavigate, but
                    'gets too confusing with all the frames and adverts triggering
                    'BeforeNavigate
                    'record the line number
                    lineNumber = GetCurrentLineIndex(txtText)
                    'we often get several  events for a page while it
                    'loads (e.g. adverts) and we only want to record the line number when
                    'there's actually something on the page, e.g. lineNumber > 1
                    If lineNumber > 1 Then
                        mobjNavigationRecord.Add(mWebBrowser.Url.ToString(), lineNumber)
                    End If
                    'Call gobjBackForwardsHandler.NavigationBegin(GetCurrentLineIndex(txtText))
                    'Now to handle the click
                    'DEV: two options here, for a link of some sort:
                    'Option 1: click it, assume IE starts navigating
                    'Option 2: extract the url and start going there manually
                    'In theory, do (1), since it supports more Javascript
                    'In practice, this can fail. For example, IBM.com in October 2009 has a Javascript-based
                    'set of drop-down navigation bars. They have valid hrefs but clicking does nothing.
                    'Added complication: on working in development, I notice that sometimes links don't work. Return does nothing.
                    'Checking it out (December 2008) I find this is because I'm getting an Error 70 Permission Denied on the
                    '.element object. So let's add some code (it'll be 3.8) that handles the permission problems.
                    'I've tried checking .address and just starting navigation
                    'if this is > 1 (to account for href="#") but .address
                    'always has the whole URL, even if the code just says "#".
                    'Options:
                    '0 Just use href. Clearly doesn't work on Javascript.
                    '1 I could parse the html to look for href="#" or href=""
                    '  or a complete lack of href, and do a .click if so.
                    '2 I could check for some onclick code, and if so do an
                    '  onclick: if not, do a manual click. If this fails do the href navigation.
                    '3 I could do a .click on everything
                    '[If I don't have the element I should always do the manual
                    'method, obviously]

                    'Turns out (3.11) that more stuff breaks if you don't do click. So do .click and
                    'provide a new menu option to force following the address.
                    'First, do I even have something to click, or is the user forcing following the address?
                    'Debug.Print "Item number: " & itemNumber
                    If links(itemNumber).element Is Nothing Or mForceFollowAddress Then
                        'have to do it manually
                        cboAddress.Text = links(itemNumber).address
                        Call cmdGo_Click()
                    ElseIf links(itemNumber).element.className = "Complete dummy test just to check we have the element okay" Then
                        'if the above line errors we'll fall through to this line: do a manual navigation. 3.8.0 Jan 2009.
                        Debug.Print("DEBUG: Fallthrough error because of unavailable object model.")
                        cboAddress.Text = links(itemNumber).address
                        Call cmdGo_Click()
                    ElseIf GetKeyState(VK_CONTROL) < 0 Then
                        'User pressing control and return, so do follow. 3.11
                        cboAddress.Text = links(itemNumber).address
                        Call cmdGo_Click()
                    Else
                        'can click. But do we want to? IBM links (www.ibm.com October 2009) don't produce any
                        'action when you click them - they have JavaScript functions attached, applied
                        'after the page loads. So reverse the previous presumption (3.10.2-) that
                        'if script, do click. Now it's if href, do navigate, otherwise click.
                        'Dev: This >1 length check is supposed to catch href="#" and suchlike, but I think the
                        '.address value gets populated from a property that is resolved to the canonical url, so
                        'it will always be "www.test.com/index.htm#" rather than just "#" - in other words, .address>1
                        'will always be true. Unless there is no href at all:
                        'OK, we have a url, which means we're going to follow it.
                        'got an address to use: but one further complication,
                        'if this link is in a frame then you have to click
                        'it or you break the frame handling.
                        'So 3.11: always do click. See commented-out code below for alternatives, but
                        'this will break lots of sites. October 2009.
                        Call links(itemNumber).element.click()
                    End If
                End If
                'Form select:
            ElseIf StrComp(VB.Left(currentLine, Len(ID_SELECT)), ID_SELECT, CompareMethod.Text) = 0 Then  '
                'itemNumber = Val(Mid(currentLine, Len(ID_SELECT) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_SELECT)
                If mControlKeyPressed Then
                    'control and return = submit form.
                    mForceNavigation = True ' 3.7.4
                    'UPGRADE_WARNING: Couldn't resolve default property of object selects().node.Form. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    Dim n As mshtml.IHTMLSelectElement
                    n = selects(itemNumber).node
                    Call n.form.submit()
                Else
                    Call frmSelect.Populate(CShort(itemNumber))
                    frmSelect.ShowDialog(Me)
                    Call txtText.Focus()
                End If
                'Form input button:
            ElseIf StrComp(VB.Left(currentLine, Len(ID_BUTTON)), ID_BUTTON, CompareMethod.Text) = 0 Then  '
                'itemNumber = Val(Mid(currentLine, Len(ID_BUTTON) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_BUTTON)
                htmlE = CType(buttonInput(itemNumber), mshtml.IHTMLElement) 'simulate a click of this button
                mForceNavigation = True ' 3.7.4
                Call htmlE.click()
                Call RefreshCurrentPage()
                'Don't select - stops screenreaders reading line, they read the document instead.
                'Call SelectCurrentParagraph
                'Form checkbox:
            ElseIf StrComp(VB.Left(currentLine, Len(ID_CHECKBOX)), ID_CHECKBOX, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_CHECKBOX) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_CHECKBOX)

                If mControlKeyPressed Then
                    'User has held down control and hit return, so submit the form
                    mForceNavigation = True ' 3.7.4
                    Call checkboxInput(itemNumber).form.submit()
                Else
                    Dim checkbx As mshtml.IHTMLInputElement
                    checkbx = checkboxInput(itemNumber)
                    checkbx.checked = Not checkbx.checked
                    'do a click in case there's a function
                    htmlE = CType(checkbx, mshtml.IHTMLElement)
                    mForceNavigation = True ' 3.7.4
                    Call htmlE.click()
                    'refresh the page
                    lineNumber = GetCurrentLineIndex(txtText)
                    Call RefreshCurrentPage()
                    Call modAPIFunctions.SetCurrentLineIndex(txtText, lineNumber)
                    'Don't select - stops screenreaders reading line, they read the document instead.
                    'Call SelectCurrentParagraph
                End If
            ElseIf StrComp(VB.Left(currentLine, Len(ID_RADIO)), ID_RADIO, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_RADIO) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_RADIO)
                Dim submitElement As mshtml.IHTMLInputElement
                htmlE = radioInput(itemNumber)
                submitElement = CType(htmlE, mshtml.IHTMLInputElement)
                If mControlKeyPressed Then
                    'User has held down control and hit return, so submit the form
                    mForceNavigation = True ' 3.7.4
                    Call submitElement.form.submit()
                Else
                    'okay, now we have to uncheck the other radio buttons in the form
                    For i = 1 To numRadioInputs
                        If radioInput(i).getAttribute("name").ToString = htmlE.getAttribute("name").ToString Then
                            Call radioInput(i).setAttribute("checked", False)
                        End If
                    Next i
                    'do a click in case there's a function
                    mForceNavigation = True ' 3.7.4
                    Call htmlE.click()
                    lineNumber = GetCurrentLineIndex(txtText)
                    Call RefreshCurrentPage()
                    Call modAPIFunctions.SetCurrentLineIndex(txtText, lineNumber)
                    'Don't select - stops screenreaders reading line, they read the document instead.
                    'Call SelectCurrentParagraph
                End If
            ElseIf StrComp(VB.Left(currentLine, Len(ID_PASSWORD)), ID_PASSWORD, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_PASSWORD) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_PASSWORD)
                htmlE = passwordInput(itemNumber)
                Dim passwordE As mshtml.IHTMLInputElement
                passwordE = CType(htmlE, mshtml.IHTMLInputElement)
                'Debug.Print "itemNumber: " & itemNumber
                If mControlKeyPressed Then
                    'User has held down control and hit return, so submit the form
                    mForceNavigation = True ' 3.7.4
                    Call passwordE.form.submit()
                Else
                    'check for a label
                    passwordPrompt = modFormLabelHandler.GetDescriptiveText(htmlE.getAttribute("id").ToString)
                    If passwordPrompt = "" Then passwordPrompt = modI18N.GetText("Enter your password")
                    newPassword = InputBox(passwordPrompt, GetText("Password"), htmlE.getAttribute("value").ToString)
                    System.Windows.Forms.Application.DoEvents()
                    Call txtText.Focus()
                    System.Windows.Forms.Application.DoEvents()
                    'TODO differentiate between Cancel and Entering Nothing.
                    If (newPassword <> "") Then
                        Call htmlE.setAttribute("value", newPassword) 'give password to IE
                    End If
                    lineNumber = GetCurrentLineIndex(txtText)
                    Call RefreshCurrentPage()
                    Call modAPIFunctions.SetCurrentLineIndex(txtText, lineNumber)
                    'Don't select - stops screenreaders reading line, they read the document instead.
                    'Call SelectCurrentParagraph
                End If
            ElseIf StrComp(VB.Left(currentLine, Len(ID_SUBMIT)), ID_SUBMIT, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_SUBMIT) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_SUBMIT)
                htmlE = submitInput(itemNumber) 'simulate a click of this button
                inputE = CType(htmlE, mshtml.IHTMLInputElement)
                mForceNavigation = True ' 3.7.4
                If mControlKeyPressed Then
                    'Control and Enter: force a submit of the form.
                    Call inputE.form.submit()
                Else
                    'Just do a click on this element, assume that'll work.
                    Call htmlE.click()
                End If
                'But what if the submit button has not created a page change? This happens, for
                'example, when you're on Facebook and update your Status or something. So we
                'have to either (1) refresh all the time or (2) check to see if there isn't a
                'page change, and if not, do a refresh.
                'Let's try checking.
                tmrRefreshIfNotChange.Enabled = True
                mNoPageActionSoRefresh = True
            ElseIf StrComp(VB.Left(currentLine, Len(ID_FILE)), ID_FILE, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_FILE) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_FILE)
                htmlE = fileInput(itemNumber) 'simulate a click of this button
                inputE = CType(htmlE, mshtml.IHTMLInputElement)
                If mControlKeyPressed Then
                    'User has held down control and hit return, so submit the form
                    mForceNavigation = True ' 3.7.4
                    Call inputE.form.submit()
                Else
                    mForceNavigation = True ' 3.7.4
                    Call htmlE.click()
                    lineNumber = GetCurrentLineIndex(txtText)
                    Call RefreshCurrentPage()
                    Call modAPIFunctions.SetCurrentLineIndex(txtText, lineNumber)
                End If
            ElseIf StrComp(VB.Left(currentLine, Len(ID_RESET)), ID_RESET, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_RESET) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_RESET)
                htmlE = resetInput(itemNumber)
                mForceNavigation = True ' 3.7.4
                Call htmlE.click()
                Call RefreshCurrentPage()
            ElseIf StrComp(VB.Left(currentLine, Len(ID_TEXTAREA)), ID_TEXTAREA, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_TEXTAREA) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_TEXTAREA)
                htmlE = textAreaInput(itemNumber)
                inputE = CType(htmlE, mshtml.IHTMLInputElement)
                If mControlKeyPressed Then
                    'User has held down control and hit return, so submit the form
                    mForceNavigation = True ' 3.7.4
                    Call inputE.form.submit()
                Else
                    'check for a label
                    frmTextareaInput.areaLabel = modFormLabelHandler.GetDescriptiveText(htmlE.getAttribute("id").ToString)
                    Call frmTextareaInput.Populate(CType(htmlE, mshtml.IHTMLDOMNode))
                    Call VB6.ShowForm(frmTextareaInput, VB6.FormShowConstants.Modal, Me)
                    System.Windows.Forms.Application.DoEvents()
                    Call txtText.Focus()
                    System.Windows.Forms.Application.DoEvents()
                    'Don't select - stops screenreaders reading line, they read the document instead.
                    'Call SelectCurrentParagraph
                End If
            ElseIf StrComp(VB.Left(currentLine, Len(ID_TEXTBOX)), ID_TEXTBOX, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_TEXTBOX) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_TEXTBOX)
                htmlE = textInput(itemNumber)
                inputE = CType(htmlE, mshtml.IHTMLInputElement)
                If mControlKeyPressed Then
                    'User has held down control and hit return, so submit the form.
                    mForceNavigation = True ' 3.7.4
                    Call inputE.form.submit()
                Else
                    newText = InputBox(modFormLabelHandler.GetDescriptiveText(htmlE.id), GetText("Text input"), inputE.value)
                    System.Windows.Forms.Application.DoEvents()
                    Call txtText.Focus()
                    System.Windows.Forms.Application.DoEvents()
                    'TODO differentiate between cancelled text input and blank deliberate text input.
                    If newText <> "" Then
                        Call htmlE.setAttribute("value", newText)
                        lineNumber = GetCurrentLineIndex(txtText)
                        Call RefreshCurrentPage()
                        Call modAPIFunctions.SetCurrentLineIndex(txtText, lineNumber)
                        'Don't select - stops screenreaders reading line, they read the document instead.
                        'Call SelectCurrentParagraph
                    End If
                End If
            ElseIf StrComp(VB.Left(currentLine, Len(modGlobals.ID_OBJECT)), ID_OBJECT, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_OBJECT) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_OBJECT)
                Call DisplayObject(itemNumber)
            ElseIf StrComp(VB.Left(currentLine, Len(modGlobals.ID_FLASHOBJECT)), ID_FLASHOBJECT, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_FLASHOBJECT) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_FLASHOBJECT)
                Call DisplayObject(itemNumber)
            ElseIf StrComp(VB.Left(currentLine, Len(ID_TABLE)), ID_TABLE, CompareMethod.Text) = 0 Then
                'itemNumber = Val(Mid(currentLine, Len(ID_TABLE) + 2, 4))
                itemNumber = GetItemIndex((txtText.Text), (txtText.SelectionStart), ID_TABLE)
                'TODO Add table functions back in.
                'Call frmTable.DisplayTable(tables(itemNumber))
                'Call frmTable.Show(vbModeless, Me)
            End If
            'end of if we press return
        End If
EventExitSub:
        e.KeyChar = Chr(KeyAscii)
        If KeyAscii = 0 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtText_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtText.KeyUp
        Dim KeyCode As Integer = e.KeyCode
        Dim Shift As Integer = e.KeyData \ &H10000
        'check if we can copy and enable button if so

        If mIgnoreNextKeypress Then
            KeyCode = 0
            Exit Sub
        End If
        'mControlKeyPressed = False ' What? Why? What if you've not raised the Control key?
        'Debug.Print "txtText_KeyUp"
        'check for if we have a selected lump of text, in which case we can copy
        '    If txtText.SelLength > 0 Then
        '        mnuEditCopy.Enabled = True
        '    Else
        '        mnuEditCopy.Enabled = False
        '    End If

    End Sub

    Private Sub txtText_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtText.TextChanged

    End Sub

    Private Sub mWebBrowser_CanGoForwardChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles mWebBrowser.CanGoForwardChanged
        cmdForward.Enabled = mWebBrowser.CanGoForward
        cmdBack.Enabled = mWebBrowser.CanGoForward
    End Sub

End Class