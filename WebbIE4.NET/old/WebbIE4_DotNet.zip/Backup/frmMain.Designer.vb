<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmMain
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents mnuFileOpen As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuFileSave As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuFileSaveas As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuFilePrint As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditCut As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditCopy As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditPaste As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditSelectall As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditFindtext As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditFindnext As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditWebsearch As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEdit As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewIE As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewCroppage As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewRSSNewsFeed As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewViewforms As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewLaunchIE As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewLinkinformation As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewMagnify As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewShrink As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewSource As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuViewReadability As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuView As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuBookmarksAddbookmark As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuBookmarksOrganisebookmarks As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuBar7 As System.Windows.Forms.ToolStripSeparator
    Public WithEvents mnuBookmarks As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnuNavigateBack As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuNavigateStop As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuNavigateHome As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuNavigateRefresh As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuNavigateForward As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuNavigateGotoform As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuNavigateGotoheadline As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuNavigate As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuLinksSkiplinks As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuLinksNextlink As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuLinksSkipup As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuLinksPreviouslink As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuLinksViewlinks As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuLinksFollowlinkaddress As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuLinksDownloadlink As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuLinks As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsFetchPDFfromGoogle As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsUsequickkeys As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsAlwaysstartintextview As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuBarIEView As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnuOptionsLanguageoptions As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnuBarLanguageOptions As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnuOptionsSethome As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsUsefavouritesforhomepage As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuBar2 As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnuOptionsAllowPopups As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsAllowmessages As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsAllowajax As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuBar0 As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnuOptionsImages As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsJavascriptonlyitems As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnuOptionsDownloadingimages As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsHideToolbar As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsToolbarcaptions As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsChangefont As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsInvertcolours As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptionsNumberlinksandotheritems As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuBarljkjl As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnuOptionsNavigationsounds As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuBar1 As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnuOptionsMadedefault As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuOptions As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents mnuBar8 As System.Windows.Forms.ToolStripSeparator
	Public WithEvents mnuHelpCheck As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuHelpReport As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuHelpWebbiehome As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuHelpAbout As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuHelp As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents MainMenu1 As System.Windows.Forms.MenuStrip
    Public WithEvents tmrDoUpDownKeys As System.Windows.Forms.Timer
	Public WithEvents tmrRefreshIfNotChange As System.Windows.Forms.Timer
	Public WithEvents cmdShrink As System.Windows.Forms.Button
	Public WithEvents workBrowser As System.Windows.Forms.WebBrowser
    Public WithEvents tmrSetFocus As System.Windows.Forms.Timer
	Public WithEvents tmrProcessAfterLoad As System.Windows.Forms.Timer
	Public WithEvents tmrStartNavigating As System.Windows.Forms.Timer
    Public WithEvents tmrAjax As System.Windows.Forms.Timer
	Public WithEvents _picBusySmall_3 As System.Windows.Forms.PictureBox
	Public WithEvents _picBusySmall_2 As System.Windows.Forms.PictureBox
	Public WithEvents _picBusySmall_1 As System.Windows.Forms.PictureBox
	Public WithEvents _picBusySmall_0 As System.Windows.Forms.PictureBox
	Public WithEvents picBusyDoneSmall As System.Windows.Forms.PictureBox
	Public WithEvents fraBusySmall As System.Windows.Forms.Panel
    Public WithEvents Winsock As AxMSWinsockLib.AxWinsock
    Public cdlgOpen As System.Windows.Forms.OpenFileDialog
	Public WithEvents tmrBusyAnimation As System.Windows.Forms.Timer
	Public WithEvents _staMain_Panel1 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _staMain_Panel2 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents _staMain_Panel3 As System.Windows.Forms.ToolStripStatusLabel
	Public WithEvents staMain As System.Windows.Forms.StatusStrip
	Public WithEvents tmrConnectionPoller As System.Windows.Forms.Timer
    Public WithEvents lblText As System.Windows.Forms.Label
	Public WithEvents mnuHelpContents As Microsoft.VisualBasic.Compatibility.VB6.ToolStripMenuItemArray
	Public WithEvents mnuOptionsDownloadingimagesOptions As Microsoft.VisualBasic.Compatibility.VB6.ToolStripMenuItemArray
	Public WithEvents mnuOptionsLanguageselect As Microsoft.VisualBasic.Compatibility.VB6.ToolStripMenuItemArray
	Public WithEvents mnuSimplebookmarkList As Microsoft.VisualBasic.Compatibility.VB6.ToolStripMenuItemArray
	Public WithEvents picBusyAnimation As Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray
	Public WithEvents picBusySmall As Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cboAddress = New System.Windows.Forms.ComboBox
        Me._picBusyAnimation_1 = New System.Windows.Forms.PictureBox
        Me._picBusyAnimation_3 = New System.Windows.Forms.PictureBox
        Me._picBusyAnimation_0 = New System.Windows.Forms.PictureBox
        Me._picBusyAnimation_2 = New System.Windows.Forms.PictureBox
        Me.MainMenu1 = New System.Windows.Forms.MenuStrip
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuFileOpen = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuFileSaveas = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuFilePrint = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEditCut = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEditCopy = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEditPaste = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEditSelectall = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEditFindtext = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEditFindnext = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuEditWebsearch = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuView = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewIE = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewCroppage = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewRSSNewsFeed = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewViewforms = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewLaunchIE = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewLinkinformation = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewMagnify = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewShrink = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewSource = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuViewReadability = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBookmarks = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBookmarksAddbookmark = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBookmarksOrganisebookmarks = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBar7 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuNavigate = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuNavigateBack = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuNavigateStop = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuNavigateHome = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuNavigateRefresh = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuNavigateForward = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuNavigateGotoform = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuNavigateGotoheadline = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptions = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsFetchPDFfromGoogle = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsUsequickkeys = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsAlwaysstartintextview = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBarIEView = New System.Windows.Forms.ToolStripSeparator
        Me.mnuOptionsLanguageoptions = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBarLanguageOptions = New System.Windows.Forms.ToolStripSeparator
        Me.mnuOptionsSethome = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsUsefavouritesforhomepage = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBar2 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuOptionsAllowPopups = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsAllowmessages = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsAllowajax = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBar0 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuOptionsImages = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsJavascriptonlyitems = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsDownloadingimages = New System.Windows.Forms.ToolStripMenuItem
        Me.TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsHideToolbar = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsToolbarcaptions = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsChangefont = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsInvertcolours = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuOptionsNumberlinksandotheritems = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBarljkjl = New System.Windows.Forms.ToolStripSeparator
        Me.mnuOptionsNavigationsounds = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBar1 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuOptionsMadedefault = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuLinks = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuLinksSkiplinks = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuLinksNextlink = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuLinksSkipup = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuLinksPreviouslink = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuLinksViewlinks = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuLinksFollowlinkaddress = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuLinksDownloadlink = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem
        Me.StartingOutASimpleGuideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.WebbIEMenuCommandsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.WebbIEControlKeysToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TheWebbIEToolbarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HowToUseFormsInWebbIEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuBar8 = New System.Windows.Forms.ToolStripSeparator
        Me.mnuHelpCheck = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuHelpReport = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuHelpWebbiehome = New System.Windows.Forms.ToolStripMenuItem
        Me.mnuHelpAbout = New System.Windows.Forms.ToolStripMenuItem
        Me.tmrDoUpDownKeys = New System.Windows.Forms.Timer(Me.components)
        Me.tmrRefreshIfNotChange = New System.Windows.Forms.Timer(Me.components)
        Me.cmdShrink = New System.Windows.Forms.Button
        Me.workBrowser = New System.Windows.Forms.WebBrowser
        Me.tmrSetFocus = New System.Windows.Forms.Timer(Me.components)
        Me.tmrProcessAfterLoad = New System.Windows.Forms.Timer(Me.components)
        Me.tmrStartNavigating = New System.Windows.Forms.Timer(Me.components)
        Me.tmrAjax = New System.Windows.Forms.Timer(Me.components)
        Me.fraBusySmall = New System.Windows.Forms.Panel
        Me._picBusySmall_3 = New System.Windows.Forms.PictureBox
        Me._picBusySmall_2 = New System.Windows.Forms.PictureBox
        Me._picBusySmall_1 = New System.Windows.Forms.PictureBox
        Me._picBusySmall_0 = New System.Windows.Forms.PictureBox
        Me.picBusyDoneSmall = New System.Windows.Forms.PictureBox
        Me.Winsock = New AxMSWinsockLib.AxWinsock
        Me.cdlgOpen = New System.Windows.Forms.OpenFileDialog
        Me.tmrBusyAnimation = New System.Windows.Forms.Timer(Me.components)
        Me.staMain = New System.Windows.Forms.StatusStrip
        Me._staMain_Panel1 = New System.Windows.Forms.ToolStripStatusLabel
        Me._staMain_Panel2 = New System.Windows.Forms.ToolStripStatusLabel
        Me._staMain_Panel3 = New System.Windows.Forms.ToolStripStatusLabel
        Me.tmrConnectionPoller = New System.Windows.Forms.Timer(Me.components)
        Me.lblText = New System.Windows.Forms.Label
        Me.mnuHelpContents = New Microsoft.VisualBasic.Compatibility.VB6.ToolStripMenuItemArray(Me.components)
        Me.mnuOptionsDownloadingimagesOptions = New Microsoft.VisualBasic.Compatibility.VB6.ToolStripMenuItemArray(Me.components)
        Me.mnuOptionsLanguageselect = New Microsoft.VisualBasic.Compatibility.VB6.ToolStripMenuItemArray(Me.components)
        Me.mnuSimplebookmarkList = New Microsoft.VisualBasic.Compatibility.VB6.ToolStripMenuItemArray(Me.components)
        Me.picBusyAnimation = New Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray(Me.components)
        Me.picBusySmall = New Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray(Me.components)
        Me.NavigationBarPanel = New System.Windows.Forms.Panel
        Me.fraBusy = New System.Windows.Forms.Panel
        Me.picBusyDone = New System.Windows.Forms.PictureBox
        Me.fraToolBar = New System.Windows.Forms.Panel
        Me.cmdHeading = New System.Windows.Forms.Button
        Me.cmdMagnify = New System.Windows.Forms.Button
        Me.cmdSkiplinks = New System.Windows.Forms.Button
        Me.cmdViewIE = New System.Windows.Forms.Button
        Me.cmdHome = New System.Windows.Forms.Button
        Me.cmdRefresh = New System.Windows.Forms.Button
        Me.cmdStop = New System.Windows.Forms.Button
        Me.cmdForward = New System.Windows.Forms.Button
        Me.cmdBack = New System.Windows.Forms.Button
        Me.MainPanel = New System.Windows.Forms.Panel
        Me.PanelText = New System.Windows.Forms.Panel
        Me.mWebBrowser = New System.Windows.Forms.WebBrowser
        Me.txtText = New System.Windows.Forms.TextBox
        Me.AddressPanel = New System.Windows.Forms.Panel
        Me.lblAddress = New System.Windows.Forms.Label
        CType(Me._picBusyAnimation_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._picBusyAnimation_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._picBusyAnimation_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._picBusyAnimation_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MainMenu1.SuspendLayout()
        Me.fraBusySmall.SuspendLayout()
        CType(Me._picBusySmall_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._picBusySmall_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._picBusySmall_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._picBusySmall_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBusyDoneSmall, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Winsock, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.staMain.SuspendLayout()
        CType(Me.mnuHelpContents, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mnuOptionsDownloadingimagesOptions, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mnuOptionsLanguageselect, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.mnuSimplebookmarkList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBusyAnimation, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBusySmall, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NavigationBarPanel.SuspendLayout()
        Me.fraBusy.SuspendLayout()
        CType(Me.picBusyDone, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.fraToolBar.SuspendLayout()
        Me.MainPanel.SuspendLayout()
        Me.PanelText.SuspendLayout()
        Me.AddressPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboAddress
        '
        Me.cboAddress.BackColor = System.Drawing.SystemColors.Window
        Me.cboAddress.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboAddress.Font = New System.Drawing.Font("Arial", 13.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(186, Byte))
        Me.cboAddress.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboAddress.Location = New System.Drawing.Point(72, 10)
        Me.cboAddress.Name = "cboAddress"
        Me.cboAddress.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cboAddress.Size = New System.Drawing.Size(757, 29)
        Me.cboAddress.TabIndex = 2
        Me.cboAddress.Tag = "frmMain.cboAddress"
        Me.ToolTip1.SetToolTip(Me.cboAddress, " Type website address here and press return ")
        '
        '_picBusyAnimation_1
        '
        Me._picBusyAnimation_1.BackColor = System.Drawing.SystemColors.Control
        Me._picBusyAnimation_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._picBusyAnimation_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._picBusyAnimation_1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picBusyAnimation_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._picBusyAnimation_1.Image = CType(resources.GetObject("_picBusyAnimation_1.Image"), System.Drawing.Image)
        Me._picBusyAnimation_1.Location = New System.Drawing.Point(0, 0)
        Me._picBusyAnimation_1.Name = "_picBusyAnimation_1"
        Me._picBusyAnimation_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picBusyAnimation_1.Size = New System.Drawing.Size(85, 85)
        Me._picBusyAnimation_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me._picBusyAnimation_1.TabIndex = 13
        Me._picBusyAnimation_1.TabStop = False
        Me._picBusyAnimation_1.Tag = "frmMain.picBusyAnimation(1)"
        Me.ToolTip1.SetToolTip(Me._picBusyAnimation_1, " If this is changing then WebbIE is busy downloading a page for you. ")
        Me._picBusyAnimation_1.Visible = False
        '
        '_picBusyAnimation_3
        '
        Me._picBusyAnimation_3.BackColor = System.Drawing.SystemColors.Control
        Me._picBusyAnimation_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._picBusyAnimation_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._picBusyAnimation_3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picBusyAnimation_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._picBusyAnimation_3.Image = CType(resources.GetObject("_picBusyAnimation_3.Image"), System.Drawing.Image)
        Me._picBusyAnimation_3.Location = New System.Drawing.Point(0, 0)
        Me._picBusyAnimation_3.Name = "_picBusyAnimation_3"
        Me._picBusyAnimation_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picBusyAnimation_3.Size = New System.Drawing.Size(85, 85)
        Me._picBusyAnimation_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me._picBusyAnimation_3.TabIndex = 15
        Me._picBusyAnimation_3.TabStop = False
        Me._picBusyAnimation_3.Tag = "frmMain.picBusyAnimation(2)"
        Me.ToolTip1.SetToolTip(Me._picBusyAnimation_3, " If this is changing then WebbIE is busy downloading a page for you. ")
        Me._picBusyAnimation_3.Visible = False
        '
        '_picBusyAnimation_0
        '
        Me._picBusyAnimation_0.BackColor = System.Drawing.SystemColors.Control
        Me._picBusyAnimation_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._picBusyAnimation_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._picBusyAnimation_0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picBusyAnimation_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._picBusyAnimation_0.Image = CType(resources.GetObject("_picBusyAnimation_0.Image"), System.Drawing.Image)
        Me._picBusyAnimation_0.Location = New System.Drawing.Point(0, 0)
        Me._picBusyAnimation_0.Name = "_picBusyAnimation_0"
        Me._picBusyAnimation_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picBusyAnimation_0.Size = New System.Drawing.Size(85, 85)
        Me._picBusyAnimation_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me._picBusyAnimation_0.TabIndex = 12
        Me._picBusyAnimation_0.TabStop = False
        Me._picBusyAnimation_0.Tag = "frmMain.picBusyAnimation(0)"
        Me.ToolTip1.SetToolTip(Me._picBusyAnimation_0, " If this is changing then WebbIE is busy downloading a page for you. ")
        '
        '_picBusyAnimation_2
        '
        Me._picBusyAnimation_2.BackColor = System.Drawing.SystemColors.Control
        Me._picBusyAnimation_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._picBusyAnimation_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._picBusyAnimation_2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._picBusyAnimation_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._picBusyAnimation_2.Image = CType(resources.GetObject("_picBusyAnimation_2.Image"), System.Drawing.Image)
        Me._picBusyAnimation_2.Location = New System.Drawing.Point(0, 32)
        Me._picBusyAnimation_2.Name = "_picBusyAnimation_2"
        Me._picBusyAnimation_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picBusyAnimation_2.Size = New System.Drawing.Size(85, 85)
        Me._picBusyAnimation_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me._picBusyAnimation_2.TabIndex = 14
        Me._picBusyAnimation_2.TabStop = False
        Me._picBusyAnimation_2.Tag = "frmMain.picBusyAnimation(2)"
        Me.ToolTip1.SetToolTip(Me._picBusyAnimation_2, " If this is changing then WebbIE is busy downloading a page for you. ")
        Me._picBusyAnimation_2.Visible = False
        '
        'MainMenu1
        '
        Me.MainMenu1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.mnuView, Me.mnuBookmarks, Me.mnuNavigate, Me.mnuOptions, Me.mnuLinks, Me.mnuHelp})
        Me.MainMenu1.Location = New System.Drawing.Point(0, 0)
        Me.MainMenu1.Name = "MainMenu1"
        Me.MainMenu1.Size = New System.Drawing.Size(880, 24)
        Me.MainMenu1.TabIndex = 32
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileOpen, Me.mnuFileSave, Me.mnuFileSaveas, Me.mnuFilePrint, Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Tag = "frmMain.mnuFile"
        Me.mnuFile.Text = "&File"
        '
        'mnuFileOpen
        '
        Me.mnuFileOpen.Name = "mnuFileOpen"
        Me.mnuFileOpen.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mnuFileOpen.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileOpen.Tag = "frmMain.mnuFileOpen"
        Me.mnuFileOpen.Text = "&Open"
        '
        'mnuFileSave
        '
        Me.mnuFileSave.Enabled = False
        Me.mnuFileSave.Name = "mnuFileSave"
        Me.mnuFileSave.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileSave.Tag = "frmMain.mnuFileSave"
        Me.mnuFileSave.Text = "&Save"
        '
        'mnuFileSaveas
        '
        Me.mnuFileSaveas.Enabled = False
        Me.mnuFileSaveas.Name = "mnuFileSaveas"
        Me.mnuFileSaveas.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileSaveas.Tag = "frmMain.mnuFileSaveas"
        Me.mnuFileSaveas.Text = "Save &As..."
        '
        'mnuFilePrint
        '
        Me.mnuFilePrint.Enabled = False
        Me.mnuFilePrint.Name = "mnuFilePrint"
        Me.mnuFilePrint.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.mnuFilePrint.Size = New System.Drawing.Size(146, 22)
        Me.mnuFilePrint.Tag = "frmMain.mnuFilePrint"
        Me.mnuFilePrint.Text = "&Print"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(146, 22)
        Me.mnuFileExit.Tag = "frmMain.mnuFileExit"
        Me.mnuFileExit.Text = "E&xit"
        '
        'mnuEdit
        '
        Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuEditCut, Me.mnuEditCopy, Me.mnuEditPaste, Me.mnuEditSelectall, Me.mnuEditFindtext, Me.mnuEditFindnext, Me.mnuEditWebsearch})
        Me.mnuEdit.Name = "mnuEdit"
        Me.mnuEdit.Size = New System.Drawing.Size(39, 20)
        Me.mnuEdit.Tag = "frmMain.mnuEdit"
        Me.mnuEdit.Text = "&Edit"
        '
        'mnuEditCut
        '
        Me.mnuEditCut.Name = "mnuEditCut"
        Me.mnuEditCut.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.mnuEditCut.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditCut.Tag = "frmMain.mnuEditCut"
        Me.mnuEditCut.Text = "Cu&t"
        '
        'mnuEditCopy
        '
        Me.mnuEditCopy.Name = "mnuEditCopy"
        Me.mnuEditCopy.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.mnuEditCopy.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditCopy.Tag = "frmMain.mnuEditCopy"
        Me.mnuEditCopy.Text = "&Copy"
        '
        'mnuEditPaste
        '
        Me.mnuEditPaste.Name = "mnuEditPaste"
        Me.mnuEditPaste.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.mnuEditPaste.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditPaste.Tag = "frmMain.mnuEditPaste"
        Me.mnuEditPaste.Text = "&Paste"
        '
        'mnuEditSelectall
        '
        Me.mnuEditSelectall.Name = "mnuEditSelectall"
        Me.mnuEditSelectall.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.mnuEditSelectall.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditSelectall.Tag = "frmMain.mnuEditSelectall"
        Me.mnuEditSelectall.Text = "Select &All"
        '
        'mnuEditFindtext
        '
        Me.mnuEditFindtext.Name = "mnuEditFindtext"
        Me.mnuEditFindtext.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.mnuEditFindtext.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditFindtext.Tag = "frmMain.mnuEditFindtext"
        Me.mnuEditFindtext.Text = "&Find (on this page)"
        '
        'mnuEditFindnext
        '
        Me.mnuEditFindnext.Name = "mnuEditFindnext"
        Me.mnuEditFindnext.ShortcutKeys = System.Windows.Forms.Keys.F3
        Me.mnuEditFindnext.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditFindnext.Tag = "frmMain.mnuEditFindnext"
        Me.mnuEditFindnext.Text = "Find &Next"
        '
        'mnuEditWebsearch
        '
        Me.mnuEditWebsearch.Name = "mnuEditWebsearch"
        Me.mnuEditWebsearch.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.W), System.Windows.Forms.Keys)
        Me.mnuEditWebsearch.Size = New System.Drawing.Size(213, 22)
        Me.mnuEditWebsearch.Tag = "frmMain.mnuEditWebsearch"
        Me.mnuEditWebsearch.Text = "&Websearch"
        '
        'mnuView
        '
        Me.mnuView.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuViewIE, Me.mnuViewCroppage, Me.mnuViewRSSNewsFeed, Me.mnuViewViewforms, Me.mnuViewLaunchIE, Me.mnuViewLinkinformation, Me.mnuViewMagnify, Me.mnuViewShrink, Me.mnuViewSource, Me.mnuViewReadability})
        Me.mnuView.Name = "mnuView"
        Me.mnuView.Size = New System.Drawing.Size(44, 20)
        Me.mnuView.Tag = "frmMain.mnuView"
        Me.mnuView.Text = "&View"
        '
        'mnuViewIE
        '
        Me.mnuViewIE.Name = "mnuViewIE"
        Me.mnuViewIE.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.I), System.Windows.Forms.Keys)
        Me.mnuViewIE.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewIE.Tag = "frmMain.mnuViewIE"
        Me.mnuViewIE.Text = "View &webpage"
        '
        'mnuViewCroppage
        '
        Me.mnuViewCroppage.Name = "mnuViewCroppage"
        Me.mnuViewCroppage.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.K), System.Windows.Forms.Keys)
        Me.mnuViewCroppage.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewCroppage.Tag = "frmMain.mnuViewCroppage"
        Me.mnuViewCroppage.Text = "&Crop page"
        '
        'mnuViewRSSNewsFeed
        '
        Me.mnuViewRSSNewsFeed.Name = "mnuViewRSSNewsFeed"
        Me.mnuViewRSSNewsFeed.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.mnuViewRSSNewsFeed.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewRSSNewsFeed.Text = "View &RSS News Feed"
        '
        'mnuViewViewforms
        '
        Me.mnuViewViewforms.Enabled = False
        Me.mnuViewViewforms.Name = "mnuViewViewforms"
        Me.mnuViewViewforms.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.mnuViewViewforms.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewViewforms.Text = "View &Forms"
        '
        'mnuViewLaunchIE
        '
        Me.mnuViewLaunchIE.Name = "mnuViewLaunchIE"
        Me.mnuViewLaunchIE.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewLaunchIE.Tag = "frmMain.mnuViewLaunchIE"
        Me.mnuViewLaunchIE.Text = "&Launch IE"
        '
        'mnuViewLinkinformation
        '
        Me.mnuViewLinkinformation.Name = "mnuViewLinkinformation"
        Me.mnuViewLinkinformation.ShortcutKeys = System.Windows.Forms.Keys.F8
        Me.mnuViewLinkinformation.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewLinkinformation.Text = "&Link information"
        '
        'mnuViewMagnify
        '
        Me.mnuViewMagnify.Name = "mnuViewMagnify"
        Me.mnuViewMagnify.ShortcutKeys = System.Windows.Forms.Keys.F11
        Me.mnuViewMagnify.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewMagnify.Text = "&Magnify"
        '
        'mnuViewShrink
        '
        Me.mnuViewShrink.Name = "mnuViewShrink"
        Me.mnuViewShrink.ShortcutKeys = System.Windows.Forms.Keys.F12
        Me.mnuViewShrink.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewShrink.Text = "&Shrink"
        '
        'mnuViewSource
        '
        Me.mnuViewSource.Name = "mnuViewSource"
        Me.mnuViewSource.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewSource.Tag = "frmMain.mnuViewSource"
        Me.mnuViewSource.Text = "Sour&ce"
        '
        'mnuViewReadability
        '
        Me.mnuViewReadability.Name = "mnuViewReadability"
        Me.mnuViewReadability.Size = New System.Drawing.Size(221, 22)
        Me.mnuViewReadability.Text = "Readability"
        Me.mnuViewReadability.Visible = False
        '
        'mnuBookmarks
        '
        Me.mnuBookmarks.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuBookmarksAddbookmark, Me.mnuBookmarksOrganisebookmarks, Me.mnuBar7})
        Me.mnuBookmarks.Name = "mnuBookmarks"
        Me.mnuBookmarks.Size = New System.Drawing.Size(66, 20)
        Me.mnuBookmarks.Tag = "frmMain.mnuBookmarks"
        Me.mnuBookmarks.Text = "F&avorites"
        '
        'mnuBookmarksAddbookmark
        '
        Me.mnuBookmarksAddbookmark.Name = "mnuBookmarksAddbookmark"
        Me.mnuBookmarksAddbookmark.Size = New System.Drawing.Size(171, 22)
        Me.mnuBookmarksAddbookmark.Tag = "frmMain.mnuBookmarksAddbookmark"
        Me.mnuBookmarksAddbookmark.Text = "&Add Favorite"
        '
        'mnuBookmarksOrganisebookmarks
        '
        Me.mnuBookmarksOrganisebookmarks.Enabled = False
        Me.mnuBookmarksOrganisebookmarks.Name = "mnuBookmarksOrganisebookmarks"
        Me.mnuBookmarksOrganisebookmarks.Size = New System.Drawing.Size(171, 22)
        Me.mnuBookmarksOrganisebookmarks.Tag = "frmMain.mnuBookmarksOrganisebookmarks"
        Me.mnuBookmarksOrganisebookmarks.Text = "&Organise Favorites"
        '
        'mnuBar7
        '
        Me.mnuBar7.Name = "mnuBar7"
        Me.mnuBar7.Size = New System.Drawing.Size(168, 6)
        '
        'mnuNavigate
        '
        Me.mnuNavigate.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuNavigateBack, Me.mnuNavigateStop, Me.mnuNavigateHome, Me.mnuNavigateRefresh, Me.mnuNavigateForward, Me.mnuNavigateGotoform, Me.mnuNavigateGotoheadline})
        Me.mnuNavigate.Name = "mnuNavigate"
        Me.mnuNavigate.Size = New System.Drawing.Size(66, 20)
        Me.mnuNavigate.Tag = "frmMain.mnuNavigate"
        Me.mnuNavigate.Text = "&Navigate"
        '
        'mnuNavigateBack
        '
        Me.mnuNavigateBack.Name = "mnuNavigateBack"
        Me.mnuNavigateBack.Size = New System.Drawing.Size(322, 22)
        Me.mnuNavigateBack.Tag = "frmMain.mnuNavigateBack"
        Me.mnuNavigateBack.Text = "&Back                                                     Alt + Left"
        '
        'mnuNavigateStop
        '
        Me.mnuNavigateStop.Name = "mnuNavigateStop"
        Me.mnuNavigateStop.Size = New System.Drawing.Size(322, 22)
        Me.mnuNavigateStop.Tag = "frmMain.mnuNavigateStop"
        Me.mnuNavigateStop.Text = "&Stop                                                    Esc"
        '
        'mnuNavigateHome
        '
        Me.mnuNavigateHome.Name = "mnuNavigateHome"
        Me.mnuNavigateHome.Size = New System.Drawing.Size(322, 22)
        Me.mnuNavigateHome.Tag = "frmMain.mnuNavigateHome"
        Me.mnuNavigateHome.Text = "&Home                                                   Alt + Home"
        '
        'mnuNavigateRefresh
        '
        Me.mnuNavigateRefresh.Name = "mnuNavigateRefresh"
        Me.mnuNavigateRefresh.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.mnuNavigateRefresh.Size = New System.Drawing.Size(322, 22)
        Me.mnuNavigateRefresh.Tag = "frmMain.mnuNavigateRefresh"
        Me.mnuNavigateRefresh.Text = "&Refresh"
        '
        'mnuNavigateForward
        '
        Me.mnuNavigateForward.Name = "mnuNavigateForward"
        Me.mnuNavigateForward.Size = New System.Drawing.Size(322, 22)
        Me.mnuNavigateForward.Tag = "frmMain.mnuNavigateForward"
        Me.mnuNavigateForward.Text = "&Forward                                               Alt + Right"
        '
        'mnuNavigateGotoform
        '
        Me.mnuNavigateGotoform.Name = "mnuNavigateGotoform"
        Me.mnuNavigateGotoform.ShortcutKeys = System.Windows.Forms.Keys.F6
        Me.mnuNavigateGotoform.Size = New System.Drawing.Size(322, 22)
        Me.mnuNavigateGotoform.Tag = "frmMain.mnuNavigateGotoform"
        Me.mnuNavigateGotoform.Text = "Goto &Form"
        '
        'mnuNavigateGotoheadline
        '
        Me.mnuNavigateGotoheadline.Name = "mnuNavigateGotoheadline"
        Me.mnuNavigateGotoheadline.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.H), System.Windows.Forms.Keys)
        Me.mnuNavigateGotoheadline.Size = New System.Drawing.Size(322, 22)
        Me.mnuNavigateGotoheadline.Tag = "frmMain.mnuNavigateGotoheadline"
        Me.mnuNavigateGotoheadline.Text = "Goto &Headline"
        '
        'mnuOptions
        '
        Me.mnuOptions.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuOptionsFetchPDFfromGoogle, Me.mnuOptionsUsequickkeys, Me.mnuOptionsAlwaysstartintextview, Me.mnuBarIEView, Me.mnuOptionsLanguageoptions, Me.mnuBarLanguageOptions, Me.mnuOptionsSethome, Me.mnuOptionsUsefavouritesforhomepage, Me.mnuBar2, Me.mnuOptionsAllowPopups, Me.mnuOptionsAllowmessages, Me.mnuOptionsAllowajax, Me.mnuBar0, Me.mnuOptionsImages, Me.mnuOptionsJavascriptonlyitems, Me.mnuOptionsDownloadingimages, Me.mnuOptionsHideToolbar, Me.mnuOptionsToolbarcaptions, Me.mnuOptionsChangefont, Me.mnuOptionsInvertcolours, Me.mnuOptionsNumberlinksandotheritems, Me.mnuBarljkjl, Me.mnuOptionsNavigationsounds, Me.mnuBar1, Me.mnuOptionsMadedefault})
        Me.mnuOptions.Name = "mnuOptions"
        Me.mnuOptions.Size = New System.Drawing.Size(61, 20)
        Me.mnuOptions.Tag = "frmMain.mnuOptions"
        Me.mnuOptions.Text = "&Options"
        '
        'mnuOptionsFetchPDFfromGoogle
        '
        Me.mnuOptionsFetchPDFfromGoogle.Checked = True
        Me.mnuOptionsFetchPDFfromGoogle.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuOptionsFetchPDFfromGoogle.Name = "mnuOptionsFetchPDFfromGoogle"
        Me.mnuOptionsFetchPDFfromGoogle.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsFetchPDFfromGoogle.Tag = "frmMain.mnuOptionsFetchPDFfromGoogle"
        Me.mnuOptionsFetchPDFfromGoogle.Text = "&Fetch PDF files from Google"
        '
        'mnuOptionsUsequickkeys
        '
        Me.mnuOptionsUsequickkeys.Name = "mnuOptionsUsequickkeys"
        Me.mnuOptionsUsequickkeys.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsUsequickkeys.Text = "Use &Quick keys"
        '
        'mnuOptionsAlwaysstartintextview
        '
        Me.mnuOptionsAlwaysstartintextview.Checked = True
        Me.mnuOptionsAlwaysstartintextview.CheckState = System.Windows.Forms.CheckState.Checked
        Me.mnuOptionsAlwaysstartintextview.Name = "mnuOptionsAlwaysstartintextview"
        Me.mnuOptionsAlwaysstartintextview.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsAlwaysstartintextview.Text = "&Always start in text view"
        '
        'mnuBarIEView
        '
        Me.mnuBarIEView.Name = "mnuBarIEView"
        Me.mnuBarIEView.Size = New System.Drawing.Size(273, 6)
        '
        'mnuOptionsLanguageoptions
        '
        Me.mnuOptionsLanguageoptions.Name = "mnuOptionsLanguageoptions"
        Me.mnuOptionsLanguageoptions.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsLanguageoptions.Tag = "frmMain.mnuOptionsLanguageoptions"
        Me.mnuOptionsLanguageoptions.Text = "&Language options..."
        '
        'mnuBarLanguageOptions
        '
        Me.mnuBarLanguageOptions.Name = "mnuBarLanguageOptions"
        Me.mnuBarLanguageOptions.Size = New System.Drawing.Size(273, 6)
        '
        'mnuOptionsSethome
        '
        Me.mnuOptionsSethome.Name = "mnuOptionsSethome"
        Me.mnuOptionsSethome.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsSethome.Tag = "frmMain.mnuOptionsSethome"
        Me.mnuOptionsSethome.Text = "Set &Home Page"
        '
        'mnuOptionsUsefavouritesforhomepage
        '
        Me.mnuOptionsUsefavouritesforhomepage.Name = "mnuOptionsUsefavouritesforhomepage"
        Me.mnuOptionsUsefavouritesforhomepage.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsUsefavouritesforhomepage.Text = "Use &Favourites for Home Page"
        '
        'mnuBar2
        '
        Me.mnuBar2.Name = "mnuBar2"
        Me.mnuBar2.Size = New System.Drawing.Size(273, 6)
        '
        'mnuOptionsAllowPopups
        '
        Me.mnuOptionsAllowPopups.Name = "mnuOptionsAllowPopups"
        Me.mnuOptionsAllowPopups.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsAllowPopups.Tag = "frmMain.mnuOptionsAllowpopups"
        Me.mnuOptionsAllowPopups.Text = "Allo&w Popup Windows"
        '
        'mnuOptionsAllowmessages
        '
        Me.mnuOptionsAllowmessages.Name = "mnuOptionsAllowmessages"
        Me.mnuOptionsAllowmessages.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsAllowmessages.Tag = "frmMain.mnuOptionsAllowmessages"
        Me.mnuOptionsAllowmessages.Text = "Allow Me&ssages"
        '
        'mnuOptionsAllowajax
        '
        Me.mnuOptionsAllowajax.Name = "mnuOptionsAllowajax"
        Me.mnuOptionsAllowajax.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsAllowajax.Text = "Allow A&jax"
        Me.mnuOptionsAllowajax.Visible = False
        '
        'mnuBar0
        '
        Me.mnuBar0.Name = "mnuBar0"
        Me.mnuBar0.Size = New System.Drawing.Size(273, 6)
        '
        'mnuOptionsImages
        '
        Me.mnuOptionsImages.Name = "mnuOptionsImages"
        Me.mnuOptionsImages.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsImages.Tag = "frmMain.mnuOptionsImages"
        Me.mnuOptionsImages.Text = "&Images"
        '
        'mnuOptionsJavascriptonlyitems
        '
        Me.mnuOptionsJavascriptonlyitems.Name = "mnuOptionsJavascriptonlyitems"
        Me.mnuOptionsJavascriptonlyitems.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsJavascriptonlyitems.Text = "Javascript-only Items"
        '
        'mnuOptionsDownloadingimages
        '
        Me.mnuOptionsDownloadingimages.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem, Me.TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem})
        Me.mnuOptionsDownloadingimages.Name = "mnuOptionsDownloadingimages"
        Me.mnuOptionsDownloadingimages.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsDownloadingimages.Tag = "frmMain.mnuOptionsDownloadingimages"
        Me.mnuOptionsDownloadingimages.Text = "Downloading Images"
        '
        'TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem
        '
        Me.TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Name = "TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem"
        Me.TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Size = New System.Drawing.Size(341, 22)
        Me.TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Text = "Turn off all images in WebbIE and Internet Explorer"
        '
        'TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem
        '
        Me.TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Name = "TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem"
        Me.TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Size = New System.Drawing.Size(341, 22)
        Me.TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem.Text = "Turn on all images in WebbIE and Internet Explorer"
        '
        'mnuOptionsHideToolbar
        '
        Me.mnuOptionsHideToolbar.Name = "mnuOptionsHideToolbar"
        Me.mnuOptionsHideToolbar.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsHideToolbar.Tag = "frmMain.mnuOptionsHidetoolbar"
        Me.mnuOptionsHideToolbar.Text = "Hide &Toolbar"
        '
        'mnuOptionsToolbarcaptions
        '
        Me.mnuOptionsToolbarcaptions.Name = "mnuOptionsToolbarcaptions"
        Me.mnuOptionsToolbarcaptions.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsToolbarcaptions.Text = "Toolbar &Captions"
        '
        'mnuOptionsChangefont
        '
        Me.mnuOptionsChangefont.Name = "mnuOptionsChangefont"
        Me.mnuOptionsChangefont.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsChangefont.Tag = "frmMain.mnuOptionsChangefont"
        Me.mnuOptionsChangefont.Text = "Change &Font"
        '
        'mnuOptionsInvertcolours
        '
        Me.mnuOptionsInvertcolours.Name = "mnuOptionsInvertcolours"
        Me.mnuOptionsInvertcolours.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsInvertcolours.Text = "In&vert Colours"
        '
        'mnuOptionsNumberlinksandotheritems
        '
        Me.mnuOptionsNumberlinksandotheritems.Name = "mnuOptionsNumberlinksandotheritems"
        Me.mnuOptionsNumberlinksandotheritems.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsNumberlinksandotheritems.Text = "&Number links and other items"
        '
        'mnuBarljkjl
        '
        Me.mnuBarljkjl.Name = "mnuBarljkjl"
        Me.mnuBarljkjl.Size = New System.Drawing.Size(273, 6)
        '
        'mnuOptionsNavigationsounds
        '
        Me.mnuOptionsNavigationsounds.Name = "mnuOptionsNavigationsounds"
        Me.mnuOptionsNavigationsounds.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsNavigationsounds.Text = "Navigation Sounds"
        '
        'mnuBar1
        '
        Me.mnuBar1.Name = "mnuBar1"
        Me.mnuBar1.Size = New System.Drawing.Size(273, 6)
        '
        'mnuOptionsMadedefault
        '
        Me.mnuOptionsMadedefault.Name = "mnuOptionsMadedefault"
        Me.mnuOptionsMadedefault.Size = New System.Drawing.Size(276, 22)
        Me.mnuOptionsMadedefault.Text = "&Make WebbIE the default web browser"
        '
        'mnuLinks
        '
        Me.mnuLinks.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuLinksSkiplinks, Me.mnuLinksNextlink, Me.mnuLinksSkipup, Me.mnuLinksPreviouslink, Me.mnuLinksViewlinks, Me.mnuLinksFollowlinkaddress, Me.mnuLinksDownloadlink})
        Me.mnuLinks.Name = "mnuLinks"
        Me.mnuLinks.Size = New System.Drawing.Size(46, 20)
        Me.mnuLinks.Tag = "frmMain.mnuLinks"
        Me.mnuLinks.Text = "&Links"
        '
        'mnuLinksSkiplinks
        '
        Me.mnuLinksSkiplinks.Name = "mnuLinksSkiplinks"
        Me.mnuLinksSkiplinks.Size = New System.Drawing.Size(350, 22)
        Me.mnuLinksSkiplinks.Tag = "frmMain.mnuLinksSkiplinks"
        Me.mnuLinksSkiplinks.Text = "&Skip Links Down                                            Ctrl+Down"
        '
        'mnuLinksNextlink
        '
        Me.mnuLinksNextlink.Name = "mnuLinksNextlink"
        Me.mnuLinksNextlink.Size = New System.Drawing.Size(350, 22)
        Me.mnuLinksNextlink.Tag = "frmMain.mnuLinksNextlink"
        Me.mnuLinksNextlink.Text = "&Next Link                                            Ctrl+Tab"
        '
        'mnuLinksSkipup
        '
        Me.mnuLinksSkipup.Name = "mnuLinksSkipup"
        Me.mnuLinksSkipup.Size = New System.Drawing.Size(350, 22)
        Me.mnuLinksSkipup.Tag = "frmMain.mnuLinksSkipup"
        Me.mnuLinksSkipup.Text = "Skip Links &Up       Ctrl+Up"
        '
        'mnuLinksPreviouslink
        '
        Me.mnuLinksPreviouslink.Name = "mnuLinksPreviouslink"
        Me.mnuLinksPreviouslink.Size = New System.Drawing.Size(350, 22)
        Me.mnuLinksPreviouslink.Tag = "frmMain.mnuLinksPreviouslink"
        Me.mnuLinksPreviouslink.Text = "&Previous Link"
        '
        'mnuLinksViewlinks
        '
        Me.mnuLinksViewlinks.Name = "mnuLinksViewlinks"
        Me.mnuLinksViewlinks.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.L), System.Windows.Forms.Keys)
        Me.mnuLinksViewlinks.Size = New System.Drawing.Size(350, 22)
        Me.mnuLinksViewlinks.Tag = "frmMain.mnuLinksViewlinks"
        Me.mnuLinksViewlinks.Text = "&View Links"
        '
        'mnuLinksFollowlinkaddress
        '
        Me.mnuLinksFollowlinkaddress.Name = "mnuLinksFollowlinkaddress"
        Me.mnuLinksFollowlinkaddress.Size = New System.Drawing.Size(350, 22)
        Me.mnuLinksFollowlinkaddress.Text = "&Follow link address (not click)"
        '
        'mnuLinksDownloadlink
        '
        Me.mnuLinksDownloadlink.Name = "mnuLinksDownloadlink"
        Me.mnuLinksDownloadlink.Size = New System.Drawing.Size(350, 22)
        Me.mnuLinksDownloadlink.Text = "&Download link to Desktop"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StartingOutASimpleGuideToolStripMenuItem, Me.WebbIEMenuCommandsToolStripMenuItem, Me.WebbIEControlKeysToolStripMenuItem, Me.TheWebbIEToolbarToolStripMenuItem, Me.HowToUseFormsInWebbIEToolStripMenuItem, Me.mnuBar8, Me.mnuHelpCheck, Me.mnuHelpReport, Me.mnuHelpWebbiehome, Me.mnuHelpAbout})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mnuHelp.Tag = "frmMain.mnuHelp"
        Me.mnuHelp.Text = "&Help"
        '
        'StartingOutASimpleGuideToolStripMenuItem
        '
        Me.StartingOutASimpleGuideToolStripMenuItem.Name = "StartingOutASimpleGuideToolStripMenuItem"
        Me.StartingOutASimpleGuideToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.StartingOutASimpleGuideToolStripMenuItem.Text = "Starting out - a simple guide"
        '
        'WebbIEMenuCommandsToolStripMenuItem
        '
        Me.WebbIEMenuCommandsToolStripMenuItem.Name = "WebbIEMenuCommandsToolStripMenuItem"
        Me.WebbIEMenuCommandsToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.WebbIEMenuCommandsToolStripMenuItem.Text = "WebbIE menu commands"
        '
        'WebbIEControlKeysToolStripMenuItem
        '
        Me.WebbIEControlKeysToolStripMenuItem.Name = "WebbIEControlKeysToolStripMenuItem"
        Me.WebbIEControlKeysToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.WebbIEControlKeysToolStripMenuItem.Text = "WebbIE control keys"
        '
        'TheWebbIEToolbarToolStripMenuItem
        '
        Me.TheWebbIEToolbarToolStripMenuItem.Name = "TheWebbIEToolbarToolStripMenuItem"
        Me.TheWebbIEToolbarToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.TheWebbIEToolbarToolStripMenuItem.Text = "The WebbIE toolbar"
        '
        'HowToUseFormsInWebbIEToolStripMenuItem
        '
        Me.HowToUseFormsInWebbIEToolStripMenuItem.Name = "HowToUseFormsInWebbIEToolStripMenuItem"
        Me.HowToUseFormsInWebbIEToolStripMenuItem.Size = New System.Drawing.Size(242, 22)
        Me.HowToUseFormsInWebbIEToolStripMenuItem.Text = "How to use forms in WebbIE"
        '
        'mnuBar8
        '
        Me.mnuBar8.Name = "mnuBar8"
        Me.mnuBar8.Size = New System.Drawing.Size(239, 6)
        '
        'mnuHelpCheck
        '
        Me.mnuHelpCheck.Name = "mnuHelpCheck"
        Me.mnuHelpCheck.Size = New System.Drawing.Size(242, 22)
        Me.mnuHelpCheck.Tag = "frmMain.mnuHelpCheck"
        Me.mnuHelpCheck.Text = "&Check for updates"
        Me.mnuHelpCheck.Visible = False
        '
        'mnuHelpReport
        '
        Me.mnuHelpReport.Name = "mnuHelpReport"
        Me.mnuHelpReport.Size = New System.Drawing.Size(242, 22)
        Me.mnuHelpReport.Tag = "frmMain.mnuHelpReport"
        Me.mnuHelpReport.Text = "&Report an inaccessible webpage"
        Me.mnuHelpReport.Visible = False
        '
        'mnuHelpWebbiehome
        '
        Me.mnuHelpWebbiehome.Name = "mnuHelpWebbiehome"
        Me.mnuHelpWebbiehome.Size = New System.Drawing.Size(242, 22)
        Me.mnuHelpWebbiehome.Tag = "frmMain.mnuHelpWebbiehome"
        Me.mnuHelpWebbiehome.Text = "www.webbie.org.uk"
        '
        'mnuHelpAbout
        '
        Me.mnuHelpAbout.Name = "mnuHelpAbout"
        Me.mnuHelpAbout.Size = New System.Drawing.Size(242, 22)
        Me.mnuHelpAbout.Tag = "frmMain.mnuHelpAbout"
        Me.mnuHelpAbout.Text = "&About WebbIE"
        '
        'tmrDoUpDownKeys
        '
        Me.tmrDoUpDownKeys.Interval = 51
        '
        'tmrRefreshIfNotChange
        '
        Me.tmrRefreshIfNotChange.Interval = 2000
        '
        'cmdShrink
        '
        Me.cmdShrink.BackColor = System.Drawing.SystemColors.Control
        Me.cmdShrink.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdShrink.Enabled = False
        Me.cmdShrink.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdShrink.Image = CType(resources.GetObject("cmdShrink.Image"), System.Drawing.Image)
        Me.cmdShrink.Location = New System.Drawing.Point(688, 24)
        Me.cmdShrink.Name = "cmdShrink"
        Me.cmdShrink.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdShrink.Size = New System.Drawing.Size(97, 81)
        Me.cmdShrink.TabIndex = 28
        Me.cmdShrink.TabStop = False
        Me.cmdShrink.Tag = "frmMain.cmdMagnify"
        Me.cmdShrink.Text = "Shrink"
        Me.cmdShrink.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdShrink.UseVisualStyleBackColor = False
        '
        'workBrowser
        '
        Me.workBrowser.Location = New System.Drawing.Point(232, 216)
        Me.workBrowser.Name = "workBrowser"
        Me.workBrowser.Size = New System.Drawing.Size(297, 153)
        Me.workBrowser.TabIndex = 27
        '
        'tmrSetFocus
        '
        Me.tmrSetFocus.Interval = 50
        '
        'tmrProcessAfterLoad
        '
        Me.tmrProcessAfterLoad.Interval = 250
        '
        'tmrStartNavigating
        '
        Me.tmrStartNavigating.Interval = 55
        '
        'tmrAjax
        '
        Me.tmrAjax.Enabled = True
        Me.tmrAjax.Interval = 3000
        '
        'fraBusySmall
        '
        Me.fraBusySmall.BackColor = System.Drawing.SystemColors.Control
        Me.fraBusySmall.Controls.Add(Me._picBusySmall_3)
        Me.fraBusySmall.Controls.Add(Me._picBusySmall_2)
        Me.fraBusySmall.Controls.Add(Me._picBusySmall_1)
        Me.fraBusySmall.Controls.Add(Me._picBusySmall_0)
        Me.fraBusySmall.Controls.Add(Me.picBusyDoneSmall)
        Me.fraBusySmall.Cursor = System.Windows.Forms.Cursors.Default
        Me.fraBusySmall.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraBusySmall.Location = New System.Drawing.Point(600, 296)
        Me.fraBusySmall.Name = "fraBusySmall"
        Me.fraBusySmall.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraBusySmall.Size = New System.Drawing.Size(73, 41)
        Me.fraBusySmall.TabIndex = 18
        '
        '_picBusySmall_3
        '
        Me._picBusySmall_3.BackColor = System.Drawing.SystemColors.Control
        Me._picBusySmall_3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._picBusySmall_3.Cursor = System.Windows.Forms.Cursors.Default
        Me._picBusySmall_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me._picBusySmall_3.Image = CType(resources.GetObject("_picBusySmall_3.Image"), System.Drawing.Image)
        Me.picBusySmall.SetIndex(Me._picBusySmall_3, CType(3, Short))
        Me._picBusySmall_3.Location = New System.Drawing.Point(-40, 8)
        Me._picBusySmall_3.Name = "_picBusySmall_3"
        Me._picBusySmall_3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picBusySmall_3.Size = New System.Drawing.Size(69, 69)
        Me._picBusySmall_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me._picBusySmall_3.TabIndex = 22
        Me._picBusySmall_3.TabStop = False
        '
        '_picBusySmall_2
        '
        Me._picBusySmall_2.BackColor = System.Drawing.SystemColors.Control
        Me._picBusySmall_2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._picBusySmall_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._picBusySmall_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me._picBusySmall_2.Image = CType(resources.GetObject("_picBusySmall_2.Image"), System.Drawing.Image)
        Me.picBusySmall.SetIndex(Me._picBusySmall_2, CType(2, Short))
        Me._picBusySmall_2.Location = New System.Drawing.Point(64, 32)
        Me._picBusySmall_2.Name = "_picBusySmall_2"
        Me._picBusySmall_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picBusySmall_2.Size = New System.Drawing.Size(69, 69)
        Me._picBusySmall_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me._picBusySmall_2.TabIndex = 21
        Me._picBusySmall_2.TabStop = False
        '
        '_picBusySmall_1
        '
        Me._picBusySmall_1.BackColor = System.Drawing.SystemColors.Control
        Me._picBusySmall_1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._picBusySmall_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._picBusySmall_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._picBusySmall_1.Image = CType(resources.GetObject("_picBusySmall_1.Image"), System.Drawing.Image)
        Me.picBusySmall.SetIndex(Me._picBusySmall_1, CType(1, Short))
        Me._picBusySmall_1.Location = New System.Drawing.Point(-32, 0)
        Me._picBusySmall_1.Name = "_picBusySmall_1"
        Me._picBusySmall_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picBusySmall_1.Size = New System.Drawing.Size(69, 69)
        Me._picBusySmall_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me._picBusySmall_1.TabIndex = 20
        Me._picBusySmall_1.TabStop = False
        '
        '_picBusySmall_0
        '
        Me._picBusySmall_0.BackColor = System.Drawing.SystemColors.Control
        Me._picBusySmall_0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me._picBusySmall_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._picBusySmall_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._picBusySmall_0.Image = CType(resources.GetObject("_picBusySmall_0.Image"), System.Drawing.Image)
        Me.picBusySmall.SetIndex(Me._picBusySmall_0, CType(0, Short))
        Me._picBusySmall_0.Location = New System.Drawing.Point(-24, 8)
        Me._picBusySmall_0.Name = "_picBusySmall_0"
        Me._picBusySmall_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._picBusySmall_0.Size = New System.Drawing.Size(69, 69)
        Me._picBusySmall_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me._picBusySmall_0.TabIndex = 19
        Me._picBusySmall_0.TabStop = False
        '
        'picBusyDoneSmall
        '
        Me.picBusyDoneSmall.BackColor = System.Drawing.SystemColors.Control
        Me.picBusyDoneSmall.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picBusyDoneSmall.Cursor = System.Windows.Forms.Cursors.Default
        Me.picBusyDoneSmall.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picBusyDoneSmall.Image = CType(resources.GetObject("picBusyDoneSmall.Image"), System.Drawing.Image)
        Me.picBusyDoneSmall.Location = New System.Drawing.Point(0, 0)
        Me.picBusyDoneSmall.Name = "picBusyDoneSmall"
        Me.picBusyDoneSmall.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.picBusyDoneSmall.Size = New System.Drawing.Size(69, 69)
        Me.picBusyDoneSmall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picBusyDoneSmall.TabIndex = 24
        Me.picBusyDoneSmall.TabStop = False
        '
        'Winsock
        '
        Me.Winsock.Enabled = True
        Me.Winsock.Location = New System.Drawing.Point(216, 320)
        Me.Winsock.Name = "Winsock"
        Me.Winsock.OcxState = CType(resources.GetObject("Winsock.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Winsock.Size = New System.Drawing.Size(28, 28)
        Me.Winsock.TabIndex = 31
        '
        'tmrBusyAnimation
        '
        Me.tmrBusyAnimation.Interval = 300
        '
        'staMain
        '
        Me.staMain.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.staMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._staMain_Panel1, Me._staMain_Panel2, Me._staMain_Panel3})
        Me.staMain.Location = New System.Drawing.Point(0, 530)
        Me.staMain.Name = "staMain"
        Me.staMain.Size = New System.Drawing.Size(880, 27)
        Me.staMain.TabIndex = 2
        Me.staMain.Tag = "frmMain.staMain"
        '
        '_staMain_Panel1
        '
        Me._staMain_Panel1.AutoSize = False
        Me._staMain_Panel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._staMain_Panel1.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._staMain_Panel1.Margin = New System.Windows.Forms.Padding(0)
        Me._staMain_Panel1.Name = "_staMain_Panel1"
        Me._staMain_Panel1.Size = New System.Drawing.Size(87, 27)
        Me._staMain_Panel1.Tag = "frmMain.staMain.txtBusy"
        Me._staMain_Panel1.Text = "Idle"
        Me._staMain_Panel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me._staMain_Panel1.ToolTipText = " What WebbIE is doing "
        '
        '_staMain_Panel2
        '
        Me._staMain_Panel2.AutoSize = False
        Me._staMain_Panel2.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._staMain_Panel2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._staMain_Panel2.Margin = New System.Windows.Forms.Padding(0)
        Me._staMain_Panel2.Name = "_staMain_Panel2"
        Me._staMain_Panel2.Size = New System.Drawing.Size(691, 27)
        Me._staMain_Panel2.Spring = True
        Me._staMain_Panel2.Tag = "frmMain.staMain.txtTitle"
        Me._staMain_Panel2.Text = "Blank"
        Me._staMain_Panel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me._staMain_Panel2.ToolTipText = " Title of this web page "
        '
        '_staMain_Panel3
        '
        Me._staMain_Panel3.AutoSize = False
        Me._staMain_Panel3.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
                    Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me._staMain_Panel3.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me._staMain_Panel3.Margin = New System.Windows.Forms.Padding(0)
        Me._staMain_Panel3.Name = "_staMain_Panel3"
        Me._staMain_Panel3.Size = New System.Drawing.Size(87, 27)
        Me._staMain_Panel3.Tag = "frmMain.staMain.txtConnection"
        Me._staMain_Panel3.Text = "Disconnected"
        Me._staMain_Panel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me._staMain_Panel3.ToolTipText = " Whether your are online or offline "
        '
        'tmrConnectionPoller
        '
        Me.tmrConnectionPoller.Enabled = True
        Me.tmrConnectionPoller.Interval = 1000
        '
        'lblText
        '
        Me.lblText.AutoSize = True
        Me.lblText.BackColor = System.Drawing.SystemColors.Control
        Me.lblText.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblText.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblText.Location = New System.Drawing.Point(328, 264)
        Me.lblText.Name = "lblText"
        Me.lblText.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblText.Size = New System.Drawing.Size(33, 16)
        Me.lblText.TabIndex = 17
        Me.lblText.Tag = "frmMain.lblText"
        Me.lblText.Text = "&Text"
        '
        'mnuHelpContents
        '
        '
        'mnuOptionsDownloadingimagesOptions
        '
        '
        'NavigationBarPanel
        '
        Me.NavigationBarPanel.Controls.Add(Me.fraBusy)
        Me.NavigationBarPanel.Controls.Add(Me.fraToolBar)
        Me.NavigationBarPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.NavigationBarPanel.Location = New System.Drawing.Point(0, 24)
        Me.NavigationBarPanel.Name = "NavigationBarPanel"
        Me.NavigationBarPanel.Size = New System.Drawing.Size(880, 85)
        Me.NavigationBarPanel.TabIndex = 33
        '
        'fraBusy
        '
        Me.fraBusy.BackColor = System.Drawing.SystemColors.Control
        Me.fraBusy.Controls.Add(Me._picBusyAnimation_1)
        Me.fraBusy.Controls.Add(Me._picBusyAnimation_3)
        Me.fraBusy.Controls.Add(Me._picBusyAnimation_0)
        Me.fraBusy.Controls.Add(Me._picBusyAnimation_2)
        Me.fraBusy.Controls.Add(Me.picBusyDone)
        Me.fraBusy.Cursor = System.Windows.Forms.Cursors.Default
        Me.fraBusy.Dock = System.Windows.Forms.DockStyle.Fill
        Me.fraBusy.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraBusy.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraBusy.Location = New System.Drawing.Point(785, 0)
        Me.fraBusy.Name = "fraBusy"
        Me.fraBusy.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraBusy.Size = New System.Drawing.Size(95, 85)
        Me.fraBusy.TabIndex = 18
        '
        'picBusyDone
        '
        Me.picBusyDone.BackColor = System.Drawing.SystemColors.Control
        Me.picBusyDone.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picBusyDone.Cursor = System.Windows.Forms.Cursors.Default
        Me.picBusyDone.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picBusyDone.Image = CType(resources.GetObject("picBusyDone.Image"), System.Drawing.Image)
        Me.picBusyDone.Location = New System.Drawing.Point(0, 0)
        Me.picBusyDone.Name = "picBusyDone"
        Me.picBusyDone.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.picBusyDone.Size = New System.Drawing.Size(85, 85)
        Me.picBusyDone.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picBusyDone.TabIndex = 23
        Me.picBusyDone.TabStop = False
        Me.picBusyDone.Tag = "frmMain.picBusyDone"
        '
        'fraToolBar
        '
        Me.fraToolBar.BackColor = System.Drawing.SystemColors.Control
        Me.fraToolBar.Controls.Add(Me.cmdHeading)
        Me.fraToolBar.Controls.Add(Me.cmdMagnify)
        Me.fraToolBar.Controls.Add(Me.cmdSkiplinks)
        Me.fraToolBar.Controls.Add(Me.cmdViewIE)
        Me.fraToolBar.Controls.Add(Me.cmdHome)
        Me.fraToolBar.Controls.Add(Me.cmdRefresh)
        Me.fraToolBar.Controls.Add(Me.cmdStop)
        Me.fraToolBar.Controls.Add(Me.cmdForward)
        Me.fraToolBar.Controls.Add(Me.cmdBack)
        Me.fraToolBar.Cursor = System.Windows.Forms.Cursors.Default
        Me.fraToolBar.Dock = System.Windows.Forms.DockStyle.Left
        Me.fraToolBar.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fraToolBar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.fraToolBar.Location = New System.Drawing.Point(0, 0)
        Me.fraToolBar.Name = "fraToolBar"
        Me.fraToolBar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.fraToolBar.Size = New System.Drawing.Size(785, 85)
        Me.fraToolBar.TabIndex = 17
        '
        'cmdHeading
        '
        Me.cmdHeading.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHeading.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHeading.Enabled = False
        Me.cmdHeading.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHeading.Image = CType(resources.GetObject("cmdHeading.Image"), System.Drawing.Image)
        Me.cmdHeading.Location = New System.Drawing.Point(688, 0)
        Me.cmdHeading.Name = "cmdHeading"
        Me.cmdHeading.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHeading.Size = New System.Drawing.Size(97, 81)
        Me.cmdHeading.TabIndex = 29
        Me.cmdHeading.TabStop = False
        Me.cmdHeading.Tag = "frmMain.cmdMagnify"
        Me.cmdHeading.Text = "Heading"
        Me.cmdHeading.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdHeading.UseVisualStyleBackColor = False
        '
        'cmdMagnify
        '
        Me.cmdMagnify.BackColor = System.Drawing.SystemColors.Control
        Me.cmdMagnify.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdMagnify.Enabled = False
        Me.cmdMagnify.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdMagnify.Image = CType(resources.GetObject("cmdMagnify.Image"), System.Drawing.Image)
        Me.cmdMagnify.Location = New System.Drawing.Point(592, 0)
        Me.cmdMagnify.Name = "cmdMagnify"
        Me.cmdMagnify.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdMagnify.Size = New System.Drawing.Size(97, 81)
        Me.cmdMagnify.TabIndex = 9
        Me.cmdMagnify.TabStop = False
        Me.cmdMagnify.Tag = "frmMain.cmdMagnify"
        Me.cmdMagnify.Text = "Magnify"
        Me.cmdMagnify.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdMagnify.UseVisualStyleBackColor = False
        '
        'cmdSkiplinks
        '
        Me.cmdSkiplinks.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSkiplinks.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSkiplinks.Enabled = False
        Me.cmdSkiplinks.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdSkiplinks.Image = CType(resources.GetObject("cmdSkiplinks.Image"), System.Drawing.Image)
        Me.cmdSkiplinks.Location = New System.Drawing.Point(592, 0)
        Me.cmdSkiplinks.Name = "cmdSkiplinks"
        Me.cmdSkiplinks.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSkiplinks.Size = New System.Drawing.Size(97, 81)
        Me.cmdSkiplinks.TabIndex = 10
        Me.cmdSkiplinks.TabStop = False
        Me.cmdSkiplinks.Tag = "frmMain.cmdSkiplinks"
        Me.cmdSkiplinks.Text = "Skip links"
        Me.cmdSkiplinks.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdSkiplinks.UseVisualStyleBackColor = False
        '
        'cmdViewIE
        '
        Me.cmdViewIE.BackColor = System.Drawing.SystemColors.Control
        Me.cmdViewIE.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdViewIE.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdViewIE.Image = CType(resources.GetObject("cmdViewIE.Image"), System.Drawing.Image)
        Me.cmdViewIE.Location = New System.Drawing.Point(496, 0)
        Me.cmdViewIE.Name = "cmdViewIE"
        Me.cmdViewIE.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdViewIE.Size = New System.Drawing.Size(97, 81)
        Me.cmdViewIE.TabIndex = 8
        Me.cmdViewIE.TabStop = False
        Me.cmdViewIE.Tag = "frmMain.cmdViewIE"
        Me.cmdViewIE.Text = "View web"
        Me.cmdViewIE.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdViewIE.UseVisualStyleBackColor = False
        '
        'cmdHome
        '
        Me.cmdHome.BackColor = System.Drawing.SystemColors.Control
        Me.cmdHome.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdHome.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdHome.Image = CType(resources.GetObject("cmdHome.Image"), System.Drawing.Image)
        Me.cmdHome.Location = New System.Drawing.Point(400, 0)
        Me.cmdHome.Name = "cmdHome"
        Me.cmdHome.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHome.Size = New System.Drawing.Size(97, 81)
        Me.cmdHome.TabIndex = 7
        Me.cmdHome.TabStop = False
        Me.cmdHome.Tag = "frmMain.cmdHome"
        Me.cmdHome.Text = "Home"
        Me.cmdHome.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdHome.UseVisualStyleBackColor = False
        '
        'cmdRefresh
        '
        Me.cmdRefresh.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRefresh.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdRefresh.Enabled = False
        Me.cmdRefresh.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdRefresh.Image = CType(resources.GetObject("cmdRefresh.Image"), System.Drawing.Image)
        Me.cmdRefresh.Location = New System.Drawing.Point(296, 0)
        Me.cmdRefresh.Name = "cmdRefresh"
        Me.cmdRefresh.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdRefresh.Size = New System.Drawing.Size(97, 81)
        Me.cmdRefresh.TabIndex = 6
        Me.cmdRefresh.TabStop = False
        Me.cmdRefresh.Tag = "frmMain.cmdRefresh"
        Me.cmdRefresh.Text = "Refresh"
        Me.cmdRefresh.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdRefresh.UseVisualStyleBackColor = False
        '
        'cmdStop
        '
        Me.cmdStop.BackColor = System.Drawing.SystemColors.Control
        Me.cmdStop.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdStop.Enabled = False
        Me.cmdStop.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdStop.Image = CType(resources.GetObject("cmdStop.Image"), System.Drawing.Image)
        Me.cmdStop.Location = New System.Drawing.Point(200, 0)
        Me.cmdStop.Name = "cmdStop"
        Me.cmdStop.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdStop.Size = New System.Drawing.Size(97, 81)
        Me.cmdStop.TabIndex = 5
        Me.cmdStop.TabStop = False
        Me.cmdStop.Tag = "frmMain.cmdStop"
        Me.cmdStop.Text = "Stop"
        Me.cmdStop.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdStop.UseVisualStyleBackColor = False
        '
        'cmdForward
        '
        Me.cmdForward.BackColor = System.Drawing.SystemColors.Control
        Me.cmdForward.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdForward.Enabled = False
        Me.cmdForward.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdForward.Image = CType(resources.GetObject("cmdForward.Image"), System.Drawing.Image)
        Me.cmdForward.Location = New System.Drawing.Point(96, 0)
        Me.cmdForward.Name = "cmdForward"
        Me.cmdForward.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdForward.Size = New System.Drawing.Size(97, 81)
        Me.cmdForward.TabIndex = 4
        Me.cmdForward.TabStop = False
        Me.cmdForward.Tag = "frmMain.cmdForward"
        Me.cmdForward.Text = "Forward"
        Me.cmdForward.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdForward.UseVisualStyleBackColor = False
        '
        'cmdBack
        '
        Me.cmdBack.BackColor = System.Drawing.SystemColors.Control
        Me.cmdBack.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBack.Enabled = False
        Me.cmdBack.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdBack.Image = CType(resources.GetObject("cmdBack.Image"), System.Drawing.Image)
        Me.cmdBack.Location = New System.Drawing.Point(0, 0)
        Me.cmdBack.Name = "cmdBack"
        Me.cmdBack.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBack.Size = New System.Drawing.Size(97, 81)
        Me.cmdBack.TabIndex = 3
        Me.cmdBack.TabStop = False
        Me.cmdBack.Tag = "frmMain.cmdBack"
        Me.cmdBack.Text = "Back"
        Me.cmdBack.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdBack.UseVisualStyleBackColor = False
        '
        'MainPanel
        '
        Me.MainPanel.Controls.Add(Me.PanelText)
        Me.MainPanel.Controls.Add(Me.AddressPanel)
        Me.MainPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MainPanel.Location = New System.Drawing.Point(0, 109)
        Me.MainPanel.Name = "MainPanel"
        Me.MainPanel.Size = New System.Drawing.Size(880, 421)
        Me.MainPanel.TabIndex = 34
        '
        'PanelText
        '
        Me.PanelText.Controls.Add(Me.mWebBrowser)
        Me.PanelText.Controls.Add(Me.txtText)
        Me.PanelText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelText.Location = New System.Drawing.Point(0, 48)
        Me.PanelText.Name = "PanelText"
        Me.PanelText.Size = New System.Drawing.Size(880, 373)
        Me.PanelText.TabIndex = 1
        '
        'mWebBrowser
        '
        Me.mWebBrowser.Location = New System.Drawing.Point(392, 126)
        Me.mWebBrowser.Name = "mWebBrowser"
        Me.mWebBrowser.Size = New System.Drawing.Size(97, 121)
        Me.mWebBrowser.TabIndex = 32
        '
        'txtText
        '
        Me.txtText.AcceptsReturn = True
        Me.txtText.BackColor = System.Drawing.SystemColors.Window
        Me.txtText.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtText.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtText.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtText.Location = New System.Drawing.Point(0, 0)
        Me.txtText.MaxLength = 0
        Me.txtText.Multiline = True
        Me.txtText.Name = "txtText"
        Me.txtText.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtText.Size = New System.Drawing.Size(880, 373)
        Me.txtText.TabIndex = 31
        '
        'AddressPanel
        '
        Me.AddressPanel.Controls.Add(Me.lblAddress)
        Me.AddressPanel.Controls.Add(Me.cboAddress)
        Me.AddressPanel.Dock = System.Windows.Forms.DockStyle.Top
        Me.AddressPanel.Location = New System.Drawing.Point(0, 0)
        Me.AddressPanel.Name = "AddressPanel"
        Me.AddressPanel.Size = New System.Drawing.Size(880, 48)
        Me.AddressPanel.TabIndex = 0
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.BackColor = System.Drawing.SystemColors.Control
        Me.lblAddress.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblAddress.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblAddress.Location = New System.Drawing.Point(12, 10)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblAddress.Size = New System.Drawing.Size(54, 16)
        Me.lblAddress.TabIndex = 3
        Me.lblAddress.Tag = "frmMain.lblAddress"
        Me.lblAddress.Text = "A&ddress"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(880, 557)
        Me.Controls.Add(Me.MainPanel)
        Me.Controls.Add(Me.NavigationBarPanel)
        Me.Controls.Add(Me.cmdShrink)
        Me.Controls.Add(Me.workBrowser)
        Me.Controls.Add(Me.fraBusySmall)
        Me.Controls.Add(Me.Winsock)
        Me.Controls.Add(Me.staMain)
        Me.Controls.Add(Me.lblText)
        Me.Controls.Add(Me.MainMenu1)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.Location = New System.Drawing.Point(15, 57)
        Me.Name = "frmMain"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Tag = "frmMain"
        Me.Text = "WebbIE"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me._picBusyAnimation_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._picBusyAnimation_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._picBusyAnimation_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._picBusyAnimation_2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MainMenu1.ResumeLayout(False)
        Me.MainMenu1.PerformLayout()
        Me.fraBusySmall.ResumeLayout(False)
        Me.fraBusySmall.PerformLayout()
        CType(Me._picBusySmall_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._picBusySmall_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._picBusySmall_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._picBusySmall_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBusyDoneSmall, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Winsock, System.ComponentModel.ISupportInitialize).EndInit()
        Me.staMain.ResumeLayout(False)
        Me.staMain.PerformLayout()
        CType(Me.mnuHelpContents, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mnuOptionsDownloadingimagesOptions, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mnuOptionsLanguageselect, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.mnuSimplebookmarkList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBusyAnimation, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBusySmall, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NavigationBarPanel.ResumeLayout(False)
        Me.fraBusy.ResumeLayout(False)
        Me.fraBusy.PerformLayout()
        CType(Me.picBusyDone, System.ComponentModel.ISupportInitialize).EndInit()
        Me.fraToolBar.ResumeLayout(False)
        Me.MainPanel.ResumeLayout(False)
        Me.PanelText.ResumeLayout(False)
        Me.PanelText.PerformLayout()
        Me.AddressPanel.ResumeLayout(False)
        Me.AddressPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NavigationBarPanel As System.Windows.Forms.Panel
    Friend WithEvents MainPanel As System.Windows.Forms.Panel
    Friend WithEvents PanelText As System.Windows.Forms.Panel
    Public WithEvents txtText As System.Windows.Forms.TextBox
    Friend WithEvents AddressPanel As System.Windows.Forms.Panel
    Public WithEvents lblAddress As System.Windows.Forms.Label
    Public WithEvents cboAddress As System.Windows.Forms.ComboBox
    Public WithEvents fraToolBar As System.Windows.Forms.Panel
    Public WithEvents cmdHeading As System.Windows.Forms.Button
    Public WithEvents cmdMagnify As System.Windows.Forms.Button
    Public WithEvents cmdSkiplinks As System.Windows.Forms.Button
    Public WithEvents cmdViewIE As System.Windows.Forms.Button
    Public WithEvents cmdHome As System.Windows.Forms.Button
    Public WithEvents cmdRefresh As System.Windows.Forms.Button
    Public WithEvents cmdStop As System.Windows.Forms.Button
    Public WithEvents cmdForward As System.Windows.Forms.Button
    Public WithEvents cmdBack As System.Windows.Forms.Button
    Public WithEvents fraBusy As System.Windows.Forms.Panel
    Public WithEvents _picBusyAnimation_1 As System.Windows.Forms.PictureBox
    Public WithEvents _picBusyAnimation_3 As System.Windows.Forms.PictureBox
    Public WithEvents _picBusyAnimation_0 As System.Windows.Forms.PictureBox
    Public WithEvents _picBusyAnimation_2 As System.Windows.Forms.PictureBox
    Public WithEvents picBusyDone As System.Windows.Forms.PictureBox
    Public WithEvents mWebBrowser As System.Windows.Forms.WebBrowser
    Friend WithEvents StartingOutASimpleGuideToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebbIEMenuCommandsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WebbIEControlKeysToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TheWebbIEToolbarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HowToUseFormsInWebbIEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TurnOffAllImagesInWebbIEAndInternetExplorerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TurnOnAllImagesInWebbIEAndInternetExplorerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
#End Region 
End Class