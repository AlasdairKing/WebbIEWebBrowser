<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmTextView
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents mnuFileClose As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditCut As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditCopy As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditPaste As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditSelectall As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditFind As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEditFindnext As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents mnuEdit As System.Windows.Forms.ToolStripMenuItem
	Public WithEvents MainMenu1 As System.Windows.Forms.MenuStrip
	Public WithEvents txtTextView As System.Windows.Forms.TextBox
	Public WithEvents cmdOK As System.Windows.Forms.Button
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmTextView))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.MainMenu1 = New System.Windows.Forms.MenuStrip
		Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem
		Me.mnuFileClose = New System.Windows.Forms.ToolStripMenuItem
		Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem
		Me.mnuEditCut = New System.Windows.Forms.ToolStripMenuItem
		Me.mnuEditCopy = New System.Windows.Forms.ToolStripMenuItem
		Me.mnuEditPaste = New System.Windows.Forms.ToolStripMenuItem
		Me.mnuEditSelectall = New System.Windows.Forms.ToolStripMenuItem
		Me.mnuEditFind = New System.Windows.Forms.ToolStripMenuItem
		Me.mnuEditFindnext = New System.Windows.Forms.ToolStripMenuItem
		Me.txtTextView = New System.Windows.Forms.TextBox
		Me.cmdOK = New System.Windows.Forms.Button
		Me.MainMenu1.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		Me.Text = "WebbIE Text View"
		Me.ClientSize = New System.Drawing.Size(803, 589)
		Me.Location = New System.Drawing.Point(15, 57)
		Me.Icon = CType(resources.GetObject("frmTextView.Icon"), System.Drawing.Icon)
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Tag = "frmTextView"
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmTextView"
		Me.mnuFile.Name = "mnuFile"
		Me.mnuFile.Text = "&File"
		Me.mnuFile.Tag = "frmTextView.mnuFile"
		Me.mnuFile.Checked = False
		Me.mnuFile.Enabled = True
		Me.mnuFile.Visible = True
		Me.mnuFileClose.Name = "mnuFileClose"
		Me.mnuFileClose.Text = "&Close"
		Me.mnuFileClose.Tag = "frmTextView.mnuFileClose"
		Me.mnuFileClose.Checked = False
		Me.mnuFileClose.Enabled = True
		Me.mnuFileClose.Visible = True
		Me.mnuEdit.Name = "mnuEdit"
		Me.mnuEdit.Text = "&Edit"
		Me.mnuEdit.Tag = "frmTextView.mnuEdit"
		Me.mnuEdit.Checked = False
		Me.mnuEdit.Enabled = True
		Me.mnuEdit.Visible = True
		Me.mnuEditCut.Name = "mnuEditCut"
		Me.mnuEditCut.Text = "Cu&t"
		Me.mnuEditCut.Enabled = False
		Me.mnuEditCut.ShortcutKeys = CType(System.Windows.Forms.Keys.Control or System.Windows.Forms.Keys.X, System.Windows.Forms.Keys)
		Me.mnuEditCut.Tag = "frmTextView.mnuEditCut"
		Me.mnuEditCut.Checked = False
		Me.mnuEditCut.Visible = True
		Me.mnuEditCopy.Name = "mnuEditCopy"
		Me.mnuEditCopy.Text = "&Copy"
		Me.mnuEditCopy.Enabled = False
		Me.mnuEditCopy.ShortcutKeys = CType(System.Windows.Forms.Keys.Control or System.Windows.Forms.Keys.C, System.Windows.Forms.Keys)
		Me.mnuEditCopy.Tag = "frmTextView.mnuEditCopy"
		Me.mnuEditCopy.Checked = False
		Me.mnuEditCopy.Visible = True
		Me.mnuEditPaste.Name = "mnuEditPaste"
		Me.mnuEditPaste.Text = "&Paste"
		Me.mnuEditPaste.Enabled = False
		Me.mnuEditPaste.ShortcutKeys = CType(System.Windows.Forms.Keys.Control or System.Windows.Forms.Keys.V, System.Windows.Forms.Keys)
		Me.mnuEditPaste.Tag = "frmTextView.mnuEditPaste"
		Me.mnuEditPaste.Checked = False
		Me.mnuEditPaste.Visible = True
		Me.mnuEditSelectall.Name = "mnuEditSelectall"
		Me.mnuEditSelectall.Text = "Select &All"
		Me.mnuEditSelectall.ShortcutKeys = CType(System.Windows.Forms.Keys.Control or System.Windows.Forms.Keys.A, System.Windows.Forms.Keys)
		Me.mnuEditSelectall.Tag = "frmTextView.mnuEditSelectall"
		Me.mnuEditSelectall.Checked = False
		Me.mnuEditSelectall.Enabled = True
		Me.mnuEditSelectall.Visible = True
		Me.mnuEditFind.Name = "mnuEditFind"
		Me.mnuEditFind.Text = "&Find (on this page)"
		Me.mnuEditFind.ShortcutKeys = CType(System.Windows.Forms.Keys.Control or System.Windows.Forms.Keys.F, System.Windows.Forms.Keys)
		Me.mnuEditFind.Tag = "frmTextView.mnuEditFind"
		Me.mnuEditFind.Checked = False
		Me.mnuEditFind.Enabled = True
		Me.mnuEditFind.Visible = True
		Me.mnuEditFindnext.Name = "mnuEditFindnext"
		Me.mnuEditFindnext.Text = "Find &Next"
		Me.mnuEditFindnext.ShortcutKeys = CType(System.Windows.Forms.Keys.F3, System.Windows.Forms.Keys)
		Me.mnuEditFindnext.Tag = "frmTextView.mnuEditFindnext"
		Me.mnuEditFindnext.Checked = False
		Me.mnuEditFindnext.Enabled = True
		Me.mnuEditFindnext.Visible = True
		Me.txtTextView.AutoSize = False
		Me.txtTextView.Size = New System.Drawing.Size(785, 513)
		Me.txtTextView.Location = New System.Drawing.Point(8, 24)
		Me.txtTextView.MultiLine = True
		Me.txtTextView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
		Me.txtTextView.TabIndex = 1
		Me.txtTextView.Text = "Text1"
		Me.txtTextView.AcceptsReturn = True
		Me.txtTextView.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.txtTextView.BackColor = System.Drawing.SystemColors.Window
		Me.txtTextView.CausesValidation = True
		Me.txtTextView.Enabled = True
		Me.txtTextView.ForeColor = System.Drawing.SystemColors.WindowText
		Me.txtTextView.HideSelection = True
		Me.txtTextView.ReadOnly = False
		Me.txtTextView.Maxlength = 0
		Me.txtTextView.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.txtTextView.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.txtTextView.TabStop = True
		Me.txtTextView.Visible = True
		Me.txtTextView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.txtTextView.Name = "txtTextView"
		Me.cmdOK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.CancelButton = Me.cmdOK
		Me.cmdOK.Text = "OK"
		Me.AcceptButton = Me.cmdOK
		Me.cmdOK.Size = New System.Drawing.Size(81, 33)
		Me.cmdOK.Location = New System.Drawing.Point(360, 552)
		Me.cmdOK.TabIndex = 0
		Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
		Me.cmdOK.CausesValidation = True
		Me.cmdOK.Enabled = True
		Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdOK.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdOK.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdOK.TabStop = True
		Me.cmdOK.Name = "cmdOK"
		Me.Controls.Add(txtTextView)
		Me.Controls.Add(cmdOK)
		MainMenu1.Items.AddRange(New System.Windows.Forms.ToolStripItem(){Me.mnuFile, Me.mnuEdit})
		mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem(){Me.mnuFileClose})
		mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem(){Me.mnuEditCut, Me.mnuEditCopy, Me.mnuEditPaste, Me.mnuEditSelectall, Me.mnuEditFind, Me.mnuEditFindnext})
		Me.Controls.Add(MainMenu1)
		Me.MainMenu1.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class