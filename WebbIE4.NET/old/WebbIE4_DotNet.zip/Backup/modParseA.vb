Option Strict Off
Option Explicit On
Module modParseA
	
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'modParseA
	'Parses an Anchor element, identifying text and image content and getting alt text where necessary
	'Also parses Button nodes, which can also contain content.
	
	Private mAnchorDatabase As New Scripting.Dictionary
	Private mToGetList As New Scripting.Dictionary
	Private mGetter As New frmLocationGetter
	
	Public Function Parse(ByRef anyNode As mshtml.IHTMLDOMNode) As String
		On Error Resume Next
		Parse = Trim(ParseA(anyNode))
	End Function
	
	Public Function ParseAnchor(ByRef anchorNode As mshtml.IHTMLDOMNode) As String
		On Error Resume Next
		ParseAnchor = Trim(ParseA(anchorNode))
		If Len(ParseAnchor) = 0 Then
			'No text obtained: fall back to A element's title or alt attribute. Title first.
			'But might be a non-A element with some information itself, or it might be
			'an A element with a title attribute - see http://www.unco.edu/, which uses
			'links with &nbsp; as the link content, fills in the content with an image
			'as the background in CSS, and puts the text content in the title attribute
			'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If Not (anchorNode.attributes.getNamedItem("title") Is Nothing) Then
				'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ParseAnchor = anchorNode.attributes.getNamedItem("title").nodeValue
			End If
			'Did that work? Try alt (not compliant with the html spec, but never mind!
			'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If Not (anchorNode.attributes.getNamedItem("title") Is Nothing) Then
				'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ParseAnchor = Trim(anchorNode.attributes.getNamedItem("title").nodeValue)
			End If
			If Len(ParseAnchor) = 0 Then
				'Try alt.
				'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If Not (anchorNode.attributes.getNamedItem("alt") Is Nothing) Then
					'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					ParseAnchor = Trim(anchorNode.attributes.getNamedItem("alt").nodeValue)
				End If
			End If
			'Did that work? Have to use the href value.
		End If
	End Function
	
	
	Private Function ParseA(ByRef anchorNode As mshtml.IHTMLDOMNode) As String
		On Error Resume Next
		Dim childNode As mshtml.IHTMLDOMNode
		Dim NBSP As String
        NBSP = Chr(160)
        ParseA = ""
		
		If anchorNode.nodeName = "#text" Then
			'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.nodeValue. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ParseA = anchorNode.nodeValue
			ParseA = Replace(ParseA, NBSP, " ")
			ParseA = Replace(ParseA, vbNewLine, "")
			ParseA = Replace(ParseA, vbCr, "")
			ParseA = Replace(ParseA, vbLf, "")
			'Debug.Print "Text obtained via ParseA: " & ParseA
		ElseIf anchorNode.nodeName = "IMG" Then 
			'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If anchorNode.attributes.getNamedItem("alt") Is Nothing Then
				'No alt tag!
			Else
				'We put the " " in because people tend to just do "text<img>" - BBC News
				'does this.
				'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ParseA = " " & anchorNode.attributes.getNamedItem("alt").nodeValue & " "
			End If
		ElseIf anchorNode.hasChildNodes Then 
			For	Each childNode In anchorNode.childNodes
				ParseA = ParseA & ParseA(childNode)
			Next childNode
		End If
		
		'3.10.5
		'Fall back to title if nothing else found.
		If ParseA = "" Then
			If anchorNode.attributes Is Nothing Then
				'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			ElseIf anchorNode.attributes.getNamedItem("title") Is Nothing Then 
			Else
				'UPGRADE_WARNING: Couldn't resolve default property of object anchorNode.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				ParseA = anchorNode.attributes.getNamedItem("title").nodeValue & " "
			End If
		End If
	End Function
	
	Public Sub AddLocationTitle(ByRef url As String, ByRef title As String)
		On Error Resume Next
		If mAnchorDatabase.Exists(url) Then
            mAnchorDatabase(url) = title
		Else
			Call mAnchorDatabase.Add(url, title)
		End If
	End Sub
	
	Public Function GetLocationTitle(ByRef url As String) As String
		On Error Resume Next
		If mAnchorDatabase.Exists(url) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object mAnchorDatabase.Item(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			GetLocationTitle = mAnchorDatabase.Item(url)
		Else
			Call AddLocationToGet(url)
		End If
	End Function
	
	Private Sub AddLocationToGet(ByRef url As String)
		On Error Resume Next
		If InStr(1, url, "javascript", CompareMethod.Text) = 1 Or InStr(1, url, "doubleclick", CompareMethod.Text) > 0 Then
			'Don't get, crap.
		ElseIf Len(Trim(url)) = 0 Then 
			'Don't get, invalid
		Else
			'Debug.Print "Added location to get: " & url
			If Not mToGetList.Exists(url) Then
				Call mToGetList.Add(url, "")
			End If
		End If
	End Sub
	
	Public Function IsLocationsToGet() As Boolean
		On Error Resume Next
		IsLocationsToGet = (mToGetList.Count > 0)
	End Function
	
	Public Sub StartGettingLocations()
		On Error Resume Next
		Call mGetter.StartGetting()
	End Sub
	
	Public Sub StopGettingLocations()
		On Error Resume Next
		Call mGetter.StopGetting()
	End Sub
	
	Public Function NextLocationToGet() As String
		On Error Resume Next
		If mToGetList.Count > 0 Then
			'UPGRADE_WARNING: Couldn't resolve default property of object mToGetList.Keys(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			NextLocationToGet = mToGetList.Keys(0)
			Call mToGetList.Remove(NextLocationToGet)
		End If
	End Function
End Module