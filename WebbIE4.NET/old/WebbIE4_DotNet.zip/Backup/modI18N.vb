Option Strict On
Option Explicit On
Module modI18N

    Private mLanguageXML As System.Xml.XmlDocument
    Private mLanguageCode As String
    Private mLanguageCodeFallback As String
    Private mInitialised As Boolean

    Private Sub Initialise()
        If mInitialised Then
            'Already loaded.
        Else
            mLanguageXML = New System.Xml.XmlDocument()
            mLanguageXML.PreserveWhitespace = False
            Call mLanguageXML.Load(My.Application.Info.DirectoryPath & "\" & My.Application.Info.AssemblyName & ".Language.xml")

            'Load the locale information.
            Dim ci As System.Globalization.CultureInfo = New System.Globalization.CultureInfo(System.Globalization.CultureInfo.CurrentUICulture.LCID) ' Thread.CurrentThread.CurrentCulture.LCID);
            mLanguageCode = ci.Name.ToLower()
            mLanguageCodeFallback = ci.TwoLetterISOLanguageName.ToLower() 'returns the fallback "en" or whatever.
            mInitialised = True
        End If
    End Sub

    Public Function GetLanguage() As String
        Call Initialise()
        Return mLanguageCodeFallback
    End Function

    Public Function GetText(ByRef text As String) As String
        Call Initialise()
        Dim n As System.Xml.XmlNode
        n = mLanguageXML.DocumentElement.SelectSingleNode("contents/item[key=""" & text & """]/content[@language=""" & mLanguageCode & """]")
        If n Is Nothing Then
            n = mLanguageXML.DocumentElement.SelectSingleNode("contents/item[key=""" & text & """]/content[@language=""" & mLanguageCodeFallback & """]")
            If n Is Nothing Then
                GetText = text
            Else
                GetText = n.InnerText
            End If
        Else
            GetText = n.InnerText
        End If
    End Function
End Module