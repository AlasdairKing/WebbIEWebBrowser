Option Strict Off
Option Explicit On
Module modFormLabelHandler
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'modFormLabelHandler
	'Handles elements of type LABEL. These are descriptive labels for FORM elements,
	'but they can appear anywhere in the HTML, so we can't just populate as we
	'iterate through the page.
	
	Private labels As New Scripting.Dictionary
	
	Public Sub Clear()
		'clear the current label look-up
		On Error Resume Next
		Call labels.RemoveAll()
	End Sub
	
    Public Sub ProcessWebpageForLabels(ByRef page As mshtml.HTMLDocument)
        'find any labels in the page and populate the dictionary
        On Error Resume Next
        Dim label As mshtml.IHTMLElement
        Dim descriptiveText As String
        Dim labelTarget As String

        'check for labels
        'DEV: alas, we can't just check for forms: controls (and labels)
        'can exist outside of forms
        For Each label In page.getElementsByTagName("LABEL")
            'found a label!
            'find which form element it applies to
            'UPGRADE_WARNING: Couldn't resolve default property of object label.attributes. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            labelTarget = label.attributes.getNamedItem("for").nodeValue
            If labelTarget = "" Then
                'nope, no applied form element: it must apply to the contained
                'control element. We'll handle this in the parsing mechanism when
                'we have a chance to extract the label contents. See ParseNode.
            Else
                'got a target and applied form element
                'work out the descriptive text
                descriptiveText = Trim(label.innerText)
                descriptiveText = Replace(descriptiveText, vbCrLf, " ") ' remove any newlines, replace with spaces
                If Len(descriptiveText) = 0 Then
                    'no text! probably an image. Have a look
                    'UPGRADE_WARNING: Couldn't resolve default property of object label.hasChildNodes. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                    If label.hasChildNodes Then
                        'the element has children
                        'UPGRADE_WARNING: Couldn't resolve default property of object label.firstChild. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                        If label.firstChild.nodeName = "IMG" Then
                            'okay, it's an image
                            'UPGRADE_WARNING: Couldn't resolve default property of object label.firstChild. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                            If label.firstChild.attributes.getNamedItem("alt").nodeValue <> "" Then
                                'use the alt tag
                                'UPGRADE_WARNING: Couldn't resolve default property of object label.firstChild. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
                                descriptiveText = Trim(label.firstChild.attributes.getNamedItem("alt").nodeValue)
                            End If
                        End If
                    Else
                        'no child nodes - nothing to link to
                    End If
                Else
                    'okay, we have our descriptive text we can use.
                End If
                'add to the label look-up if we have managed to find some descriptive text
                If Len(descriptiveText) > 0 Then
                    '3.6.9 Trim the descriptive text. IE will dump a huge LABEL element on you if the site
                    'miscodes.
                    'In theory a label should not exist when it gets here - if it does, ignore the
                    'latest one.
                    If labels.Exists(labelTarget) Then
                        Debug.Print("Warning: page has multiple LABEL elements for one id. Id=" & labelTarget)
                    Else
                        'Was fifty, increased to 512 after someone complained their labels were getting truncated.
                        Call labels.Add(labelTarget, Left(descriptiveText, 512))
                    End If
                End If
            End If
        Next label
    End Sub
	
	Public Function GetDescriptiveText(ByRef controlID As String) As String
		'returns the descriptive text for a control indicated by controlID
		'returns empty string if not found
		On Error Resume Next
		If labels.Exists(controlID) Then
			'UPGRADE_WARNING: Couldn't resolve default property of object labels.Item(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            GetDescriptiveText = Trim(labels.Item(controlID))
		End If
	End Function
	
	'This function allows parsing to handle situations where a
	'label is not explicitly associated with a form element by id but contains the
	'form element it labels, e.g. <label>Name <input type="text" id="name"></label>
	
	Public Sub AddLabel(ByRef labelText As String, ByRef labelControl As mshtml.IHTMLElement)
		'Add label by hand
		On Error Resume Next
		Dim oldContent As String
		
		If labelControl Is Nothing Then
			'whoops, not got the control to be labelled. Do nothing.
			'UPGRADE_WARNING: Couldn't resolve default property of object labelControl.currentStyle. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		ElseIf labelControl.currentStyle.display = "none" Then 
			'Whoops, this element should not be rendered. Do nothing.
		Else
			'okay, already got control for which this is the label
			If Len(labelControl.getAttribute("id")) > 0 Then
				If labels.Exists(labelControl.getAttribute("id")) Then
					'Already got label: concatenate with existing contents. This is
					'completely valid HTML, even if no-one else supports it.
					'UPGRADE_WARNING: Couldn't resolve default property of object labels.Item(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					oldContent = labels.Item(labelControl.getAttribute("id"))
					If Len(oldContent) > 0 Then
						If InStr(1, ".!?:", Right(oldContent, 1)) = 0 Then
							oldContent = oldContent & "."
						End If
					End If
					labelText = oldContent & " " & labelText
					Call labels.Remove(labelControl.getAttribute("id"))
				End If
				Call labels.Add(labelControl.getAttribute("id"), labelText)
			Else
				'whoops, no id on the control. Give up.
			End If
		End If
	End Sub
End Module