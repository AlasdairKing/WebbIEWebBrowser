<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmLanguage
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents _optLanguage_0 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_2 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_1 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_3 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_4 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_5 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_6 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_7 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_8 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_9 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_11 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_13 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_12 As System.Windows.Forms.RadioButton
	Public WithEvents _optLanguage_10 As System.Windows.Forms.RadioButton
	Public WithEvents lblSelect As System.Windows.Forms.Label
	Public WithEvents picLanguage As System.Windows.Forms.Panel
	Public WithEvents _optDetect_1 As System.Windows.Forms.RadioButton
	Public WithEvents _optDetect_0 As System.Windows.Forms.RadioButton
	Public WithEvents picDetection As System.Windows.Forms.Panel
	Public WithEvents fraDetection As System.Windows.Forms.GroupBox
	Public WithEvents fraLanguage As System.Windows.Forms.GroupBox
	Public WithEvents cmdCancel As System.Windows.Forms.Button
	Public WithEvents cmdOK As System.Windows.Forms.Button
	Public WithEvents optDetect As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	Public WithEvents optLanguage As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmLanguage))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.picLanguage = New System.Windows.Forms.Panel
		Me._optLanguage_0 = New System.Windows.Forms.RadioButton
		Me._optLanguage_2 = New System.Windows.Forms.RadioButton
		Me._optLanguage_1 = New System.Windows.Forms.RadioButton
		Me._optLanguage_3 = New System.Windows.Forms.RadioButton
		Me._optLanguage_4 = New System.Windows.Forms.RadioButton
		Me._optLanguage_5 = New System.Windows.Forms.RadioButton
		Me._optLanguage_6 = New System.Windows.Forms.RadioButton
		Me._optLanguage_7 = New System.Windows.Forms.RadioButton
		Me._optLanguage_8 = New System.Windows.Forms.RadioButton
		Me._optLanguage_9 = New System.Windows.Forms.RadioButton
		Me._optLanguage_11 = New System.Windows.Forms.RadioButton
		Me._optLanguage_13 = New System.Windows.Forms.RadioButton
		Me._optLanguage_12 = New System.Windows.Forms.RadioButton
		Me._optLanguage_10 = New System.Windows.Forms.RadioButton
		Me.lblSelect = New System.Windows.Forms.Label
		Me.fraDetection = New System.Windows.Forms.GroupBox
		Me.picDetection = New System.Windows.Forms.Panel
		Me._optDetect_1 = New System.Windows.Forms.RadioButton
		Me._optDetect_0 = New System.Windows.Forms.RadioButton
		Me.fraLanguage = New System.Windows.Forms.GroupBox
		Me.cmdCancel = New System.Windows.Forms.Button
		Me.cmdOK = New System.Windows.Forms.Button
		Me.optDetect = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.optLanguage = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(components)
		Me.picLanguage.SuspendLayout()
		Me.fraDetection.SuspendLayout()
		Me.picDetection.SuspendLayout()
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		CType(Me.optDetect, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.optLanguage, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.Text = "WebbIE Language settings"
		Me.ClientSize = New System.Drawing.Size(435, 550)
		Me.Location = New System.Drawing.Point(3, 23)
		Me.ControlBox = False
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Tag = "frmLanguage"
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmLanguage"
		Me.picLanguage.Size = New System.Drawing.Size(393, 369)
		Me.picLanguage.Location = New System.Drawing.Point(24, 32)
		Me.picLanguage.TabIndex = 4
		Me.picLanguage.Dock = System.Windows.Forms.DockStyle.None
		Me.picLanguage.BackColor = System.Drawing.SystemColors.Control
		Me.picLanguage.CausesValidation = True
		Me.picLanguage.Enabled = True
		Me.picLanguage.ForeColor = System.Drawing.SystemColors.ControlText
		Me.picLanguage.Cursor = System.Windows.Forms.Cursors.Default
		Me.picLanguage.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.picLanguage.TabStop = True
		Me.picLanguage.Visible = True
		Me.picLanguage.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.picLanguage.Name = "picLanguage"
		Me._optLanguage_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_0.Text = "Arabic"
		Me._optLanguage_0.Size = New System.Drawing.Size(393, 33)
		Me._optLanguage_0.Location = New System.Drawing.Point(0, 32)
		Me._optLanguage_0.TabIndex = 18
		Me._optLanguage_0.Tag = "frmLanguage.optLanguage(0)"
		Me._optLanguage_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_0.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_0.CausesValidation = True
		Me._optLanguage_0.Enabled = True
		Me._optLanguage_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_0.TabStop = True
		Me._optLanguage_0.Checked = False
		Me._optLanguage_0.Visible = True
		Me._optLanguage_0.Name = "_optLanguage_0"
		Me._optLanguage_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_2.Text = "Central European (Hungarian, Slovakian)"
		Me._optLanguage_2.Size = New System.Drawing.Size(401, 33)
		Me._optLanguage_2.Location = New System.Drawing.Point(0, 80)
		Me._optLanguage_2.TabIndex = 17
		Me._optLanguage_2.Tag = "frmLanguage.optLanguage(2)"
		Me._optLanguage_2.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_2.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_2.CausesValidation = True
		Me._optLanguage_2.Enabled = True
		Me._optLanguage_2.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_2.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_2.TabStop = True
		Me._optLanguage_2.Checked = False
		Me._optLanguage_2.Visible = True
		Me._optLanguage_2.Name = "_optLanguage_2"
		Me._optLanguage_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_1.Text = "Baltic (Estonian, Lithanian, Latvian)"
		Me._optLanguage_1.Size = New System.Drawing.Size(401, 33)
		Me._optLanguage_1.Location = New System.Drawing.Point(0, 56)
		Me._optLanguage_1.TabIndex = 16
		Me._optLanguage_1.Tag = "frmLanguage.optLanguage(1)"
		Me._optLanguage_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_1.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_1.CausesValidation = True
		Me._optLanguage_1.Enabled = True
		Me._optLanguage_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_1.TabStop = True
		Me._optLanguage_1.Checked = False
		Me._optLanguage_1.Visible = True
		Me._optLanguage_1.Name = "_optLanguage_1"
		Me._optLanguage_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_3.Text = "Chinese (simplified)"
		Me._optLanguage_3.Size = New System.Drawing.Size(401, 33)
		Me._optLanguage_3.Location = New System.Drawing.Point(0, 104)
		Me._optLanguage_3.TabIndex = 15
		Me._optLanguage_3.Tag = "frmLanguage.optLanguage(3)"
		Me._optLanguage_3.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_3.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_3.CausesValidation = True
		Me._optLanguage_3.Enabled = True
		Me._optLanguage_3.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_3.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_3.TabStop = True
		Me._optLanguage_3.Checked = False
		Me._optLanguage_3.Visible = True
		Me._optLanguage_3.Name = "_optLanguage_3"
		Me._optLanguage_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_4.Text = "Chinese (traditional)"
		Me._optLanguage_4.Size = New System.Drawing.Size(393, 33)
		Me._optLanguage_4.Location = New System.Drawing.Point(0, 128)
		Me._optLanguage_4.TabIndex = 14
		Me._optLanguage_4.Tag = "frmLanguage.optLanguage(4)"
		Me._optLanguage_4.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_4.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_4.CausesValidation = True
		Me._optLanguage_4.Enabled = True
		Me._optLanguage_4.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_4.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_4.TabStop = True
		Me._optLanguage_4.Checked = False
		Me._optLanguage_4.Visible = True
		Me._optLanguage_4.Name = "_optLanguage_4"
		Me._optLanguage_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_5.Text = "Cyrillic (Russian)"
		Me._optLanguage_5.Size = New System.Drawing.Size(401, 33)
		Me._optLanguage_5.Location = New System.Drawing.Point(0, 152)
		Me._optLanguage_5.TabIndex = 13
		Me._optLanguage_5.Tag = "frmLanguage.optLanguage(5)"
		Me._optLanguage_5.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_5.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_5.CausesValidation = True
		Me._optLanguage_5.Enabled = True
		Me._optLanguage_5.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_5.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_5.TabStop = True
		Me._optLanguage_5.Checked = False
		Me._optLanguage_5.Visible = True
		Me._optLanguage_5.Name = "_optLanguage_5"
		Me._optLanguage_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_6.Text = "Greek"
		Me._optLanguage_6.Size = New System.Drawing.Size(401, 33)
		Me._optLanguage_6.Location = New System.Drawing.Point(0, 176)
		Me._optLanguage_6.TabIndex = 12
		Me._optLanguage_6.Tag = "frmLanguage.optLanguage(6)"
		Me._optLanguage_6.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_6.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_6.CausesValidation = True
		Me._optLanguage_6.Enabled = True
		Me._optLanguage_6.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_6.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_6.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_6.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_6.TabStop = True
		Me._optLanguage_6.Checked = False
		Me._optLanguage_6.Visible = True
		Me._optLanguage_6.Name = "_optLanguage_6"
		Me._optLanguage_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_7.Text = "Hebrew"
		Me._optLanguage_7.Size = New System.Drawing.Size(393, 33)
		Me._optLanguage_7.Location = New System.Drawing.Point(0, 200)
		Me._optLanguage_7.TabIndex = 11
		Me._optLanguage_7.Tag = "frmLanguage.optLanguage(7)"
		Me._optLanguage_7.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_7.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_7.CausesValidation = True
		Me._optLanguage_7.Enabled = True
		Me._optLanguage_7.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_7.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_7.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_7.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_7.TabStop = True
		Me._optLanguage_7.Checked = False
		Me._optLanguage_7.Visible = True
		Me._optLanguage_7.Name = "_optLanguage_7"
		Me._optLanguage_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_8.Text = "Japanese"
		Me._optLanguage_8.Size = New System.Drawing.Size(393, 33)
		Me._optLanguage_8.Location = New System.Drawing.Point(0, 224)
		Me._optLanguage_8.TabIndex = 10
		Me._optLanguage_8.Tag = "frmLanguage.optLanguage(8)"
		Me._optLanguage_8.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_8.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_8.CausesValidation = True
		Me._optLanguage_8.Enabled = True
		Me._optLanguage_8.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_8.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_8.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_8.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_8.TabStop = True
		Me._optLanguage_8.Checked = False
		Me._optLanguage_8.Visible = True
		Me._optLanguage_8.Name = "_optLanguage_8"
		Me._optLanguage_9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_9.Text = "Korean"
		Me._optLanguage_9.Size = New System.Drawing.Size(393, 33)
		Me._optLanguage_9.Location = New System.Drawing.Point(0, 248)
		Me._optLanguage_9.TabIndex = 9
		Me._optLanguage_9.Tag = "frmLanguage.optLanguage(9)"
		Me._optLanguage_9.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_9.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_9.CausesValidation = True
		Me._optLanguage_9.Enabled = True
		Me._optLanguage_9.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_9.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_9.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_9.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_9.TabStop = True
		Me._optLanguage_9.Checked = False
		Me._optLanguage_9.Visible = True
		Me._optLanguage_9.Name = "_optLanguage_9"
		Me._optLanguage_11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_11.Text = "Turkish"
		Me._optLanguage_11.Size = New System.Drawing.Size(401, 33)
		Me._optLanguage_11.Location = New System.Drawing.Point(0, 296)
		Me._optLanguage_11.TabIndex = 8
		Me._optLanguage_11.Tag = "frmLanguage.optLanguage(11)"
		Me._optLanguage_11.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_11.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_11.CausesValidation = True
		Me._optLanguage_11.Enabled = True
		Me._optLanguage_11.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_11.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_11.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_11.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_11.TabStop = True
		Me._optLanguage_11.Checked = False
		Me._optLanguage_11.Visible = True
		Me._optLanguage_11.Name = "_optLanguage_11"
		Me._optLanguage_13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_13.Text = "Western European (English, German, French)"
		Me._optLanguage_13.Size = New System.Drawing.Size(393, 17)
		Me._optLanguage_13.Location = New System.Drawing.Point(0, 352)
		Me._optLanguage_13.TabIndex = 7
		Me._optLanguage_13.Tag = "frmLanguage.optLanguage(13)"
		Me._optLanguage_13.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_13.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_13.CausesValidation = True
		Me._optLanguage_13.Enabled = True
		Me._optLanguage_13.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_13.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_13.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_13.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_13.TabStop = True
		Me._optLanguage_13.Checked = False
		Me._optLanguage_13.Visible = True
		Me._optLanguage_13.Name = "_optLanguage_13"
		Me._optLanguage_12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_12.Text = "Vietnamese"
		Me._optLanguage_12.Size = New System.Drawing.Size(393, 33)
		Me._optLanguage_12.Location = New System.Drawing.Point(0, 320)
		Me._optLanguage_12.TabIndex = 6
		Me._optLanguage_12.Tag = "frmLanguage.optLanguage(12)"
		Me._optLanguage_12.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_12.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_12.CausesValidation = True
		Me._optLanguage_12.Enabled = True
		Me._optLanguage_12.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_12.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_12.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_12.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_12.TabStop = True
		Me._optLanguage_12.Checked = False
		Me._optLanguage_12.Visible = True
		Me._optLanguage_12.Name = "_optLanguage_12"
		Me._optLanguage_10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_10.Text = "Thai"
		Me._optLanguage_10.Size = New System.Drawing.Size(393, 33)
		Me._optLanguage_10.Location = New System.Drawing.Point(0, 272)
		Me._optLanguage_10.TabIndex = 5
		Me._optLanguage_10.Tag = "frmLanguage.optLanguage(10)"
		Me._optLanguage_10.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optLanguage_10.BackColor = System.Drawing.SystemColors.Control
		Me._optLanguage_10.CausesValidation = True
		Me._optLanguage_10.Enabled = True
		Me._optLanguage_10.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optLanguage_10.Cursor = System.Windows.Forms.Cursors.Default
		Me._optLanguage_10.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optLanguage_10.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optLanguage_10.TabStop = True
		Me._optLanguage_10.Checked = False
		Me._optLanguage_10.Visible = True
		Me._optLanguage_10.Name = "_optLanguage_10"
		Me.lblSelect.Text = "Select the default language for WebbIE to use to display pages."
		Me.lblSelect.Size = New System.Drawing.Size(301, 13)
		Me.lblSelect.Location = New System.Drawing.Point(0, 0)
		Me.lblSelect.TabIndex = 19
		Me.lblSelect.Tag = "frmLanguage.lblSelect"
		Me.lblSelect.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblSelect.BackColor = System.Drawing.SystemColors.Control
		Me.lblSelect.Enabled = True
		Me.lblSelect.ForeColor = System.Drawing.SystemColors.ControlText
		Me.lblSelect.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblSelect.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblSelect.UseMnemonic = True
		Me.lblSelect.Visible = True
		Me.lblSelect.AutoSize = True
		Me.lblSelect.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.lblSelect.Name = "lblSelect"
		Me.fraDetection.Text = "Language detection"
		Me.fraDetection.Size = New System.Drawing.Size(425, 81)
		Me.fraDetection.Location = New System.Drawing.Point(8, 424)
		Me.fraDetection.TabIndex = 1
		Me.fraDetection.Tag = "frmLanguage.fraDetection"
		Me.fraDetection.BackColor = System.Drawing.SystemColors.Control
		Me.fraDetection.Enabled = True
		Me.fraDetection.ForeColor = System.Drawing.SystemColors.ControlText
		Me.fraDetection.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.fraDetection.Visible = True
		Me.fraDetection.Padding = New System.Windows.Forms.Padding(0)
		Me.fraDetection.Name = "fraDetection"
		Me.picDetection.Size = New System.Drawing.Size(409, 57)
		Me.picDetection.Location = New System.Drawing.Point(8, 16)
		Me.picDetection.TabIndex = 20
		Me.picDetection.Dock = System.Windows.Forms.DockStyle.None
		Me.picDetection.BackColor = System.Drawing.SystemColors.Control
		Me.picDetection.CausesValidation = True
		Me.picDetection.Enabled = True
		Me.picDetection.ForeColor = System.Drawing.SystemColors.ControlText
		Me.picDetection.Cursor = System.Windows.Forms.Cursors.Default
		Me.picDetection.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.picDetection.TabStop = True
		Me.picDetection.Visible = True
		Me.picDetection.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.picDetection.Name = "picDetection"
		Me._optDetect_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optDetect_1.Text = "Let WebbIE try to detect the correct language"
		Me._optDetect_1.Size = New System.Drawing.Size(401, 25)
		Me._optDetect_1.Location = New System.Drawing.Point(0, 24)
		Me._optDetect_1.TabIndex = 22
		Me._optDetect_1.Tag = "frmLanguage.optDetect(1)"
		Me._optDetect_1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optDetect_1.BackColor = System.Drawing.SystemColors.Control
		Me._optDetect_1.CausesValidation = True
		Me._optDetect_1.Enabled = True
		Me._optDetect_1.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optDetect_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._optDetect_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optDetect_1.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optDetect_1.TabStop = True
		Me._optDetect_1.Checked = False
		Me._optDetect_1.Visible = True
		Me._optDetect_1.Name = "_optDetect_1"
		Me._optDetect_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optDetect_0.Text = "Always use my default language"
		Me._optDetect_0.Size = New System.Drawing.Size(401, 25)
		Me._optDetect_0.Location = New System.Drawing.Point(0, 0)
		Me._optDetect_0.TabIndex = 21
		Me._optDetect_0.Tag = "frmLanguage.optDetect(0)"
		Me._optDetect_0.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
		Me._optDetect_0.BackColor = System.Drawing.SystemColors.Control
		Me._optDetect_0.CausesValidation = True
		Me._optDetect_0.Enabled = True
		Me._optDetect_0.ForeColor = System.Drawing.SystemColors.ControlText
		Me._optDetect_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._optDetect_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._optDetect_0.Appearance = System.Windows.Forms.Appearance.Normal
		Me._optDetect_0.TabStop = True
		Me._optDetect_0.Checked = False
		Me._optDetect_0.Visible = True
		Me._optDetect_0.Name = "_optDetect_0"
		Me.fraLanguage.Text = "Select correct language"
		Me.fraLanguage.Size = New System.Drawing.Size(425, 409)
		Me.fraLanguage.Location = New System.Drawing.Point(8, 8)
		Me.fraLanguage.TabIndex = 0
		Me.fraLanguage.Tag = "frmLanguage.fraLanguage"
		Me.fraLanguage.BackColor = System.Drawing.SystemColors.Control
		Me.fraLanguage.Enabled = True
		Me.fraLanguage.ForeColor = System.Drawing.SystemColors.ControlText
		Me.fraLanguage.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.fraLanguage.Visible = True
		Me.fraLanguage.Padding = New System.Windows.Forms.Padding(0)
		Me.fraLanguage.Name = "fraLanguage"
		Me.cmdCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.CancelButton = Me.cmdCancel
		Me.cmdCancel.Text = "Cancel"
		Me.cmdCancel.Size = New System.Drawing.Size(81, 33)
		Me.cmdCancel.Location = New System.Drawing.Point(224, 512)
		Me.cmdCancel.TabIndex = 3
		Me.cmdCancel.Tag = "frmLanguage.cmdCancel"
		Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
		Me.cmdCancel.CausesValidation = True
		Me.cmdCancel.Enabled = True
		Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdCancel.TabStop = True
		Me.cmdCancel.Name = "cmdCancel"
		Me.cmdOK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.cmdOK.Text = "OK"
		Me.AcceptButton = Me.cmdOK
		Me.cmdOK.Size = New System.Drawing.Size(81, 33)
		Me.cmdOK.Location = New System.Drawing.Point(120, 512)
		Me.cmdOK.TabIndex = 2
		Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
		Me.cmdOK.CausesValidation = True
		Me.cmdOK.Enabled = True
		Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdOK.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdOK.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdOK.TabStop = True
		Me.cmdOK.Name = "cmdOK"
		Me.Controls.Add(picLanguage)
		Me.Controls.Add(fraDetection)
		Me.Controls.Add(fraLanguage)
		Me.Controls.Add(cmdCancel)
		Me.Controls.Add(cmdOK)
		Me.picLanguage.Controls.Add(_optLanguage_0)
		Me.picLanguage.Controls.Add(_optLanguage_2)
		Me.picLanguage.Controls.Add(_optLanguage_1)
		Me.picLanguage.Controls.Add(_optLanguage_3)
		Me.picLanguage.Controls.Add(_optLanguage_4)
		Me.picLanguage.Controls.Add(_optLanguage_5)
		Me.picLanguage.Controls.Add(_optLanguage_6)
		Me.picLanguage.Controls.Add(_optLanguage_7)
		Me.picLanguage.Controls.Add(_optLanguage_8)
		Me.picLanguage.Controls.Add(_optLanguage_9)
		Me.picLanguage.Controls.Add(_optLanguage_11)
		Me.picLanguage.Controls.Add(_optLanguage_13)
		Me.picLanguage.Controls.Add(_optLanguage_12)
		Me.picLanguage.Controls.Add(_optLanguage_10)
		Me.picLanguage.Controls.Add(lblSelect)
		Me.fraDetection.Controls.Add(picDetection)
		Me.picDetection.Controls.Add(_optDetect_1)
		Me.picDetection.Controls.Add(_optDetect_0)
		Me.optDetect.SetIndex(_optDetect_1, CType(1, Short))
		Me.optDetect.SetIndex(_optDetect_0, CType(0, Short))
		Me.optLanguage.SetIndex(_optLanguage_0, CType(0, Short))
		Me.optLanguage.SetIndex(_optLanguage_2, CType(2, Short))
		Me.optLanguage.SetIndex(_optLanguage_1, CType(1, Short))
		Me.optLanguage.SetIndex(_optLanguage_3, CType(3, Short))
		Me.optLanguage.SetIndex(_optLanguage_4, CType(4, Short))
		Me.optLanguage.SetIndex(_optLanguage_5, CType(5, Short))
		Me.optLanguage.SetIndex(_optLanguage_6, CType(6, Short))
		Me.optLanguage.SetIndex(_optLanguage_7, CType(7, Short))
		Me.optLanguage.SetIndex(_optLanguage_8, CType(8, Short))
		Me.optLanguage.SetIndex(_optLanguage_9, CType(9, Short))
		Me.optLanguage.SetIndex(_optLanguage_11, CType(11, Short))
		Me.optLanguage.SetIndex(_optLanguage_13, CType(13, Short))
		Me.optLanguage.SetIndex(_optLanguage_12, CType(12, Short))
		Me.optLanguage.SetIndex(_optLanguage_10, CType(10, Short))
		CType(Me.optLanguage, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.optDetect, System.ComponentModel.ISupportInitialize).EndInit()
		Me.picLanguage.ResumeLayout(False)
		Me.fraDetection.ResumeLayout(False)
		Me.picDetection.ResumeLayout(False)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class