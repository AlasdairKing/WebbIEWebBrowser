Option Strict On
Option Explicit On
Module modAPIFunctions
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	Private Declare Function RegOpenKeyEx Lib "advapi32.dll"  Alias "RegOpenKeyExA"(ByVal hKey As Integer, ByVal lpSubKey As String, ByVal ulOptions As Integer, ByVal samDesired As Integer, ByRef phkResult As Integer) As Integer
	'open a key for reading or writing
	
	
	Public Sub Scroll(ByRef editControl As System.Windows.Forms.Control, ByRef lines As Integer)
		'scrolls the editControl textbox by lines lines
		' editControl - the current control
		' lines - the number of lines to scroll
		On Error Resume Next
		Call SendMessageW(editControl.Handle.ToInt32, EM_LINESCROLL, 0, lines)
	End Sub
	
	Public Sub ScrollToCursor(ByRef editControl As System.Windows.Forms.Control)
		'scrolls the editControl textbox to where the cursor is now
		' editControl - the current control
		On Error Resume Next
		Call SendMessageW(editControl.Handle.ToInt32, EM_SCROLLCARET, 0, 0)
	End Sub
	
    Public Function GetCurrentLine(ByRef editControl As System.Windows.Forms.TextBox) As String
        'returns the text on the current line from the current control
        '   editControl - the current control
        '   charPos - the position of the cursor in the control
        On Error Resume Next
        Dim lineNumber As Integer ' the line number of the current line
        'get the line number: arguments of -1 mean "line with caret", 0 is not used
        lineNumber = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_LINEFROMCHAR, -1, 0)
        Return editControl.Lines(lineNumber)
    End Function
	
    Public Function GetCurrentLineIndex(ByRef editControl As System.Windows.Forms.TextBox) As Integer
        On Error Resume Next
        'returns the number of the current line indicated by the cursor NUMBERED FROM 0!
        'get the line number: arguments of -1 mean "line with caret", 0 is not used
        GetCurrentLineIndex = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_LINEFROMCHAR, -1, 0)
    End Function
	
    Public Function SetCurrentLineIndex(ByRef editControl As System.Windows.Forms.TextBox, ByRef line As Integer) As Object
        On Error Resume Next
        'sets the caret to the line numbered line
        Dim charIndex As Integer
        'get the character index of line
        charIndex = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_LINEINDEX, line, 0)
        editControl.SelectionStart = charIndex
        editControl.SelectionLength = 0
    End Function
	
    Public Function GetNumberedLine(ByRef editControl As System.Windows.Forms.TextBox, ByRef lineNumber As Integer) As String
        'returns the numbered line
        On Error Resume Next
        Return editControl.Lines(lineNumber)
    End Function
	
    Public Function GetNumberOfLines(ByRef editControl As System.Windows.Forms.TextBox) As Integer
        'returns the number of lines in the control
        On Error Resume Next
        'UPGRADE_WARNING: Couldn't resolve default property of object editControl.hwnd. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        GetNumberOfLines = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_GETLINECOUNT, 0, 0)
    End Function
	
    Public Function GetCharacterIndexOfLine(ByRef editControl As System.Windows.Forms.TextBox, ByRef lineNumber As Integer) As Integer
        'returns the number of characters in the control up to the numbered line
        On Error Resume Next
        'UPGRADE_WARNING: Couldn't resolve default property of object editControl.hwnd. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        GetCharacterIndexOfLine = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_LINEINDEX, lineNumber, 0)
    End Function
	
	Public Sub SetImagesOnOrOffInIE(ByRef State As Boolean)
		'put image loading in ie in the registry back to its original setting on leaving WebbIE
		'state is determined by blnIEImages
        On Error Resume Next
        Dim regKey As Microsoft.Win32.RegistryKey
        Dim stateString As String

        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\Internet Explorer\Main", True)
        If State Then
            stateString = "yes"
        Else
            stateString = "no"
        End If
        Call regKey.SetValue("Display Inline Images", stateString)
        Call regKey.Close()
	End Sub
	
	Public Function GetImagesOnOrOffInIE() As Boolean
        On Error Resume Next
        Dim regKey As Microsoft.Win32.RegistryKey
        Dim stateString As String

        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\Internet Explorer\Main", False)
        stateString = regKey.GetValue("Display Inline images").ToString
        regKey.Close()
        If LCase(stateString) = "yes" Then
            Return True
        Else
            Return False
        End If
    End Function
End Module