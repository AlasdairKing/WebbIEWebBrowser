Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmTextView
	Inherits System.Windows.Forms.Form
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	Public targetForm As frmMain
	
	Private Sub cmdOK_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOK.Click
		On Error Resume Next
		Call Me.Hide()
	End Sub
	
	'UPGRADE_WARNING: Form event frmTextView.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
	Private Sub frmTextView_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		On Error Resume Next
		Dim cursorPosition As Integer
		Dim selectLength As Integer
		txtTextView.Font = targetForm.txtText.Font
	End Sub
	
	'UPGRADE_WARNING: Event frmTextView.Resize may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub frmTextView_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
		On Error Resume Next
		If VB6.PixelsToTwipsX(Me.Width) < 1000 Then Exit Sub
		If VB6.PixelsToTwipsY(Me.Height) < 1000 Then Exit Sub
		txtTextView.Width = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - 100)
		cmdOK.Top = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - 1400)
		txtTextView.Height = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(cmdOK.Top) - 300)
		cmdOK.Left = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) / 2 - VB6.PixelsToTwipsX(cmdOK.Width) / 2)
	End Sub
	
	Public Sub mnuEditCopy_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditCopy.Click
		On Error Resume Next
		If txtTextView.SelectedText <> "" Then ' only copy if we have something selected
			Call My.Computer.Clipboard.Clear()
			Call My.Computer.Clipboard.SetText(txtTextView.SelectedText)
		End If
	End Sub
	
	Public Sub mnuEditCut_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditCut.Click
		On Error Resume Next
		Dim selStart As Integer
		Call My.Computer.Clipboard.Clear()
		Call My.Computer.Clipboard.SetText(txtTextView.SelectedText)
		selStart = txtTextView.SelectionStart
		txtTextView.Text = VB.Left(txtTextView.Text, txtTextView.SelectionStart) & VB.Right(txtTextView.Text, Len(txtTextView.Text) - txtTextView.SelectionStart - txtTextView.SelectionLength)
		txtTextView.SelectionStart = selStart
		Call ScrollToCursor(txtTextView)
	End Sub
	
	Public Sub mnuEditFind_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditFind.Click
		On Error Resume Next
		Dim where As Integer
		
		findText = InputBox(modI18N.GetText("Enter text to find"), modI18N.GetText("Search string") & ":", findText)
		'if OK is clicked
		If findText <> "" Then
			' Find string in text
			where = InStr(1, txtTextView.Text, findText, CompareMethod.Text)
			If where Then ' If found..
				txtTextView.Focus()
				txtTextView.SelectionStart = where - 1 ' set selection start and
				txtTextView.SelectionLength = Len(findText) ' set selection length
				Call ScrollToCursor(txtTextView)
			Else
				MsgBox(modI18N.GetText("Text not found"), MsgBoxStyle.Information, modI18N.GetText("Not found"))
			End If
		End If
	End Sub
	
	Public Sub mnuEditFindnext_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditFindnext.Click
		On Error Resume Next
		Dim where As Integer
		Dim originalPos As Integer
		
		If txtTextView.Text <> "" Then
			originalPos = txtTextView.SelectionStart 'go to start of the found word
			'make lower case and search onwards from the existing word
			where = InStr(LCase(Mid(txtTextView.Text, txtTextView.SelectionStart + 2, Len(txtTextView.Text) - (txtTextView.SelectionStart + 2))), findText)
			If where Then 'if found
				where = where + originalPos
				txtTextView.SelectionStart = where
				txtTextView.SelectionLength = Len(findText) 'highlight the word
				Call ScrollToCursor(txtTextView)
			Else
				'if unfound, display a warning
				MsgBox(modI18N.GetText("No further occurrences found"), MsgBoxStyle.Information, modI18N.GetText("Text not found"))
			End If
		Else 'if there is no text to search
			Call PlayErrorSound()
		End If
	End Sub
	
	Public Sub mnuEditSelectall_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuEditSelectall.Click
		On Error Resume Next
		txtTextView.SelectionStart = 0
		txtTextView.SelectionLength = Len(txtTextView.Text)
		Call ScrollToCursor(txtTextView)
	End Sub
	
	Public Sub mnuFileClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuFileClose.Click
		On Error Resume Next
		Call cmdOK_Click(cmdOK, New System.EventArgs())
	End Sub
	
	Private Sub txtTextView_KeyUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles txtTextView.KeyUp
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		On Error Resume Next
		If txtTextView.SelectedText <> "" Then
			mnuEditCopy.Enabled = True
		Else
			mnuEditCopy.Enabled = False
		End If
	End Sub
	
	
	Private Sub txtTextView_MouseUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles txtTextView.MouseUp
		Dim Button As Short = eventArgs.Button \ &H100000
		Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
		Dim X As Single = VB6.PixelsToTwipsX(eventArgs.X)
		Dim Y As Single = VB6.PixelsToTwipsY(eventArgs.Y)
		On Error Resume Next
		'process a mouse action like a key action - check for a selected area.
		Call txtTextView_KeyUp(txtTextView, New System.Windows.Forms.KeyEventArgs(0 Or 0 * &H10000))
	End Sub
End Class