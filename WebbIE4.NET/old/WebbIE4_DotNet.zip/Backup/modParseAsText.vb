Option Strict Off
Option Explicit On
Module modParseAsText
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	Private gstrNewline As String
	Private gHadSomeText As Boolean
	
	Public Function ParseDocs() As String
		On Error Resume Next
		Dim got() As String
		Dim keep() As Boolean
		Dim found As String
		Dim i As Integer
		Dim o As Object
		Dim j As Integer
		Dim lineOK As Boolean
		Dim charValue As Short
		Dim words() As String
		
		modParseAsText.gHadSomeText = False
		modParseAsText.gstrNewline = ""
		
        If blnAlwaysUseUserDefaultLanguage Then
            ParseDocs = modI18N.GetText("WEBPAGE:") & " " & frmMain.mWebBrowser.Document.DomDocument.title.ToString
        Else
            ParseDocs = modI18N.GetText("WEBPAGE:") & " " & frmMain.mWebBrowser.Document.DomDocument.title.ToString
        End If

		ParseDocs = ParseDocs & vbNewLine & vbNewLine
		'UPGRADE_WARNING: Couldn't resolve default property of object frmMain.mWebBrowser.Document.documentElement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		ParseDocs = ParseDocs & ParseNodeText(frmMain.mWebBrowser.Document.DomDocument.documentElement)
		'now truncate ParseDocs to remove blank lines and links that aren't part
		'of text.
		'Unless, of course, ParseDocs didn't work.
		If ParseDocs = "" Then
		Else
			'First split into array by line
			got = Split(ParseDocs, vbNewLine)
			'UPGRADE_WARNING: Lower bound of array keep was changed from LBound(got) to 0. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="0F1C9BE1-AF9D-476E-83B1-17D43BECFF20"'
			ReDim keep(UBound(got))
			'Now process through array deciding what lines to keep
			For i = LBound(got) To UBound(got)
				found = got(i)
				If Len(Replace(found, " ", "")) > 0 Then keep(i) = True
			Next i
			'Remove crap at top of page by removing lines with no ANSI text.
			For i = LBound(got) To UBound(got)
				found = Trim(got(i))
				lineOK = False
				For j = 1 To Len(found)
					charValue = Asc(Mid(found, j, 1))
					'Debug.Print "Checking " & charValue
					If ((charValue > 47 And charValue < 58) Or (charValue > 64 And charValue < 91) Or charValue > 96) And charValue <> 124 And charValue <> 183 Then
						'a real character, OK: can keep line.
						lineOK = True
						Exit For
					Else
						'Debug.Print "Fake:[" & charValue & "]"
					End If
				Next j
				If lineOK Then
					'we've found a valid line, so quit the remove crap loop
					'No, on second thoughts: strip out all the crap lines.
					'Exit For
				Else
					'line is crap
					keep(i) = False
				End If
			Next i
			'now take out the remains of navigation links at the top of the page by taking
			'out single-word lines
			For i = LBound(got) To UBound(got)
				If keep(i) Then
					'okay, this line contains valid stuff: is it more than one word long?
					words = Split(got(i), " ")
					If UBound(words) > 0 Then
						'okay, we've found the start of the page content.
						Exit For
					Else
						'nope, only one word: not the start of the page
						'content yet.
						keep(i) = False
					End If
				End If
			Next i
			ParseDocs = ""
			For i = LBound(got) To UBound(got)
				If keep(i) Then ParseDocs = ParseDocs & got(i) & vbNewLine
			Next i
			'take out errant spaces
			ParseDocs = Replace(ParseDocs, " ,", ",")
			ParseDocs = Replace(ParseDocs, " .", ".")
		End If
	End Function
	
	
	Private Function ParseNodeText(ByRef element As mshtml.IHTMLDOMNode) As String
		'processes a document html node and all of its children and siblings (by calling itself.
		'Outputs results to output, which it returns
		' gstrnewline is either Empty or vbNewline, and should be set accordingly
		On Error Resume Next
		
		Dim tagname As String ' the HTML element name
		Dim label As String
        Dim output As String = "" ' the result of the parsing
		'Dim htmlE As IHTMLElement ' the node as an IHTMLElement object, lets us get more stuff
		Dim linkContent As String ' the content of an a element to display
		Dim elementIterator As mshtml.IHTMLDOMNode ' used to iterate through any further node collections
		Dim nodeIterator As mshtml.IHTMLDOMNode
		Dim nodeIterator2 As mshtml.IHTMLDOMNode ' used to iterate again
		Dim i As Short ' counter
		Dim trimmedText As String ' used to strip spare spaces out of text
		Dim revText As String ' reversed text
		Dim parentElement As mshtml.IHTMLDOMNode
		
		tagname = element.nodeName
		linkContent = ""
		'attempt to speed things up
		'Debug.Print "Nodetype:" & element.nodeType
		If element.nodeType = TEXT_NODE Then
			'get rid of whitespace at end/start of line, INCLUDING non-breaking whitespace (Unicode
			'   value 160, NBSP)
			trimmedText = Trim(Replace(element.nodeValue, Chr(160), " "))
			output = Replace(trimmedText, vbCr, vbNewLine) & " "
			gstrNewline = vbNewLine
			If Len(trimmedText) > 25 Then gHadSomeText = True
			'UPGRADE_WARNING: Couldn't resolve default property of object element.currentStyle. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		ElseIf element.currentStyle.display = "none" Then  'check displayed
			'don't display this element at all! And don't do kids!
		ElseIf tagname = "A" Then 
			'Don't do link content until we have some non-link text
			If gHadSomeText Then
				'okay, this is a link: does it make up all the content of the containing
				'element, and if so, don't display it.
				parentElement = element.parentNode
				'UPGRADE_WARNING: Couldn't resolve default property of object element.innerText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object parentElement.innerText. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If Len(parentElement.innerText) <= Len(element.innerText) + 5 Then
					'don't display! Probably a link in a list
					'Debug.Print "Nope"
				Else
					'okay, go ahead and display
					For	Each elementIterator In element.childNodes
						output = output & ParseNodeText(elementIterator)
					Next elementIterator
				End If
			End If
		ElseIf tagname = "IMG" Then 
			'Don't show images
		ElseIf tagname = "SELECT" Then 
			'don't show select
		ElseIf tagname = "INPUT" Then 
			'Don't show input
		ElseIf tagname = "BUTTON" Then 
			'Don't show button
		ElseIf tagname = "TEXTAREA" Then 
			'Don't show textarea
		ElseIf tagname = "HEAD" Then 
			'Don't do HEAD
		ElseIf tagname = "OL" Then 
			'an ordered list
			i = 1
			If element.hasChildNodes Then
				For	Each elementIterator In element.childNodes
					output = output & i & " "
					gstrNewline = vbNewLine
					output = output & ParseNodeText(elementIterator)
					i = i + 1
				Next elementIterator
			End If
		ElseIf tagname = "HR" Then 
			'a horizontal rule: don't think I'll do this.
			'        Set frmDummy.Font = frmMain.txtText.Font
			'        For i = 1 To (frmMain.txtText.width / frmDummy.TextWidth("_") - 4)
			'            output = output & "_"
			'        Next i
			'        output = output & vbNewLine
			'        gstrNewline = ""
		ElseIf tagname = "AREA" Then 
			'Don't show
		ElseIf tagname = "BLOCKQUOTE" Then 
			'a quotation
			output = output & gstrNewline & modI18N.GetText("[quotation marks]")
			gstrNewline = vbNewLine
			If element.hasChildNodes Then
				For	Each elementIterator In element.childNodes
					output = output & ParseNodeText(elementIterator)
				Next elementIterator
			End If
			output = RTrim(output)
			On Error GoTo SkipBlockquoteWhile
			While Right(output, 2) = vbNewLine
				output = Left(output, Len(output) - 2)
			End While
SkipBlockquoteWhile: 
			On Error Resume Next
			output = output & modI18N.GetText("[quotation marks]") & vbNewLine
			gstrNewline = ""
		ElseIf tagname = "OBJECT" Or tagname = "APPLET" Then 
			'Don't show objects
		ElseIf tagname = "STYLE" Then 
			'content for browser - not intended for user to see
		ElseIf tagname = "DEL" Then 
			'deleted content - don't do any of it or it's child nodes!
		ElseIf tagname = "LABEL" Then 
			'Don't show labels
		ElseIf tagname = "IFRAME" Then 
			'internal frame - used for non-frame-supporting browsers - WebbIE does support frames,
			'so don't show any content (see HTML4.0 spec)
		ElseIf tagname = "BDO" Then 
			'set-direction text - right-to-left or left-to-right
			'UPGRADE_WARNING: Couldn't resolve default property of object element.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			If element.attributes.getNamedItem("dir").nodeValue = "ltr" Then
				'"normal" left-to-right direction - process as "normal" text
				If element.hasChildNodes Then
					For	Each elementIterator In element.childNodes
						output = output & ParseNodeText(elementIterator)
					Next elementIterator
				End If
			Else
				'reversed right-to-left direction
				linkContent = ""
				If element.hasChildNodes Then
					For	Each elementIterator In element.childNodes
						linkContent = linkContent & ParseNodeText(elementIterator)
					Next elementIterator
				End If
				i = Len(linkContent)
				While i > 0
					If Mid(linkContent, i, 1) = vbLf Then
						'we've found a newline (CR + LF)
						output = output & vbNewLine
						gstrNewline = ""
						i = i - 2
					Else
						'normal character - add to output
						output = output & Mid(linkContent, i, 1)
						gstrNewline = vbNewLine
						i = i - 1
					End If
				End While
			End If
			'ElseIf tagname = "FORM" Then
			'don't do form
			'No, not doing forms doesn't work, because discussion pages (e.g. blogs) can encapsulate all their content in FORM
			'elements. 3.8.0 Jan 2009.
			'don't do the sub-kids of an A node, an INPUT node, a FRAME node, an IMG node...
		Else
			If tagname = "Q" Then
				output = output & modI18N.GetText("[quotation marks]")
				gstrNewline = vbNewLine
			ElseIf tagname = "TABLE" Then 
				'UPGRADE_WARNING: Couldn't resolve default property of object element.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If element.attributes.getNamedItem("summary").nodeValue <> "" Then
					'UPGRADE_WARNING: Couldn't resolve default property of object element.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					output = output & gstrNewline & ID_TABLE & ": " & element.attributes.getNamedItem("summary").nodeValue & vbNewLine
					gstrNewline = ""
				End If
			ElseIf tagname = "H1" Then 
				output = output & gstrNewline & SECTION_MARKER_H1 & ": "
				gstrNewline = vbNewLine
			ElseIf tagname = "H2" Then 
				output = output & gstrNewline & SECTION_MARKER_H2 & ": "
				gstrNewline = vbNewLine
			ElseIf tagname = "H3" Then 
				output = output & gstrNewline & SECTION_MARKER_H3 & ": "
				gstrNewline = vbNewLine
			ElseIf tagname = "H4" Then 
				output = output & gstrNewline & SECTION_MARKER_H4 & ": "
				gstrNewline = vbNewLine
			ElseIf tagname = "H5" Then 
				output = output & gstrNewline & SECTION_MARKER_H5 & ": "
				gstrNewline = vbNewLine
			ElseIf tagname = "H6" Then 
				output = output & gstrNewline & SECTION_MARKER_H6 & ": "
				gstrNewline = vbNewLine
			End If
			If element.hasChildNodes Then
				For	Each elementIterator In element.childNodes
					output = output & ParseNodeText(elementIterator)
				Next elementIterator
			End If
			'UPGRADE_NOTE: Object elementIterator may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
			elementIterator = Nothing
			'do newline if the element is one requiring a newline
			If (tagname = "BR" Or tagname = "P" Or tagname = "H1" Or tagname = "H2" Or tagname = "H3" Or tagname = "H4" Or tagname = "H5" Or tagname = "H6" Or tagname = "ADDRESS" Or tagname = "CENTER" Or tagname = "PRE" Or tagname = "TABLE" Or tagname = "TR" Or tagname = "CAPTION" Or tagname = "DIV") And gstrNewline = vbNewLine Then
				output = output & vbNewLine
				gstrNewline = ""
			ElseIf tagname = "TD" Or tagname = "TH" Then 
				output = output & " "
				gstrNewline = vbNewLine
			ElseIf tagname = "Q" Then 
				If Right(output, 1) = " " Then output = Left(output, Len(output) - 1)
				output = output & modI18N.GetText("[quotation marks]")
				gstrNewline = vbNewLine
			End If
		End If
		ParseNodeText = output
	End Function
End Module