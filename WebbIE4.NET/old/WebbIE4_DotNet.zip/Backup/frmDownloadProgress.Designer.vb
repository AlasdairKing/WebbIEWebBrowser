<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmDownloadProgress
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents tmrProgressSound As System.Windows.Forms.Timer
	Public WithEvents cmdCancel As System.Windows.Forms.Button
	Public WithEvents progressBar As System.Windows.Forms.ProgressBar
	Public WithEvents lblDownloading As System.Windows.Forms.Label
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmDownloadProgress))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.tmrProgressSound = New System.Windows.Forms.Timer(components)
		Me.cmdCancel = New System.Windows.Forms.Button
		Me.progressBar = New System.Windows.Forms.ProgressBar
		Me.lblDownloading = New System.Windows.Forms.Label
		Me.SuspendLayout()
		Me.ToolTip1.Active = True
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
		Me.Text = "Downloading"
		Me.ClientSize = New System.Drawing.Size(436, 126)
		Me.Location = New System.Drawing.Point(3, 15)
		Me.ControlBox = False
		Me.Icon = CType(resources.GetObject("frmDownloadProgress.Icon"), System.Drawing.Icon)
		Me.KeyPreview = True
		Me.MaximizeBox = False
		Me.MinimizeBox = False
		Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
		Me.Tag = "frmDownloadProgress"
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.BackColor = System.Drawing.SystemColors.Control
		Me.Enabled = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmDownloadProgress"
		Me.tmrProgressSound.Interval = 1500
		Me.tmrProgressSound.Enabled = True
		Me.cmdCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		Me.CancelButton = Me.cmdCancel
		Me.cmdCancel.Text = "Cancel"
		Me.AcceptButton = Me.cmdCancel
		Me.cmdCancel.Size = New System.Drawing.Size(81, 33)
		Me.cmdCancel.Location = New System.Drawing.Point(176, 88)
		Me.cmdCancel.TabIndex = 1
		Me.cmdCancel.Tag = "frmDownloadProgress.cmdCancel"
		Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
		Me.cmdCancel.CausesValidation = True
		Me.cmdCancel.Enabled = True
		Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
		Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
		Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.cmdCancel.TabStop = True
		Me.cmdCancel.Name = "cmdCancel"
		Me.progressBar.Size = New System.Drawing.Size(425, 25)
		Me.progressBar.Location = New System.Drawing.Point(8, 56)
		Me.progressBar.TabIndex = 0
		Me.progressBar.Name = "progressBar"
		Me.lblDownloading.Text = "Downloading"
		Me.lblDownloading.Size = New System.Drawing.Size(3, 1)
		Me.lblDownloading.Location = New System.Drawing.Point(16, 8)
		Me.lblDownloading.TabIndex = 2
		Me.lblDownloading.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.lblDownloading.BackColor = System.Drawing.SystemColors.Control
		Me.lblDownloading.Enabled = True
		Me.lblDownloading.ForeColor = System.Drawing.SystemColors.ControlText
		Me.lblDownloading.Cursor = System.Windows.Forms.Cursors.Default
		Me.lblDownloading.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.lblDownloading.UseMnemonic = True
		Me.lblDownloading.Visible = True
		Me.lblDownloading.AutoSize = True
		Me.lblDownloading.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.lblDownloading.Name = "lblDownloading"
		Me.Controls.Add(cmdCancel)
		Me.Controls.Add(progressBar)
		Me.Controls.Add(lblDownloading)
		Me.ResumeLayout(False)
		Me.PerformLayout()
	End Sub
#End Region 
End Class