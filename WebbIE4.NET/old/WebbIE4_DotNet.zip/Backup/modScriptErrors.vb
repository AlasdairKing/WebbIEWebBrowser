Option Strict Off
Option Explicit On
Module modScriptErrors
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'modScriptErrors
	'This module turns off IE script errors in the registry, and restores their state when the program
	'closes. Prevents all those annoying script errors popping up in WebbIE.
	
	
	Private mDisableScriptDebugger As String
	Private mDisableScriptDebuggerIE As String
	Private mErrorDlgDisplayedOnEveryError As String
	
	Private Declare Function RegOpenKeyEx Lib "advapi32.dll"  Alias "RegOpenKeyExA"(ByVal hKey As Integer, ByVal lpSubKey As String, ByVal ulOptions As Integer, ByVal samDesired As Integer, ByRef phkResult As Integer) As Integer
	'open a key for reading or writing
	
	
	Public Sub DisableScriptErrors()
		'Turn off all script errors after recording their values.
        On Error Resume Next
        Dim regKey As Microsoft.Win32.RegistryKey
        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\Internet Explorer\Main", True)
        mDisableScriptDebugger = regKey.GetValue("Disable Script Debugger")
        Call regKey.SetValue("Disable Script Debugger", "yes")
        mDisableScriptDebuggerIE = regKey.GetValue("DisableScriptDebuggerIE")
        Call regKey.SetValue("DisableScriptDebuggerIE", "yes")
        mErrorDlgDisplayedOnEveryError = regKey.GetValue("Error Dlg Displayed On Every Error")
        Call regKey.SetValue("Error Dlg Displayed On Every Error", "no")
        Call regKey.Close()
	End Sub
	
	Public Sub RestoreScriptErrors()
        'Restore script error settings to what they were when DisableScriptErrors was called.
        Dim regKey As Microsoft.Win32.RegistryKey
        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\Internet Explorer\Main", True)
        If Len(mDisableScriptDebugger) > 0 Then Call regKey.SetValue("Disable Script Debugger", mDisableScriptDebugger)
        If Len(mDisableScriptDebuggerIE) > 0 Then Call regKey.SetValue("DisableScriptDebuggerIE", mDisableScriptDebuggerIE)
        If Len(mErrorDlgDisplayedOnEveryError) > 0 Then Call regKey.SetValue("Error Dlg Displayed On Every Error", mErrorDlgDisplayedOnEveryError)
        regKey.Close()
	End Sub
	
End Module