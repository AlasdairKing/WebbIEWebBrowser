Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmLinks
	Inherits System.Windows.Forms.Form
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	Public targetForm As frmMain
	
	Private Sub cmdCloseLinks_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCloseLinks.Click
		On Error Resume Next
		cmdGo.Enabled = False
		Call Me.Hide()
	End Sub
	
	Private Sub cmdGo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdGo.Click
		On Error Resume Next
		Dim selection As Short
		
		selection = lstLinks.SelectedIndex
		If selection = -1 Then
			'nothing selected - don't do anything
		Else
			If (optSort(0).Checked) Then
				'targetForm.cboAddress.Text = links(selection + 1).address
				Call targetForm.StartNavigating(links(selection + 1).address)
			Else
				'targetForm.cboAddress.Text = sortedLinks(selection + 1).address
				Call targetForm.StartNavigating(sortedLinks(selection + 1).address)
			End If
			Call Me.Hide()
		End If
	End Sub
	
	
	'UPGRADE_WARNING: Form event frmLinks.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
	Private Sub frmLinks_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
		On Error Resume Next
		lstLinks.Font = Me.targetForm.txtText.Font
		If lstLinks.SelectedIndex > -1 Then
			cmdGo.Enabled = True
		End If
	End Sub
	
	Private Sub frmLinks_KeyUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
		Dim KeyCode As Short = eventArgs.KeyCode
		Dim Shift As Short = eventArgs.KeyData \ &H10000
		'see if user has pressed ALT-A or ALT-P to change order
		On Error Resume Next
		'    If KeyCode = vbKeyEscape Then Me.Hide
	End Sub
	
	Private Sub frmLinks_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		On Error Resume Next
        Me.lblLinks.TabIndex = 0
		Me.lstLinks.TabIndex = 1
		Me.optSort(0).TabIndex = 2
		Me.optSort(1).TabIndex = 3
		Me.cmdGo.TabIndex = 4
		Me.cmdCloseLinks.TabIndex = 5
	End Sub
	
	'UPGRADE_WARNING: Event frmLinks.Resize may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub frmLinks_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
		On Error Resume Next
		If VB6.PixelsToTwipsX(Me.Width) < 6200 Then Exit Sub
		If VB6.PixelsToTwipsY(Me.Height) < 2800 Then Exit Sub
		lstLinks.Left = VB6.TwipsToPixelsX(gintFormMargin)
		lstLinks.Width = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - gintFormMargin * 2)
		lstLinks.Top = VB6.TwipsToPixelsY(gintFormMargin)
		optSort(0).Top = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - gintFormMargin - VB6.PixelsToTwipsY(optSort(0).Height) - gintFormMargin - VB6.PixelsToTwipsY(optSort(1).Height) - gintOffset)
		lstLinks.Height = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(optSort(0).Top) - gintFormMargin * 2)
		optSort(1).Top = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(optSort(0).Top) + gintFormMargin + VB6.PixelsToTwipsY(optSort(0).Height))
		cmdGo.Top = VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(Me.Height) - VB6.PixelsToTwipsY(cmdGo.Height) - gintFormMargin - gintOffset - 200)
		cmdCloseLinks.Top = cmdGo.Top
		cmdGo.Left = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(Me.Width) - VB6.PixelsToTwipsX(cmdCloseLinks.Width) - VB6.PixelsToTwipsX(cmdGo.Width) - gintFormMargin * 2 - 300)
		cmdCloseLinks.Left = VB6.TwipsToPixelsX(VB6.PixelsToTwipsX(cmdGo.Left) + gintFormMargin + VB6.PixelsToTwipsX(cmdGo.Width) + gintFormMargin)
	End Sub
	
    'UPGRADE_WARNING: Event lstLinks.SelectedIndexChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub lstLinks_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstLinks.SelectedIndexChanged
		On Error Resume Next
		cmdGo.Enabled = True
	End Sub
	
	Private Sub lstLinks_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstLinks.DoubleClick
		On Error Resume Next
		cmdGo_Click(cmdGo, New System.EventArgs())
	End Sub
	
	Private Sub lstLinks_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles lstLinks.KeyPress
		Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
		On Error Resume Next
		'    If (KeyAscii = vbKeyReturn) Then
		'        cmdGo_Click
		'    End If
		eventArgs.KeyChar = Chr(KeyAscii)
		If KeyAscii = 0 Then
			eventArgs.Handled = True
		End If
	End Sub
	
	Public Sub PopulateList(Optional ByRef newList As Boolean = True)
		On Error Resume Next
		Dim i As Short
		Dim address As String
        Dim currentAddress As String = "" ' the current url selected, if any
		
		If lstLinks.SelectedIndex = -1 Then
			'no selected link
		Else
			'we have a selected link: remember what it is for when we change link
			'order so it can remain the selected link.
			currentAddress = VB6.GetItemString(lstLinks, lstLinks.SelectedIndex)
		End If
		Call lstLinks.Items.Clear()
		
		If optSort(0).Checked Then
			'page order
			For i = 1 To numLinks
				address = links(i).address
				If InStr(1, address, "//") > 0 Then
					address = VB.Right(address, Len(address) - InStr(1, address, "//") - 1)
				End If
                Call lstLinks.Items.Add(links(i).description & " - " & address)
                'check to see if this link we have just added was the current link
				'If so, make it the selected link
				If VB6.GetItemString(lstLinks, lstLinks.Items.Count - 1) = currentAddress Then
					'found it!
					lstLinks.SelectedIndex = lstLinks.Items.Count - 1
				End If
			Next i
		Else
			'alphabetical order
			For i = 1 To numLinks
				address = sortedLinks(i).address
				If InStr(1, address, "//") > 0 Then
					address = VB.Right(address, Len(address) - InStr(1, address, "//") - 1)
				End If
#If UNICONTROL_STATE = DONT_USE_UNICONTROLS Then
				'UPGRADE_NOTE: #If #EndIf block was not upgraded because the expression UNICONTROL_STATE = DONT_USE_UNICONTROLS did not evaluate to True or was not evaluated. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="27EE2C3C-05AF-4C04-B2AF-657B4FB6B5FC"'
				Call lstLinks.AddItem(StrConv(StrConv(sortedLinks(i).description, vbFromUnicode, lngPageLocale), vbUnicode, LOCALE_WESTERN_EUROPEAN) + " - " + address)
#End If
#If UNICONTROL_STATE = USE_UNICONTROLS Then
				Call lstLinks.Items.Add(sortedLinks(i).description & " - " & address)
#End If
				'check to see if this link we have just added was the current link
				'If so, make it the selected link
				If VB6.GetItemString(lstLinks, lstLinks.Items.Count - 1) = currentAddress Then
					'found it!
					lstLinks.SelectedIndex = lstLinks.Items.Count - 1
				End If
			Next i
		End If
		If newList Or lstLinks.SelectedIndex = -1 Then
			lstLinks.SelectedIndex = 0
		End If
	End Sub
	
	'UPGRADE_WARNING: Event optSort.CheckedChanged may fire when form is initialized. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="88B12AE1-6DE0-48A0-86F1-60C0686C026A"'
	Private Sub optSort_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles optSort.CheckedChanged
		If eventSender.Checked Then
			Dim index As Short = optSort.GetIndex(eventSender)
			On Error Resume Next
			Call PopulateList(False)
			Call lstLinks.Focus()
		End If
	End Sub
End Class