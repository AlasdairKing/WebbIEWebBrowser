Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmParseHTMLHelp
	Inherits System.Windows.Forms.Form
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'frmParseHTMLHelp
	
	
	Private Const Document As Integer = 0
	Private mTitle As String
	
	Public Function ConvertHTMLHelp(ByRef Path As String) As String
		On Error Resume Next
		Dim fso As Scripting.FileSystemObject
		Dim fi As Scripting.File
		Dim folderPath As String
		Dim runLine As String
		Dim i As Integer
		Dim newIndex As String
		Dim outputIndexFile As Scripting.TextStream
		Dim tempFolder As Scripting.Folder
		Dim wsh As IWshRuntimeLibrary.WshShell
		
		'create output folder
		fso = New Scripting.FileSystemObject
		fi = fso.GetFile(Path)
		tempFolder = fso.GetSpecialFolder(Scripting.__MIDL___MIDL_itf_scrrun_0001_0000_0002.TemporaryFolder)
		folderPath = fso.BuildPath(tempFolder.Path, fi.name)
		folderPath = Replace(folderPath, ".chm", "")
		If Not fso.FolderExists(folderPath) Then
			Call fso.CreateFolder(folderPath)
		End If
		runLine = "hh.exe -decompile " & folderPath & " " & Path
		wsh = New IWshRuntimeLibrary.WshShell
		Call wsh.Run(runLine,  , True)
		'Call Shell(runLine, vbNormalFocus)
		For i = 0 To 100
			System.Windows.Forms.Application.DoEvents()
		Next i
		'now try to parse index.hhc (or similar) to get help file index
		For	Each fi In fso.GetFolder(folderPath).Files
			If StrComp(VB.Right(fi.name, 3), "hhc", CompareMethod.Text) = 0 Then
				'found an index file, process it for contents
				'get the new index file ready
				mTitle = ""
				newIndex = "<html><head><title>TITLEHERE</title></head><body><h1>TITLEHERE</h1>" & vbNewLine
				'UPGRADE_WARNING: Navigate2 was upgraded to Navigate and has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
				Call mWebBrowser.Navigate(New System.URI(fso.BuildPath(folderPath, fi.name)))
				While mWebBrowser.ReadyState <> System.Windows.Forms.WebBrowserReadyState.Complete
					System.Windows.Forms.Application.DoEvents()
				End While
				'UPGRADE_WARNING: Couldn't resolve default property of object mWebBrowser.Document.body. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				newIndex = newIndex & ParseHelp(mWebBrowser.Document.DomDocument.body)
				newIndex = newIndex & "</html>"
				newIndex = Replace(newIndex, "TITLEHERE", mTitle)
				outputIndexFile = fso.CreateTextFile(fso.BuildPath(folderPath, "helpindex.htm"))
				Call outputIndexFile.write(newIndex)
				Call outputIndexFile.Close()
				ConvertHTMLHelp = fso.BuildPath(folderPath, "helpindex.htm")
				Exit For
			End If
		Next fi
	End Function
	
	Private Function ParseHelp(ByRef e As mshtml.IHTMLElement) As String
		'parses a node in the help file into html
		On Error Resume Next
		Dim childIterator As mshtml.IHTMLElement
		Dim d As mshtml.IHTMLDOMNode
		'UPGRADE_NOTE: name was upgraded to name_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
        Dim name_Renamed As String = ""
        Dim url As String = ""
		
		Select Case e.tagname
			Case "BODY"
				ParseHelp = "<body>" & vbNewLine
				For	Each childIterator In e.children
					ParseHelp = ParseHelp & ParseHelp(childIterator) & vbNewLine
				Next childIterator
				ParseHelp = ParseHelp & "</body>" & vbNewLine
			Case "UL"
				ParseHelp = "<ul>" & vbNewLine
				For	Each childIterator In e.children
					ParseHelp = ParseHelp & ParseHelp(childIterator) & vbNewLine
				Next childIterator
				ParseHelp = ParseHelp & "</ul>" & vbNewLine
			Case "LI"
				ParseHelp = "<li>" & vbNewLine
				For	Each childIterator In e.children
					ParseHelp = ParseHelp & ParseHelp(childIterator) & vbNewLine
				Next childIterator
				ParseHelp = ParseHelp & "</li>" & vbNewLine
			Case "OBJECT"
				If InStr(1, e.innerHTML, "name=""Local""", CompareMethod.Text) > 0 Then
					'link to local file
					'UPGRADE_WARNING: Couldn't resolve default property of object e.childNodes. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					For	Each d In e.childNodes
						If d.nodeName = "PARAM" Then
							'UPGRADE_WARNING: Couldn't resolve default property of object d.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
							If d.attributes.getNamedItem("name").nodeValue = "Name" Then
								'got name
								'UPGRADE_WARNING: Couldn't resolve default property of object d.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
								name_Renamed = d.attributes.getNamedItem("value").nodeValue
								If Len(mTitle) = 0 Then mTitle = name_Renamed
								'UPGRADE_WARNING: Couldn't resolve default property of object d.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
							ElseIf d.attributes.getNamedItem("name").nodeValue = "Local" Then 
								'got url
								'UPGRADE_WARNING: Couldn't resolve default property of object d.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
								url = d.attributes.getNamedItem("value").nodeValue
							End If
						End If
					Next d
					ParseHelp = "<a href=""" & url & """>" & name_Renamed & "</a>"
				ElseIf InStr(1, e.innerHTML, "name=""ImageNumber""") > 0 Then 
					'section heading
					'UPGRADE_WARNING: Couldn't resolve default property of object e.childNodes. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
					For	Each d In e.childNodes
						If d.nodeName = "PARAM" Then
							'UPGRADE_WARNING: Couldn't resolve default property of object d.attributes.getNamedItem. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
							If d.attributes.getNamedItem("name").text = "Name" Then
								'got name
								ParseHelp = "<h2>" & name_Renamed & "</h2>" & vbNewLine
								Exit For
							End If
						End If
					Next d
				End If
		End Select
	End Function
End Class