﻿Module modFavorites

    Public Function GenerateHTMLFromFavorites() As String
        Dim output As String

        output = ParseFavoritesFolder(Environment.GetFolderPath(Environment.SpecialFolder.Favorites))
        output = "<html><head><title>" & GetText("Favorites") & "</title><body>" & output & "</body></html>"
        GenerateHTMLFromFavorites = output
    End Function

    Private Function ParseFavoritesFolder(path As String) As String
        Dim f As System.IO.FileInfo
        Dim fo As System.IO.DirectoryInfo
        Dim url As String
        Dim name As String
        ParseFavoritesFolder = ""
        'Do urls
        For Each f In New System.IO.DirectoryInfo(path).EnumerateFiles()
            name = ""
            name = f.Name
            url = modIniFile.GetString("InternetShortcut", "URL", "", f.FullName)
            If name <> "" And url <> "" Then
                name = Replace(name, ".url", "", , , CompareMethod.Text)
                ParseFavoritesFolder = ParseFavoritesFolder & "<li><a href=""" & url & """>" & name & "</a></li>" & vbNewLine
            End If
        Next f
        'Do subfolders. I'm going to do subfolders after links, otherwise stuff on the top menu will never get seen.
        For Each fo In New System.IO.DirectoryInfo(path).EnumerateDirectories
            ParseFavoritesFolder = ParseFavoritesFolder & "<li>" & fo.Name & "</li>"
            ParseFavoritesFolder = ParseFavoritesFolder & "<ul>"
            ParseFavoritesFolder = ParseFavoritesFolder & ParseFavoritesFolder(fo.FullName)
            ParseFavoritesFolder = ParseFavoritesFolder & "</ul>"
        Next fo
    End Function



End Module
