Option Strict On
Option Explicit On
Friend Class clsBackForwardsHandler
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'Manages the line that should be used for the caret by the Back and Forwards function
	
	
	Private lineNumbers() As Integer 'contains the line numbers to use
	Private currentPosition As Integer ' the index to the lineNumbers collection of
	'the current page
	Private cGoingBack As Boolean 'whether the current navigation is back
	Private cGoingForwards As Boolean 'whether the current navigation is forwards
	
	Public ReadOnly Property goingSomewhere() As Boolean
		Get

            goingSomewhere = (cGoingBack Or cGoingForwards)
        End Get
    End Property

    'setup the array we're going to use
    'UPGRADE_NOTE: Class_Initialize was upgraded to Class_Initialize_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
    Private Sub Class_Initialize_Renamed()

        ReDim lineNumbers(1000)
        currentPosition = 0
    End Sub
    Public Sub New()
        MyBase.New()
        Class_Initialize_Renamed()
    End Sub

    'store a line number on the onset of a navigation happening
    Public Sub NavigationBegin(ByRef newLineNumber As Integer)

        'okay, store this line number as the current location line number
        Debug.Print("Saved " & newLineNumber & " at position " & currentPosition)
        lineNumbers(currentPosition) = newLineNumber
        Dim i As Integer
        Dim s As String = ""
        For i = 0 To 10
            s = s & lineNumbers(i)
        Next i
        Debug.Print("Contains: [" & s & "]")
    End Sub

    'clears the going state, moves the current pointer along
    Public Function GetLineNumberAndClear() As Integer

        'change the pointer location
        Dim i As Integer
        Dim s As String = ""
        For i = 0 To 10
            s = s & lineNumbers(i)
        Next i
        Debug.Print("Contains: [" & s & "]")
        If cGoingBack Then
            If currentPosition > 0 Then
                Debug.Print("Back!")
                currentPosition = currentPosition - 1
            End If
        ElseIf cGoingForwards Then
            'should always be a value here - but I'll check anyway
            If currentPosition <= UBound(lineNumbers) Then
                Debug.Print("Forwards!")
                currentPosition = currentPosition + 1
            End If
        Else
            'normal navigation: we've reached somewhere new
            currentPosition = currentPosition + 1
            Call CheckForLineNumberArraySize()
            lineNumbers(currentPosition) = 0
        End If
        'return the new line number
        GetLineNumberAndClear = lineNumbers(currentPosition)
        Debug.Print("Returning line: " & GetLineNumberAndClear)
        s = ""
        For i = 0 To 10
            s = s & lineNumbers(i)
        Next i
        Debug.Print("Contains: [" & s & "]")
        'clear the state variables
        cGoingBack = False
        cGoingForwards = False
    End Function

    'tell the object the user is going back
    Public Sub goingBack()

        cGoingBack = True
    End Sub

    'makes the lineNumber array bigger if necessary
    Private Sub CheckForLineNumberArraySize()

        If currentPosition > UBound(lineNumbers) Then
            'need to resize lineNumbers
            ReDim Preserve lineNumbers(UBound(lineNumbers) + 500)
        End If
    End Sub

    'tell the object the user is going forwards
    Public Sub goingForwards()

        cGoingForwards = True
    End Sub
End Class