Option Strict On
Option Explicit On
Friend Class frmRSS
    Inherits System.Windows.Forms.Form
    '   This file is part of WebbIE.
    '
    '    WebbIE is free software: you can redistribute it and/or modify
    '    it under the terms of the GNU General Public License as published by
    '    the Free Software Foundation, either version 3 of the License, or
    '    (at your option) any later version.
    '
    '    WebbIE is distributed in the hope that it will be useful,
    '    but WITHOUT ANY WARRANTY; without even the implied warranty of
    '    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    '    GNU General Public License for more details.
    '
    '    You should have received a copy of the GNU General Public License
    '    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.


    Private WithEvents mRSSFeed As MSXML2.DOMDocument60
    Private mLinks As Collection = New Collection()

    Private Sub Initialise()
        Static initialised As Boolean
        If initialised Then
        Else
            mRSSFeed = New MSXML2.DOMDocument60
            Call lstItems.Items.Add(modI18N.GetText("No RSS News feed found."))
            lstItems.SelectedIndex = 0
        End If
        initialised = True
    End Sub

    Public Sub DisplayRSS(ByRef url As String)

        Call Initialise()
        Call lstItems.Items.Clear()
        'Call frmMain.cboAddress.Clear
        If Len(url) = 0 Then
            'no RSS feed
            Call lstItems.Items.Add(modI18N.GetText("No RSS News feed found."))
            cmdOpen.Enabled = False
            cmdSubscribe.Enabled = False
        Else
            Call mRSSFeed.load(url)
        End If
        mLinks = New Collection
    End Sub

    Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click

        Call Me.Hide()
    End Sub

    Private Sub cmdOpen_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdOpen.Click
        Call Initialise()
        Call GotoItem(lstItems.SelectedIndex)
    End Sub

    Public Sub GotoItem(ByRef index As Integer)
        Call Initialise()
        If index >= 0 And mLinks.Count() > 0 Then
            frmMain.cboAddress.Text = mLinks.Item(index + 1).ToString
            Call frmMain.cmdGo_Click()
            'Call frmMain.SetFocus Gets into a nasty race with frmMain to have the focus!
        End If
    End Sub

    Private Sub cmdSubscribe_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSubscribe.Click
        Call Initialise()
        '3.14.1
        'Write to the registry, RSS will pick it up when next opened. RSS must be in the same folder.
        Call SaveSetting("WebbIE", "Interprocess", "NewRSSURL", mRSSFeed.url)
        Call SaveSetting("WebbIE", "Interprocess", "NewRSSName", frmMain.webMain.DocumentTitle)
        Call Shell(My.Application.Info.DirectoryPath & "\RSS News Reader.exe", AppWinStyle.NormalNoFocus)
        Call MsgBox(modI18N.GetText("Subscription added to Accessible RSS News Reader"), MsgBoxStyle.OkOnly, My.Application.Info.Title)
        '    Dim rssDoc As DOMDocument30
        '    Dim rssFeed As IXMLDOMNode

        '    Set rssDoc = New DOMDocument30
        '    rssDoc.async = False
        '    If modPath.runningLocal Then
        '        Call rssDoc.Load(modPath.GetAppPath & "\Settings\WebbIE\AccessibleRSS\1\feeds.xml")
        '    Else
        '        Call rssDoc.Load(modPath.GetSpecialFolderPath(modPath.CSIDL_APPDATA) & "\WebbIE\AccessibleRSS\1\feeds.xml")
        '    End If
        '    If rssDoc.parseError.errorCode = 0 Then
        '        'loaded XML file containing RSS feeds okay.
        '        Set rssFeed = rssDoc.documentElement.selectSingleNode("feed[url=""" & mRSSFeed.url & """]")
        '        If rssFeed Is Nothing Then
        '            'not already subscribed to this, so add.
        '            Set rssFeed = rssDoc.createNode(NODE_ELEMENT, "feed", "")
        '            Call rssFeed.appendChild(rssDoc.createNode(NODE_ELEMENT, "title", ""))
        '            Call rssFeed.appendChild(rssDoc.createNode(NODE_ELEMENT, "url", ""))
        '            rssFeed.selectSingleNode("title").Text = frmMain.mWebBrowser.Document.title
        '            rssFeed.selectSingleNode("url").Text = mRSSFeed.url
        '            Call rssDoc.documentElement.appendChild(rssFeed)
        '            Call rssDoc.save(rssDoc.url)
        '            Call MsgBox(modI18N.GetText("Subscription added to Accessible RSS News Reader"), vbOKOnly, App.title)
        '        Else
        '            'already subscribed to this feed.
        '            Call MsgBox(modI18N.GetText("Already subscribed to this RSS News Feed"), vbInformation, App.title)
        '        End If
        '    Else
        '        'failed to parse: beep and get out
        '        cmdSubscribe.Visible = False
        '    End If


        'okay, we need to add this feed to the RSS News Reader.


        '    Dim i As Integer
        '    Dim found As Boolean
        '    Dim finished As Boolean
        '    Dim url As String

        '    'Are we running local?
        '    If modPath.runningLocal Then
        '        'whoops! We can't save locally yet: we haven't written the code for
        '        'saving feeds as xml files, we still store it in the registry.
        '        'Try using the command line anyway
        '        Call Shell(modPath.GetAppPath & "\AccessibleRSS.exe " & mRSSFeed.url)
        '    Else
        '        'okay, save to the registry using the same mechanism as AccessibleRSS
        '        i = 0
        '        On Error GoTo FailedToFind:
        '        While Not finished
        '            url = GetSetting("AccessibleRSS", "Feeds", "URL(" & i & ")", "NOWT,NOTHING,NADA-5553")
        '            If url = "NOWT,NOTHING,NADA-5553" Then
        '                'run out of things to find
        '                finished = True
        '            Else
        '                'found a url
        '                If url = mRSSFeed.url Then
        '                    'already subscribed
        '                    found = True
        '                End If
        '                'go to next entry
        '                i = i + 1
        '            End If
        '        Wend
        'FailedToFind:
        '        
        '        If found Then
        '            'already subscribed
        '            Call MsgBox(modi18n.GetText("Already subscribed to this RSS News Feed"), vbInformation, App.title)
        '        Else
        '            'can add to subscriptions: i was not present, so it's okay to back up
        '            'one - to the blank i - and use that
        '            i = i - 1
        '            Call SaveSetting("AccessibleRSS", "Feeds", "URL(" & i & ")", mRSSFeed.url)
        '            Call SaveSetting("AccessibleRSS", "Feeds", "Name(" & i & ")", frmMain.mWebBrowser.Document.title)
        '            'add the blank one used to indicate end-of-feeds
        '            i = i + 1
        '            Call SaveSetting("AccessibleRSS", "Feeds", "URL(" & i & ")", "")
        '            Call SaveSetting("AccessibleRSS", "Feeds", "Name(" & i & ")", "")
        '            Call MsgBox(modi18n.GetText("Subscription added to Accessible RSS News Reader"), vbOKOnly, App.title)
        '        End If
        '    End If
    End Sub

    'UPGRADE_WARNING: Form event frmRSS.Activate has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6BA9B8D2-2A32-4B6E-8D36-44949974A5B4"'
    Private Sub frmRSS_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated

        Call lstItems.Focus()
    End Sub

    Private Sub frmRSS_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Call Initialise()
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000

        If KeyCode = System.Windows.Forms.Keys.E And eventArgs.Control Then
            Call Me.Hide()
            'Call frmMain.SetFocus There's a nasty race with frmMain to get focus, might be this.
        End If
    End Sub

    Private Sub lstItems_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstItems.DoubleClick
        Call Initialise()
        If cmdOpen.Enabled Then Call cmdOpen_Click(cmdOpen, New System.EventArgs())
    End Sub

    Private Sub lstItems_KeyDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles lstItems.KeyDown
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000

        Call Initialise()
        If KeyCode = System.Windows.Forms.Keys.Up And lstItems.SelectedIndex = 0 Then
            Call PlayErrorSound()
        ElseIf KeyCode = System.Windows.Forms.Keys.Down And lstItems.SelectedIndex = lstItems.Items.Count - 1 Then
            Call PlayErrorSound()
        End If
    End Sub

    Private Sub mRSSFeed_onreadystatechange() Handles mRSSFeed.onreadystatechange

        Dim nodeIterator As MSXML2.IXMLDOMNode
        Dim itemsFound As Boolean
        'UPGRADE_NOTE: text was upgraded to text_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
        Dim text_Renamed As String
        Dim description As String

        Call Initialise()
        'Got RSS feed
        If mRSSFeed.readyState = System.Windows.Forms.WebBrowserReadyState.Complete Then
            If mRSSFeed.parseError.errorCode = 0 Then
                'parsed okay: display.
                cmdOpen.Enabled = True
                'Tried processing channels and items, but because of the varied
                'RSS formats, didn't work on some sites. 21 Feb 2007.
                If mRSSFeed.documentElement.selectSingleNode("channel/title") Is Nothing Then
                    Me.Text = modI18N.GetText("RSS News Feed")
                Else
                    Me.Text = modI18N.GetText("RSS News Feed") & " - " & mRSSFeed.documentElement.selectSingleNode("channel/title").text
                End If
                For Each nodeIterator In mRSSFeed.selectNodes("//item")
                    'For Each channelIterator In mRSSFeed.documentElement.selectNodes("channel")
                    '    For Each nodeIterator In channelIterator.selectNodes("item")
                    Call mLinks.Add(nodeIterator.selectSingleNode("link").text)
                    text_Renamed = nodeIterator.selectSingleNode("title").text
                    description = nodeIterator.selectSingleNode("description").text
                    If Len(description) > 0 Then
                        'okay, we have a description: at least one site makes this a link,
                        'not text, which isn't helpful. So reject any links
                        If InStr(1, description, "<") = 0 Then
                            text_Renamed = text_Renamed & " - " & description
                        End If
                    End If
                    text_Renamed = Replace(text_Renamed, "&amp;", "&")
                    text_Renamed = Replace(text_Renamed, "&nbsp;", " ")
                    text_Renamed = Replace(text_Renamed, "&rsquo;", "'")
                    Call lstItems.Items.Add(text_Renamed)
                    'Call frmMain.cboAddress.AddItem(text)
                    itemsFound = True
                    '    Next nodeIterator
                    'Next channelIterator
                Next nodeIterator
                If itemsFound Then
                    cmdOpen.Enabled = True
                Else
                    cmdOpen.Enabled = False
                    Call lstItems.Items.Add(modI18N.GetText("No items in RSS News feed."))
                End If
                cmdSubscribe.Enabled = True
            Else
                'didn't parse
                Call lstItems.Items.Add(modI18N.GetText("RSS Feed broken!"))
                'Call frmMain.cboAddress.Clear
                cmdOpen.Enabled = False
                cmdSubscribe.Enabled = False
            End If
            lstItems.SelectedIndex = 0
        End If
    End Sub
End Class