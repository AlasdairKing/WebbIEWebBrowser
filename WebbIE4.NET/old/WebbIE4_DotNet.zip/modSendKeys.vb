﻿Module modSendKeys
    <System.Runtime.InteropServices.DllImport("user32.dll", CallingConvention:=System.Runtime.InteropServices.CallingConvention.StdCall, _
           CharSet:=System.Runtime.InteropServices.CharSet.Unicode, EntryPoint:="keybd_event", _
           ExactSpelling:=True, SetLastError:=True)> _
    Private Function keybd_event(ByVal bVk As Int32, ByVal bScan As Int32, _
                              ByVal dwFlags As Int32, ByVal dwExtraInfo As Int32) As Boolean
    End Function

    Private Const VK_BACK As Int32 = &H8
    Private Const VK_TAB As Int32 = &H9
    ' &HA-&HB are unassigned, according to http://blogs.msdn.com/michkap/archive/2006/03/23/558658.aspx
    Private Const VK_CLEAR As Int32 = &HC
    Private Const VK_RETURN As Int32 = &HD
    ' &HE and &F - don't know!
    Private Const VK_SHIFT As Int32 = &H10
    Private Const VK_CONTROL As Int32 = &H11
    Private Const VK_ALTER As Int32 = &H12
    Private Const VK_Pause As Int32 = &H13
    Private Const VK_CapsLock As Int32 = &H14
    Private Const VK_KANA As Int32 = &H15
    Private Const VK_HANGEUL As Int32 = &H15
    Private Const VK_JUNJA As Int32 = &H17 ' 22
    Private Const VK_FINAL As Int32 = &H18 ' 23
    Private Const VK_HANJA As Int32 = &H19 ' 24
    Private Const VK_KANJI As Int32 = &H19 ' 25
    '&H1A - don't know. 26
    Private Const VK_Escape As Int32 = &H1B ' 27
    Private Const VK_CONVERT As Int32 = &H1C ' 28
    Private Const VK_NONCONVERT As Int32 = &H1D ' 29
    Private Const VK_ACCEPT As Int32 = &H1E ' 30
    Private Const VK_MODECHANGE As Int32 = &H1F ' 31
    Private Const VK_Space As Int32 = &H20 ' 32
    Private Const VK_PRIOR As Int32 = &H21 'Keys.PageUp
    Private Const VK_NEXT As Int32 = &H22 '  Keys.PageDown
    Private Const VK_End As Int32 = &H23
    Private Const VK_Home As Int32 = &H24
    Private Const VK_Left As Int32 = &H25
    Private Const VK_Up As Int32 = &H26
    Private Const VK_RIGHT As Int32 = &H27
    Private Const VK_Down As Int32 = &H28
    Private Const VK_SELECT As Int32 = &H29
    Private Const VK_PRINT As Int32 = &H2A
    Private Const VK_EXECUTE As Int32 = &H2B
    Private Const VK_SNAPSHOT As Int32 = &H2C ' Keys.PrintScreen
    Private Const VK_Insert As Int32 = &H2D
    Private Const VK_Delete As Int32 = &H2E
    Private Const VK_HELP As Int32 = &H2F
    Private Const VK_0 As Int32 = &H30
    Private Const VK_1 As Int32 = &H31
    Private Const VK_2 As Int32 = &H32
    Private Const VK_3 As Int32 = &H33
    Private Const VK_4 As Int32 = &H34
    Private Const VK_5 As Int32 = &H35
    Private Const VK_6 As Int32 = &H36
    Private Const VK_7 As Int32 = &H37
    Private Const VK_8 As Int32 = &H38
    Private Const VK_9 As Int32 = &H39
    ' &H40 : unassigned
    Private Const VK_A As Int32 = &H41
    Private Const VK_B As Int32 = &H42
    Private Const VK_C As Int32 = &H43
    Private Const VK_D As Int32 = &H44
    Private Const VK_E As Int32 = &H45
    Private Const VK_F As Int32 = &H46
    Private Const VK_G As Int32 = &H47
    Private Const VK_H As Int32 = &H48
    Private Const VK_I As Int32 = &H49
    Private Const VK_J As Int32 = &H4A
    Private Const VK_K As Int32 = &H4B
    Private Const VK_L As Int32 = &H4C
    Private Const VK_M As Int32 = &H4D
    Private Const VK_N As Int32 = &H4E
    Private Const VK_O As Int32 = &H4F
    Private Const VK_P As Int32 = &H50
    Private Const VK_Q As Int32 = &H51
    Private Const VK_R As Int32 = &H52
    Private Const VK_S As Int32 = &H53
    Private Const VK_T As Int32 = &H54
    Private Const VK_U As Int32 = &H55
    Private Const VK_V As Int32 = &H56
    Private Const VK_W As Int32 = &H57
    Private Const VK_X As Int32 = &H58
    Private Const VK_Y As Int32 = &H59
    Private Const VK_Z As Int32 = &H5A
    Private Const VK_LWIN As Int32 = &H5B
    Private Const VK_RWIN As Int32 = &H5C
    Private Const VK_APPS As Int32 = &H5D
    ' &H5E : reserved
    Private Const VK_SLEEP As Int32 = &H5 ' Keys.Sleep
    Private Const VK_NUMPAD0 As Int32 = &H60
    Private Const VK_NUMPAD1 As Int32 = &H61
    Private Const VK_NUMPAD2 As Int32 = &H62
    Private Const VK_NUMPAD3 As Int32 = &H63
    Private Const VK_NUMPAD4 As Int32 = &H64
    Private Const VK_NUMPAD5 As Int32 = &H65
    Private Const VK_NUMPAD6 As Int32 = &H66
    Private Const VK_NUMPAD7 As Int32 = &H67
    Private Const VK_NUMPAD8 As Int32 = &H68
    Private Const VK_NUMPAD9 As Int32 = &H69
    Private Const VK_MULTIPLY As Int32 = &H6A '*
    Private Const VK_ADD As Int32 = &H6B '+
    Private Const VK_SEPARATOR As Int32 = &H6C
    Private Const VK_SUBTRACT As Int32 = &H6D '-
    Private Const VK_DECIMAL As Int32 = &H6E '.
    Private Const VK_DIVIDE As Int32 = &H6F '/
    Private Const VK_F1 As Int32 = &H70
    Private Const VK_F2 As Int32 = &H71
    Private Const VK_F3 As Int32 = &H72
    Private Const VK_F4 As Int32 = &H73
    Private Const VK_F5 As Int32 = &H74
    Private Const VK_F6 As Int32 = &H75
    Private Const VK_F7 As Int32 = &H76
    Private Const VK_F8 As Int32 = &H77
    Private Const VK_F9 As Int32 = &H78
    Private Const VK_F10 As Int32 = &H79
    Private Const VK_F11 As Int32 = &H7A
    Private Const VK_F12 As Int32 = &H7B
    Private Const VK_F13 As Int32 = &H7C
    Private Const VK_F14 As Int32 = &H7D
    Private Const VK_F15 As Int32 = &H7E
    Private Const VK_F16 As Int32 = &H7F
    Private Const VK_F17 As Int32 = &H80
    Private Const VK_F18 As Int32 = &H81
    Private Const VK_F19 As Int32 = &H82
    Private Const VK_F20 As Int32 = &H83
    Private Const VK_F21 As Int32 = &H84
    Private Const VK_F22 As Int32 = &H85
    Private Const VK_F23 As Int32 = &H86
    Private Const VK_F24 As Int32 = &H87
    ' &H88 - &H8F : unassigned
    Private Const VK_NUMLOCK As Int32 = &H90
    Private Const VK_SCROLL As Int32 = &H91
    Private Const VK_OEM_NEC_EQUAL As Int32 = &H92        ',                     ' &H92, NEC PC-9800 kbd definition
    Private Const VK_OEM_FJ_JISHO As Int32 = &H92 ',                     ' &H92, Fujitsu/OASYS kbd definition
    Private Const VK_OEM_FJ_MASSHOU As Int32 = &H93 ',                     ' &H93, Fujitsu/OASYS kbd definition
    Private Const VK_OEM_FJ_TOUROKU As Int32 = &H94 ',                     ' &H94, Fujitsu/OASYS kbd definition
    Private Const VK_OEM_FJ_LOYA As Int32 = &H95 ',                     ' &H95, Fujitsu/OASYS kbd definition
    Private Const VK_OEM_FJ_ROYA As Int32 = &H96 ',                     ' &H96, Fujitsu/OASYS kbd definition
    ' &H97 - &H9F : unassigned
    Private Const VK_LSHIFT As Int32 = &HA0 ' 160
    Private Const VK_RSHIFT As Int32 = &HA1 ' 161
    Private Const VK_LCONTROL As Int32 = &HA2 ' 162
    Private Const VK_RCONTROL As Int32 = &HA3 ' 163
    Private Const VK_LMENU As Int32 = &HA4 ' 164
    Private Const VK_RMENU As Int32 = &HA5
    Private Const VK_BROWSER_BACK As Int32 = &HA6
    Private Const VK_BROWSER_FORWARD As Int32 = &HA7
    Private Const VK_BROWSER_REFRESH As Int32 = &HA8
    Private Const VK_BROWSER_STOP As Int32 = &HA9
    Private Const VK_BROWSER_SEARCH As Int32 = &HAA
    Private Const VK_BROWSER_FAVORITES As Int32 = &HAB
    Private Const VK_BROWSER_HOME As Int32 = &HAC
    Private Const VK_VOLUME_MUTE As Int32 = &HAD
    Private Const VK_VOLUME_DOWN As Int32 = &HAE
    Private Const VK_VOLUME_UP As Int32 = &HAF
    Private Const VK_MEDIA_NEXT_TRACK As Int32 = &HB0
    Private Const VK_MEDIA_PREV_TRACK As Int32 = &HB1
    Private Const VK_MEDIA_STOP As Int32 = &HB2
    Private Const VK_MEDIA_PLAY_PAUSE As Int32 = &HB3
    Private Const VK_LAUNCH_MAIL As Int32 = &HB4
    Private Const VK_LAUNCH_MEDIA_SELECT As Int32 = &HB5
    Private Const VK_LAUNCH_APP1 As Int32 = &HB6
    Private Const VK_LAUNCH_APP2 As Int32 = &HB7
    ' &HB8 - &HB9 : reserved
    Private Const VK_OEM_1 As Int32 = &HBA ' Keys.Oem1
    Private Const VK_OEM_PLUS As Int32 = &HBB
    Private Const VK_OEM_COMMA As Int32 = &HBC
    Private Const VK_OEM_MINUS As Int32 = &HBD
    Private Const VK_OEM_PERIOD As Int32 = &HBE
    Private Const VK_OEM_2 As Int32 = &HBF
    Private Const VK_OEM_3 As Int32 = &HC0           ' Keys.Oem3
    ' &HC1 - &HD7 : reserved
    ' &HD8 - &HDA : unassigned
    Private Const VK_OEM_4 As Int32 = &HDB
    Private Const VK_OEM_5 As Int32 = &HDC
    Private Const VK_OEM_6 As Int32 = &HDD
    Private Const VK_OEM_7 As Int32 = &HDE
    Private Const VK_OEM_8 As Int32 = &HDF
    '&HE0 : reserved
    Private Const VK_OEM_AX As Int32 = &HE1               '                     &HE1 ' 'AX' key on Japanese AX kbd
    Private Const VK_OEM_102 As Int32 = &HE2        ' Keys.Oem102
    Private Const VK_ICO_HELP As Int32 = &HE3 ' Help key on ICO
    Private Const VK_ICO_00 As Int32 = &HE4 ' 00 key on ICO
    Private Const VK_PROCESSKEY As Int32 = &HE5
    Private Const VK_ICO_CLEAR As Int32 = &HE6            ' &HE6
    Private Const VK_PACKET As Int32 = &HE7 '                     &HE7 ' Keys.Packet
    ' &HE8 : unassigned
    Private Const VK_OEM_RESET As Int32 = &HE9 ' Nokia/Ericsson definition
    Private Const VK_OEM_JUMP As Int32 = &HEA ' Nokia/Ericsson definition
    Private Const VK_OEM_PA1 As Int32 = &HEB ' Nokia/Ericsson definition
    Private Const VK_OEM_PA2 As Int32 = &HEC ' Nokia/Ericsson definition
    Private Const VK_OEM_PA3 As Int32 = &HED ' Nokia/Ericsson definition
    Private Const VK_OEM_WSCTRL As Int32 = &HEE ' Nokia/Ericsson definition
    Private Const VK_OEM_CUSEL As Int32 = &HEF ' Nokia/Ericsson definition
    Private Const VK_OEM_ATTN As Int32 = &HF0 ' Nokia/Ericsson definition
    Private Const VK_OEM_FINISH As Int32 = &HF1 ' Nokia/Ericsson definition
    Private Const VK_OEM_COPY As Int32 = &HF2 ' Nokia/Ericsson definition
    Private Const VK_OEM_AUTO As Int32 = &HF3 ' Nokia/Ericsson definition
    Private Const VK_OEM_ENLW As Int32 = &HF4 ' Nokia/Ericsson definition
    Private Const VK_OEM_BACKTAB As Int32 = &HF5 ' Nokia/Ericsson definition
    Private Const VK_ATTN As Int32 = &HF6
    Private Const VK_CRSEL As Int32 = &HF7
    Private Const VK_EXSEL As Int32 = &HF8
    Private Const VK_EREOF As Int32 = &HF9
    Private Const VK_PLAY As Int32 = &HFA
    Private Const VK_ZOOM As Int32 = &HFB
    Private Const VK_NONAME As Int32 = &HFC
    Private Const VK_PA1 As Int32 = &HFD
    Private Const VK_OEM_CLEAR As Int32 = &HFE
    ' &HFF : reserved

    Private Const KEYEVENTF_EXTENDEDKEY As Int32 = &H1
    Private Const KEYEVENTF_KEYUP As Int32 = &H2

    Public Sub SendPaste()
        Call keybd_event(VK_CONTROL, 0, 0, 0)
        Call keybd_event(VK_V, 0, 0, 0)

        Call keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
        Call keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
    End Sub

    Public Sub SendSelectAll()
        Call keybd_event(VK_CONTROL, 0, 0, 0)
        Call keybd_event(VK_A, 0, 0, 0)

        Call keybd_event(VK_A, 0, KEYEVENTF_KEYUP, 0)
        Call keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
    End Sub

End Module
