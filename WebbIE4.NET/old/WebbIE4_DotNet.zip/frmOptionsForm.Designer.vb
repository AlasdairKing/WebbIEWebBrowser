﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOptionsForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOptionsForm))
        Me.chkUseQuickkeys = New System.Windows.Forms.CheckBox()
        Me.chkAlwaysstartintextview = New System.Windows.Forms.CheckBox()
        Me.chkAllowPopupWindows = New System.Windows.Forms.CheckBox()
        Me.chkAllowMessages = New System.Windows.Forms.CheckBox()
        Me.chkUseFavoritesForHomePage = New System.Windows.Forms.CheckBox()
        Me.gbpDownloadingImages = New System.Windows.Forms.GroupBox()
        Me.radDoNotDownloadImagesInIEAndWebbIE = New System.Windows.Forms.RadioButton()
        Me.radDownloadImagesInIEAndWebbIE = New System.Windows.Forms.RadioButton()
        Me.chkNumberLinks = New System.Windows.Forms.CheckBox()
        Me.chkNavigationSounds = New System.Windows.Forms.CheckBox()
        Me.chkShowImages = New System.Windows.Forms.CheckBox()
        Me.chkShowToolbarCaptions = New System.Windows.Forms.CheckBox()
        Me.chkShowToolbar = New System.Windows.Forms.CheckBox()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.gbpDownloadingImages.SuspendLayout()
        Me.SuspendLayout()
        '
        'chkUseQuickkeys
        '
        Me.chkUseQuickkeys.AutoSize = True
        Me.chkUseQuickkeys.Location = New System.Drawing.Point(12, 12)
        Me.chkUseQuickkeys.Name = "chkUseQuickkeys"
        Me.chkUseQuickkeys.Size = New System.Drawing.Size(96, 17)
        Me.chkUseQuickkeys.TabIndex = 0
        Me.chkUseQuickkeys.Text = "Use quick keys"
        Me.chkUseQuickkeys.UseVisualStyleBackColor = True
        '
        'chkAlwaysstartintextview
        '
        Me.chkAlwaysstartintextview.AutoSize = True
        Me.chkAlwaysstartintextview.Location = New System.Drawing.Point(12, 35)
        Me.chkAlwaysstartintextview.Name = "chkAlwaysstartintextview"
        Me.chkAlwaysstartintextview.Size = New System.Drawing.Size(145, 17)
        Me.chkAlwaysstartintextview.TabIndex = 1
        Me.chkAlwaysstartintextview.Text = "Always start in text view"
        Me.chkAlwaysstartintextview.UseVisualStyleBackColor = True
        '
        'chkAllowPopupWindows
        '
        Me.chkAllowPopupWindows.AutoSize = True
        Me.chkAllowPopupWindows.Location = New System.Drawing.Point(12, 58)
        Me.chkAllowPopupWindows.Name = "chkAllowPopupWindows"
        Me.chkAllowPopupWindows.Size = New System.Drawing.Size(128, 17)
        Me.chkAllowPopupWindows.TabIndex = 2
        Me.chkAllowPopupWindows.Text = "Allow popup windows"
        Me.chkAllowPopupWindows.UseVisualStyleBackColor = True
        '
        'chkAllowMessages
        '
        Me.chkAllowMessages.AutoSize = True
        Me.chkAllowMessages.Location = New System.Drawing.Point(12, 81)
        Me.chkAllowMessages.Name = "chkAllowMessages"
        Me.chkAllowMessages.Size = New System.Drawing.Size(101, 17)
        Me.chkAllowMessages.TabIndex = 3
        Me.chkAllowMessages.Text = "Allow messages"
        Me.chkAllowMessages.UseVisualStyleBackColor = True
        '
        'chkUseFavoritesForHomePage
        '
        Me.chkUseFavoritesForHomePage.AutoSize = True
        Me.chkUseFavoritesForHomePage.Location = New System.Drawing.Point(12, 131)
        Me.chkUseFavoritesForHomePage.Name = "chkUseFavoritesForHomePage"
        Me.chkUseFavoritesForHomePage.Size = New System.Drawing.Size(163, 17)
        Me.chkUseFavoritesForHomePage.TabIndex = 4
        Me.chkUseFavoritesForHomePage.Text = "Use favorites for home page"
        Me.chkUseFavoritesForHomePage.UseVisualStyleBackColor = True
        '
        'gbpDownloadingImages
        '
        Me.gbpDownloadingImages.Controls.Add(Me.radDoNotDownloadImagesInIEAndWebbIE)
        Me.gbpDownloadingImages.Controls.Add(Me.radDownloadImagesInIEAndWebbIE)
        Me.gbpDownloadingImages.Location = New System.Drawing.Point(12, 154)
        Me.gbpDownloadingImages.Name = "gbpDownloadingImages"
        Me.gbpDownloadingImages.Size = New System.Drawing.Size(244, 71)
        Me.gbpDownloadingImages.TabIndex = 7
        Me.gbpDownloadingImages.TabStop = False
        Me.gbpDownloadingImages.Text = "Downloading images"
        '
        'radDoNotDownloadImagesInIEAndWebbIE
        '
        Me.radDoNotDownloadImagesInIEAndWebbIE.AutoSize = True
        Me.radDoNotDownloadImagesInIEAndWebbIE.Location = New System.Drawing.Point(18, 42)
        Me.radDoNotDownloadImagesInIEAndWebbIE.Name = "radDoNotDownloadImagesInIEAndWebbIE"
        Me.radDoNotDownloadImagesInIEAndWebbIE.Size = New System.Drawing.Size(142, 17)
        Me.radDoNotDownloadImagesInIEAndWebbIE.TabIndex = 8
        Me.radDoNotDownloadImagesInIEAndWebbIE.TabStop = True
        Me.radDoNotDownloadImagesInIEAndWebbIE.Text = "Do not download images"
        Me.radDoNotDownloadImagesInIEAndWebbIE.UseVisualStyleBackColor = True
        '
        'radDownloadImagesInIEAndWebbIE
        '
        Me.radDownloadImagesInIEAndWebbIE.AutoSize = True
        Me.radDownloadImagesInIEAndWebbIE.Location = New System.Drawing.Point(18, 19)
        Me.radDownloadImagesInIEAndWebbIE.Name = "radDownloadImagesInIEAndWebbIE"
        Me.radDownloadImagesInIEAndWebbIE.Size = New System.Drawing.Size(194, 17)
        Me.radDownloadImagesInIEAndWebbIE.TabIndex = 7
        Me.radDownloadImagesInIEAndWebbIE.TabStop = True
        Me.radDownloadImagesInIEAndWebbIE.Text = "Download images in IE and WebbIE"
        Me.radDownloadImagesInIEAndWebbIE.UseVisualStyleBackColor = True
        '
        'chkNumberLinks
        '
        Me.chkNumberLinks.AutoSize = True
        Me.chkNumberLinks.Location = New System.Drawing.Point(12, 231)
        Me.chkNumberLinks.Name = "chkNumberLinks"
        Me.chkNumberLinks.Size = New System.Drawing.Size(86, 17)
        Me.chkNumberLinks.TabIndex = 8
        Me.chkNumberLinks.Text = "Number links"
        Me.chkNumberLinks.UseVisualStyleBackColor = True
        '
        'chkNavigationSounds
        '
        Me.chkNavigationSounds.AutoSize = True
        Me.chkNavigationSounds.Location = New System.Drawing.Point(12, 254)
        Me.chkNavigationSounds.Name = "chkNavigationSounds"
        Me.chkNavigationSounds.Size = New System.Drawing.Size(114, 17)
        Me.chkNavigationSounds.TabIndex = 9
        Me.chkNavigationSounds.Text = "Navigation sounds"
        Me.chkNavigationSounds.UseVisualStyleBackColor = True
        '
        'chkShowImages
        '
        Me.chkShowImages.AutoSize = True
        Me.chkShowImages.Location = New System.Drawing.Point(12, 277)
        Me.chkShowImages.Name = "chkShowImages"
        Me.chkShowImages.Size = New System.Drawing.Size(88, 17)
        Me.chkShowImages.TabIndex = 10
        Me.chkShowImages.Text = "Show images"
        Me.chkShowImages.UseVisualStyleBackColor = True
        '
        'chkShowToolbarCaptions
        '
        Me.chkShowToolbarCaptions.AutoSize = True
        Me.chkShowToolbarCaptions.Location = New System.Drawing.Point(12, 324)
        Me.chkShowToolbarCaptions.Name = "chkShowToolbarCaptions"
        Me.chkShowToolbarCaptions.Size = New System.Drawing.Size(132, 17)
        Me.chkShowToolbarCaptions.TabIndex = 11
        Me.chkShowToolbarCaptions.Text = "Show toolbar captions"
        Me.chkShowToolbarCaptions.UseVisualStyleBackColor = True
        '
        'chkShowToolbar
        '
        Me.chkShowToolbar.AutoSize = True
        Me.chkShowToolbar.Location = New System.Drawing.Point(12, 300)
        Me.chkShowToolbar.Name = "chkShowToolbar"
        Me.chkShowToolbar.Size = New System.Drawing.Size(89, 17)
        Me.chkShowToolbar.TabIndex = 12
        Me.chkShowToolbar.Text = "Show toolbar"
        Me.chkShowToolbar.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(197, 12)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 13
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'frmOptionsForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 353)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.chkShowToolbar)
        Me.Controls.Add(Me.chkShowToolbarCaptions)
        Me.Controls.Add(Me.chkShowImages)
        Me.Controls.Add(Me.chkNavigationSounds)
        Me.Controls.Add(Me.chkNumberLinks)
        Me.Controls.Add(Me.gbpDownloadingImages)
        Me.Controls.Add(Me.chkUseFavoritesForHomePage)
        Me.Controls.Add(Me.chkAllowMessages)
        Me.Controls.Add(Me.chkAllowPopupWindows)
        Me.Controls.Add(Me.chkAlwaysstartintextview)
        Me.Controls.Add(Me.chkUseQuickkeys)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmOptionsForm"
        Me.Text = "Options"
        Me.gbpDownloadingImages.ResumeLayout(False)
        Me.gbpDownloadingImages.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chkUseQuickkeys As System.Windows.Forms.CheckBox
    Friend WithEvents chkAlwaysstartintextview As System.Windows.Forms.CheckBox
    Friend WithEvents chkAllowPopupWindows As System.Windows.Forms.CheckBox
    Friend WithEvents chkAllowMessages As System.Windows.Forms.CheckBox
    Friend WithEvents chkUseFavoritesForHomePage As System.Windows.Forms.CheckBox
    Friend WithEvents gbpDownloadingImages As System.Windows.Forms.GroupBox
    Friend WithEvents radDoNotDownloadImagesInIEAndWebbIE As System.Windows.Forms.RadioButton
    Friend WithEvents radDownloadImagesInIEAndWebbIE As System.Windows.Forms.RadioButton
    Friend WithEvents chkNumberLinks As System.Windows.Forms.CheckBox
    Friend WithEvents chkNavigationSounds As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowImages As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowToolbarCaptions As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowToolbar As System.Windows.Forms.CheckBox
    Friend WithEvents btnOK As System.Windows.Forms.Button
End Class
