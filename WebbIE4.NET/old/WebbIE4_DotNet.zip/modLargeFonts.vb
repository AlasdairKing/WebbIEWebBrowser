Option Strict Off
Option Explicit On
Module modLargeFonts
	'Gets font size in Windows, for handling large fonts settings.
	
	'From http://www.vbaccelerator.com/home/VB/Tips/Get_System_Display_Fonts_and_Non-Client_Area_Sizes/article.asp
	'See also http://msdn2.microsoft.com/en-us/library/ms724506.aspx
	
	'HOW TO USE
	'1 Add this module to your project.
	'2 Add frmLargeFonts to your project.
	'3 For each font call this module in Form_Load:
	'   Call modLargeFonts.ApplySystemSettingsToForm(Me)
	'4 Write Form_Resize code to handle when all your labels etc. change size...
	
	Private Const SPI_GETICONMETRICS As Short = 45
	Private Const SPI_GETICONTITLELOGFONT As Short = 31
	Private Const LF_FACESIZE As Short = 32
	Private Const LF_FULLFACESIZE As Short = 64
	
	Private Const HASNOT_FONT As String = "*WebBrowser*Winsock*CommonDialog*Timer*Menu*ProgressBar*Slider*WindowsMediaPlayer*"
	Private Const HAS_FONT As String = "*Label*DUniLabel*UniLabel*ComboBox*TextBox*Frame*CommandButton*CheckBox*OptionButton*ListBox*TabStrip*Toolbar*StatusBar*TreeView*ListView*ImageCombo*DUniText*DUniList*DUniCombo*"
	
	' Normal log font structure:
	Private Structure LOGFONT
		Dim lfHeight As Integer
		Dim lfWidth As Integer
		Dim lfEscapement As Integer
		Dim lfOrientation As Integer
		Dim lfWeight As Integer
		Dim lfItalic As Byte
		Dim lfUnderline As Byte
		Dim lfStrikeOut As Byte
		Dim lfCharSet As Byte
		Dim lfOutPrecision As Byte
		Dim lfClipPrecision As Byte
		Dim lfQuality As Byte
		Dim lfPitchAndFamily As Byte
		<VBFixedArray(LF_FACESIZE)> Dim lfFaceName() As Byte
		
		'UPGRADE_TODO: "Initialize" must be called to initialize instances of this structure. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="B4BFF9E0-8631-45CF-910E-62AB3970F27B"'
		Public Sub Initialize()
			ReDim lfFaceName(LF_FACESIZE)
		End Sub
	End Structure
	Private Enum CNCMetricsFontWeightConstants
		FW_DONTCARE = 0
		FW_THIN = 100
		FW_EXTRALIGHT = 200
		FW_ULTRALIGHT = 200
		FW_LIGHT = 300
		FW_NORMAL = 400
		FW_REGULAR = 400
		FW_MEDIUM = 500
		FW_SEMIBOLD = 600
		FW_DEMIBOLD = 600
		FW_BOLD = 700
		FW_EXTRABOLD = 800
		FW_ULTRABOLD = 800
		FW_HEAVY = 900
		FW_BLACK = 900
	End Enum
	' For some bizarre reason, maybe to do with byte
	' alignment, the LOGFONT structure we must apply
	' to NONCLIENTMETRICS seems to require an LF_FACESIZE
	' 4 bytes smaller than normal:
	Private Structure NMLOGFONT
		Dim lfHeight As Integer
		Dim lfWidth As Integer
		Dim lfEscapement As Integer
		Dim lfOrientation As Integer
		Dim lfWeight As Integer
		Dim lfItalic As Byte
		Dim lfUnderline As Byte
		Dim lfStrikeOut As Byte
		Dim lfCharSet As Byte
		Dim lfOutPrecision As Byte
		Dim lfClipPrecision As Byte
		Dim lfQuality As Byte
		Dim lfPitchAndFamily As Byte
		<VBFixedArray(LF_FACESIZE - 4)> Dim lfFaceName() As Byte
		
		'UPGRADE_TODO: "Initialize" must be called to initialize instances of this structure. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="B4BFF9E0-8631-45CF-910E-62AB3970F27B"'
		Public Sub Initialize()
			ReDim lfFaceName(LF_FACESIZE - 4)
		End Sub
	End Structure
	Private Structure NONCLIENTMETRICS
		Dim cbSize As Integer
		Dim iBorderWidth As Integer
		Dim iScrollWidth As Integer
		Dim iScrollHeight As Integer
		Dim iCaptionWidth As Integer
		Dim iCaptionHeight As Integer
		'UPGRADE_WARNING: Arrays in structure lfCaptionFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfCaptionFont As NMLOGFONT
		Dim iSMCaptionWidth As Integer
		Dim iSMCaptionHeight As Integer
		'UPGRADE_WARNING: Arrays in structure lfSMCaptionFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfSMCaptionFont As NMLOGFONT
		Dim iMenuWidth As Integer
		Dim iMenuHeight As Integer
		'UPGRADE_WARNING: Arrays in structure lfMenuFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfMenuFont As NMLOGFONT
		'UPGRADE_WARNING: Arrays in structure lfStatusFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfStatusFont As NMLOGFONT
		'UPGRADE_WARNING: Arrays in structure lfMessageFont may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim lfMessageFont As NMLOGFONT
		
		'UPGRADE_TODO: "Initialize" must be called to initialize instances of this structure. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="B4BFF9E0-8631-45CF-910E-62AB3970F27B"'
		Public Sub Initialize()
			lfCaptionFont.Initialize()
			lfSMCaptionFont.Initialize()
			lfMenuFont.Initialize()
			lfStatusFont.Initialize()
			lfMessageFont.Initialize()
		End Sub
	End Structure
	Private Const SPI_GETNONCLIENTMETRICS As Short = 41
	Private Const SPI_SETNONCLIENTMETRICS As Short = 42
	'UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
	Private Declare Function SystemParametersInfo Lib "user32"  Alias "SystemParametersInfoA"(ByVal uAction As Integer, ByVal uParam As Integer, ByRef lpvParam As Any, ByVal fuWinIni As Integer) As Integer
	'UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
	'UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
	Private Declare Sub CopyMemory Lib "kernel32"  Alias "RtlMoveMemory"(ByRef lpvDest As Any, ByRef lpvSource As Any, ByVal cbCopy As Integer)
	Private Declare Function GetDeviceCaps Lib "gdi32" (ByVal hDC As Integer, ByVal nIndex As Integer) As Integer
	Private Const LOGPIXELSY As Short = 90 ' Logical pixels/inch in Y
	'UPGRADE_WARNING: Structure LOGFONT may require marshalling attributes to be passed as an argument in this Declare statement. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="C429C3A5-5D47-4CD9-8F51-74A1616405DC"'
	Private Declare Function CreateFontIndirect Lib "gdi32"  Alias "CreateFontIndirectA"(ByRef lpLogFont As LOGFONT) As Integer
	Private Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Integer) As Integer
	
	Private m_tNCM As NONCLIENTMETRICS
	'UPGRADE_WARNING: Arrays in structure m_tLF may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
	Private m_tLF As LOGFONT
	
	Private Enum CNCMetricsFontTypes
		IconFont = 1
		CaptionFont = 2
		SMCaptionFont = 3
		MenuFont = 4
		StatusFont = 5
		MessageFont = 6
	End Enum
	
	Private Function GetMetrics() As Boolean
		Dim lR As Integer
		' Get Non-client metrics:
		m_tNCM.cbSize = 340
		'UPGRADE_WARNING: Couldn't resolve default property of object m_tNCM. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
		lR = SystemParametersInfo(SPI_GETNONCLIENTMETRICS, 0, m_tNCM, 0)
		If (lR <> 0) Then
			' Get icon font:
			'UPGRADE_WARNING: Couldn't resolve default property of object m_tLF. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			lR = SystemParametersInfo(SPI_GETICONTITLELOGFONT, 0, m_tLF, 0)
			GetMetrics = (lR <> 0)
		End If
	End Function
	
	Private Function GetFont(ByVal hDC As Integer, ByVal eFontNum As CNCMetricsFontTypes) As System.Drawing.Font
		
		'UPGRADE_WARNING: Arrays in structure tLF may need to be initialized before they can be used. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="814DF224-76BD-4BB4-BFFB-EA359CB9FC48"'
		Dim tLF As LOGFONT
		
		Select Case eFontNum
			Case CNCMetricsFontTypes.StatusFont
				'UPGRADE_ISSUE: LenB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object m_tNCM.lfStatusFont. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object tLF. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				CopyMemory(tLF, m_tNCM.lfStatusFont, LenB(m_tNCM.lfStatusFont))
			Case CNCMetricsFontTypes.SMCaptionFont
				'UPGRADE_ISSUE: LenB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object m_tNCM.lfSMCaptionFont. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object tLF. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				CopyMemory(tLF, m_tNCM.lfSMCaptionFont, LenB(m_tNCM.lfSMCaptionFont))
			Case CNCMetricsFontTypes.MessageFont
				'UPGRADE_ISSUE: LenB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object m_tNCM.lfMessageFont. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object tLF. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				CopyMemory(tLF, m_tNCM.lfMessageFont, LenB(m_tNCM.lfMessageFont))
			Case CNCMetricsFontTypes.MenuFont
				'UPGRADE_ISSUE: LenB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object m_tNCM.lfMenuFont. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object tLF. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				CopyMemory(tLF, m_tNCM.lfMenuFont, LenB(m_tNCM.lfMenuFont))
			Case CNCMetricsFontTypes.IconFont
				'UPGRADE_ISSUE: LenB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object m_tLF. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object tLF. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				CopyMemory(tLF, m_tLF, LenB(m_tLF))
			Case CNCMetricsFontTypes.CaptionFont
				'UPGRADE_ISSUE: LenB function is not supported. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="367764E5-F3F8-4E43-AC3E-7FE0B5E074E2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object m_tNCM.lfCaptionFont. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				'UPGRADE_WARNING: Couldn't resolve default property of object tLF. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				CopyMemory(tLF, m_tNCM.lfCaptionFont, LenB(m_tNCM.lfCaptionFont))
			Case Else
				Exit Function
		End Select
		
		' This demonstrates how to return a VB style font.
		' If you want an API hFont, just do this:
		' hFont = CreateFontIndirect(tLF)
		' Remember to use DeleteObject hFont when you've
		' finished with it.
		Dim sFnt As System.Drawing.Font = System.Windows.Forms.Control.DefaultFont.Clone()
		pLogFontToStdFont(tLF, hDC, sFnt)
		GetFont = sFnt
		
	End Function
	
	Private Sub pLogFontToStdFont(ByRef tLF As LOGFONT, ByVal hDC As Integer, ByRef sFnt As System.Drawing.Font)
		With sFnt
			'UPGRADE_ISSUE: Constant vbUnicode was not upgraded. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="55B59875-9A95-4B71-9D6A-7C294BF7139D"'
			sFnt = VB6.FontChangeName(sFnt, StrConv(System.Text.UnicodeEncoding.Unicode.GetString(tLF.lfFaceName), vbUnicode))
			If tLF.lfHeight < 1 Then
				If tLF.lfHeight <> 0 Then
					sFnt = VB6.FontChangeSize(sFnt, System.Math.Abs((72# / GetDeviceCaps(hDC, LOGPIXELSY)) * tLF.lfHeight))
				End If
			Else
				sFnt = VB6.FontChangeSize(sFnt, tLF.lfHeight)
			End If
			sFnt = VB6.FontChangeGdiCharSet(sFnt, tLF.lfCharSet)
			sFnt = VB6.FontChangeItalic(sFnt, Not (tLF.lfItalic = 0))
			sFnt = VB6.FontChangeUnderline(sFnt, Not (tLF.lfUnderline = 0))
			sFnt = VB6.FontChangeStrikeOut(sFnt, Not (tLF.lfStrikeOut = 0))
			sFnt = VB6.FontChangeBold(sFnt, (tLF.lfWeight > CNCMetricsFontWeightConstants.FW_REGULAR))
		End With
	End Sub
	
	Private Function GetCaptionHeight() As Integer
		GetCaptionHeight = m_tNCM.iCaptionHeight
	End Function
	Private Function GetCaptionWIdth() As Integer
		GetCaptionWIdth = m_tNCM.iCaptionWidth
	End Function
	Private Function GetMenuHeight() As Integer
		GetMenuHeight = m_tNCM.iMenuHeight
	End Function
	Private Function GetMenuWidth() As Integer
		GetMenuWidth = m_tNCM.iMenuWidth
	End Function
	Private Function GetScrollHeight() As Integer
		GetScrollHeight = m_tNCM.iScrollHeight
	End Function
	Private Function GetScrollWidth() As Integer
		GetScrollWidth = m_tNCM.iScrollWidth
	End Function
	Private Function GetSMCaptionHeight() As Integer
		GetSMCaptionHeight = m_tNCM.iSMCaptionHeight
	End Function
	Private Function GetSMCaptionWIdth() As Integer
		GetSMCaptionWIdth = m_tNCM.iSMCaptionWidth
	End Function
	Private Function GetBorderWidth() As Integer
		GetBorderWidth = m_tNCM.iBorderWidth
	End Function
	
	Public Sub ApplySystemSettingsToForm(ByRef aForm As System.Windows.Forms.Form, Optional ByRef controlsExcluded As String = "", Optional ByRef retainLargerFonts As Boolean = False)
	End Sub
	
	Private Function HasFont(ByRef c As System.Windows.Forms.Control) As Boolean
		On Error Resume Next
		'UPGRADE_WARNING: TypeName has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
		HasFont = (InStr(1, HAS_FONT, TypeName(c)) > 0)
	End Function
	
	Private Sub ApplyFont(ByRef uiObject As Object, ByRef newFont As System.Drawing.Font, ByRef retainLargerFonts As Boolean)
		'Applies the font newFont to the form or control uiObject, but checks bold and font size against
		'existing bold and font size and keeps the "more visible" ones if retainLargerFonts is true
		On Error Resume Next
		Dim size As Single
		Dim bold As Boolean
		
		'UPGRADE_WARNING: TypeName has a new behavior. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="9B7D5ADD-D8FE-4819-A36C-6DEDAF088CC7"'
		If TypeName(uiObject) = "Toolbar" Then
			'No font object to manipulate
		Else
			size = newFont.SizeInPoints
			'UPGRADE_WARNING: Couldn't resolve default property of object uiObject.Font. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			size = uiObject.Font.size
			'UPGRADE_WARNING: Couldn't resolve default property of object uiObject.Font. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			bold = uiObject.Font.bold
			'UPGRADE_WARNING: Couldn't resolve default property of object uiObject.Font. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
			uiObject.Font = newFont
			If retainLargerFonts Then
				'UPGRADE_WARNING: Couldn't resolve default property of object uiObject.Font. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If uiObject.Font.size < size Then uiObject.Font.size = size
				'UPGRADE_WARNING: Couldn't resolve default property of object uiObject.Font. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
				If (Not uiObject.Font.bold) And bold Then uiObject.Font.bold = True
			End If
		End If
		
		
	End Sub
End Module