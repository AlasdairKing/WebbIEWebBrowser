Option Strict On
Option Explicit On
Module modAPIFunctions
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
    <System.Runtime.InteropServices.DllImport("user32.dll", SetLastError:=True, CharSet:=System.Runtime.InteropServices.CharSet.Auto)> _
    Public Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function

    <System.Runtime.InteropServices.DllImport("user32.dll", SetLastError:=True, CharSet:=System.Runtime.InteropServices.CharSet.Auto)> _
    Public Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As String) As IntPtr
    End Function

	Private Declare Function RegOpenKeyEx Lib "advapi32.dll"  Alias "RegOpenKeyExA"(ByVal hKey As Integer, ByVal lpSubKey As String, ByVal ulOptions As Integer, ByVal samDesired As Integer, ByRef phkResult As Integer) As Integer
	'open a key for reading or writing
	
	
	Public Sub Scroll(ByRef editControl As System.Windows.Forms.Control, ByRef lines As Integer)
		'scrolls the editControl textbox by lines lines
		' editControl - the current control
		' lines - the number of lines to scroll

		Call SendMessageW(editControl.Handle.ToInt32, EM_LINESCROLL, 0, lines)
	End Sub
	
    Public Sub ScrollToCursor(ByRef editControl As System.Windows.Forms.TextBox)
        'scrolls the editControl textbox to where the cursor is now
        ' editControl - the current control
        Call SendMessageW(editControl.Handle.ToInt32, EM_SCROLLCARET, 0, 0)
    End Sub
	
    Public Function GetCurrentLine(ByRef editControl As System.Windows.Forms.TextBox) As String
        'returns the text on the current line from the current control
        '   editControl - the current control
        '   charPos - the position of the cursor in the control
        Dim lineNumber As IntPtr ' the line number of the current line
        'get the line number: arguments of -1 mean "line with caret", 0 is not used.
        lineNumber = SendMessage(editControl.Handle, EM_LINEFROMCHAR, New IntPtr(-1), New IntPtr(0))
        'We can get a "line number" from either SendMessage (the old VB6 way) or from the actual
        'edit control, and they agree. However, they are both wrong: if I is the caret:
        ' Line 1<newline>
        ' LineI 2           Correctly returns 1, and editControl.Lines(1) is "Line 2" Great!
        '
        'But now what if the text wraps? Then it all goes to crap.
        ' Line
        ' 1<newline>
        ' LineI                 Now returns 2, which is fine - it's the third line of text. BUT
        ' 2                     .lines() hasn't changed, so you get a blank piece of text - you 
        '                       still need to get .lines(1)!
        'So you can't do this:
        '        Return editControl.Lines(editControl.GetLineFromCharIndex(editControl.SelectionStart))
        'Instead you must still use the API, which I've done in GetLine.

        Return GetLine(editControl, CInt(lineNumber))

    End Function

    Public Function GetLine(ByRef editControl As System.Windows.Forms.TextBox, ByVal ZeroBasedLinetoRead As Integer) As String
        'First, get the length of the line.
        Dim lineLen As Integer = CInt(SendMessage(editControl.Handle, EM_LINELENGTH, New IntPtr(ZeroBasedLinetoRead), New IntPtr(0)))
        'Now construct a buffer to get the text content.
        Dim byte1 As String = Chr(lineLen And &HFF)
        Dim byte2 As String = Chr(CInt(lineLen / &H100))
        Dim bBuffer As String = byte1 & byte2 & New String(ChrW(32), lineLen)
        'OK, try to get back.
        Dim gotChars As Integer = CInt(SendMessage(editControl.Handle, EM_GETLINE, New IntPtr(ZeroBasedLinetoRead), bBuffer))

        If gotChars > 0 Then
            Return bBuffer.Substring(0, gotChars)
        Else
            Return String.Empty
        End If

    End Function

    Public Function GetCurrentLineIndex(ByRef editControl As System.Windows.Forms.TextBox) As Integer
        'returns the number of the current line indicated by the cursor NUMBERED FROM 0!
        'get the line number: arguments of -1 mean "line with caret", 0 is not used
        GetCurrentLineIndex = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_LINEFROMCHAR, -1, 0)
    End Function
	
    Public Sub SetCurrentLineIndex(ByRef editControl As System.Windows.Forms.TextBox, ByRef line As Integer)
        'sets the caret to the line numbered line
        Dim charIndex As Integer
        'get the character index of line
        charIndex = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_LINEINDEX, line, 0)
        editControl.SelectionStart = charIndex
        editControl.SelectionLength = 0
    End Sub
	
    Public Function GetNumberedLine(ByRef editControl As System.Windows.Forms.TextBox, ByRef lineNumber As Integer) As String
        'returns the numbered line
        Return editControl.Lines(lineNumber)
    End Function
	
    Public Function GetNumberOfLines(ByRef editControl As System.Windows.Forms.TextBox) As Integer
        'Returns the number of lines in the control.
        'This gives the actual number of lines as currently displayed, taking into account word wrap.
        'So while editControl.Lines has the number of [text chunks with newlines] and never changes 
        'even as you resize the control, GetNumberOfLines gives the number of [lines actually shown
        'in the control] which will be the same or greater.
        GetNumberOfLines = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_GETLINECOUNT, 0, 0)
    End Function
	
    Public Function GetCharacterIndexOfLine(ByRef editControl As System.Windows.Forms.TextBox, ByRef lineNumber As Integer) As Integer
        'returns the number of characters in the control up to the numbered line
        GetCharacterIndexOfLine = modAPIDeclarations.SendMessage(editControl.Handle.ToInt32, EM_LINEINDEX, lineNumber, 0)
    End Function
	
	Public Sub SetImagesOnOrOffInIE(ByRef State As Boolean)
		'put image loading in ie in the registry back to its original setting on leaving WebbIE
		'state is determined by blnIEImages
        Dim regKey As Microsoft.Win32.RegistryKey
        Dim stateString As String

        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\Internet Explorer\Main", True)
        If State Then
            stateString = "yes"
        Else
            stateString = "no"
        End If
        Call regKey.SetValue("Display Inline Images", stateString)
        Call regKey.Close()
	End Sub
	
	Public Function GetImagesOnOrOffInIE() As Boolean
        Dim regKey As Microsoft.Win32.RegistryKey
        Dim stateString As String

        regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("Software\Microsoft\Internet Explorer\Main", False)
        stateString = regKey.GetValue("Display Inline images").ToString
        regKey.Close()
        If LCase(stateString) = "yes" Then
            Return True
        Else
            Return False
        End If
    End Function
End Module