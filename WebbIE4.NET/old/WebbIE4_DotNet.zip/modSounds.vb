Option Strict On
Option Explicit On
Module modSounds
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	'Sounds
	' Contains functions for calling the different navigation and interface sounds
	' in WebbIE
	
	Private Const SND_ASYNC As Integer = 1
	Private Const SND_LOOP As Integer = 8
	Private Const SND_ALIAS As Integer = &H10000 ' use System sounds
    Private Const SND_FILENAME As Integer = &H20000 '' from mmsystem.h
	Private Const SND_NODEFAULT As Integer = &H2
	' Silence if sound not found
	Private Const SND_RESOURCE As Integer = &H40004
	' Name is resource name or atom
	
	
	'Why play a sound when the program quits? Just quit, dammit.
	'Public Sub PlayExitSound()
	''plays the sound when the program quits
	'    Call PlaySound(App.Path & "\sounds\exit.WAV", 0, SND_ASYNC)
	'End Sub
	
    Public Sub PlayProgressSound(ByRef progress As Integer)
        If frmMain.frmOptions.chkNavigationSounds.Checked Then
            Call PlayResourceWav("progress" & progress & ".wav")
        End If
    End Sub

    Public Sub PlayResourceWav(name As String)
        Dim sp As System.Media.SoundPlayer = New System.Media.SoundPlayer()
        sp.Stream = System.Reflection.Assembly.LoadFrom(Application.ExecutablePath).GetManifestResourceStream(name)
        Call sp.Play()
    End Sub

    Public Sub PlayDoneSound()

        'plays the sound when the program has finished - a "dong"
        If frmMain.frmOptions.chkNavigationSounds.Checked Then
            Call PlayResourceWav("done.wav")
        End If
    End Sub

    Public Sub PlayErrorSound()

        'plays sound to indicate error
        'In fact, can just use Beep
        Call Beep()
    End Sub

    Public Sub PlayWorkingSound()
        'plays a sound to indicate WebbIE is working
        If frmMain.frmOptions.chkNavigationSounds.Checked Then
            Call PlayResourceWav("working.wav")
        End If

    End Sub

    Public Sub PlayLocationRefreshSound()

        'plays the sound when an RSS feed is discovered
        If frmMain.frmOptions.chkNavigationSounds.Checked Then
            Call PlayResourceWav("locationrefresh.wav")
        End If
    End Sub

    Public Sub PlayStartSound()
        'plays the sound when an RSS feed is discovered
        If frmMain.frmOptions.chkNavigationSounds.Checked Then
            Call PlayResourceWav("start.wav")
        End If
    End Sub

    Public Sub PlayRSSSound()

        'plays the sound when an RSS feed is discovered
        If frmMain.frmOptions.chkNavigationSounds.Checked Then
            Call PlayResourceWav("rss.wav")
        End If
    End Sub

    Public Sub PlayAjaxSound()

        'plays the sound when an Ajax-inspired focus change occurs
        'plays the sound when an RSS feed is discovered
        If frmMain.frmOptions.chkNavigationSounds.Checked Then
            Call PlayResourceWav("ajaxfocus.wav")
        End If
    End Sub
End Module