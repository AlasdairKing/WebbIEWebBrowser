Option Strict On
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmLinks
	Inherits System.Windows.Forms.Form
	'   This file is part of WebbIE.
	'
	'    WebbIE is free software: you can redistribute it and/or modify
	'    it under the terms of the GNU General Public License as published by
	'    the Free Software Foundation, either version 3 of the License, or
	'    (at your option) any later version.
	'
	'    WebbIE is distributed in the hope that it will be useful,
	'    but WITHOUT ANY WARRANTY; without even the implied warranty of
	'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	'    GNU General Public License for more details.
	'
	'    You should have received a copy of the GNU General Public License
	'    along with WebbIE.  If not, see <http://www.gnu.org/licenses/>.
	
	
	Public targetForm As frmMain
	
	Private Sub cmdCloseLinks_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCloseLinks.Click
        cmdGo.Enabled = False
		Call Me.Hide()
	End Sub
	
	Private Sub cmdGo_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdGo.Click
        Dim selection As Integer
		
		selection = lstLinks.SelectedIndex
		If selection = -1 Then
			'nothing selected - don't do anything
		Else
            If (optSortPageOrder.Checked) Then
                Call targetForm.StartNavigating(links(selection + 1).address)
            Else
                Call targetForm.StartNavigating(sortedLinks(selection + 1).address)
            End If
			Call Me.Hide()
		End If
	End Sub
	
	
    Private Sub frmLinks_Activated(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Activated
        lstLinks.Font = Me.targetForm.txtText.Font
        If lstLinks.SelectedIndex > -1 Then
            cmdGo.Enabled = True
        End If
    End Sub
	
	Private Sub frmLinks_KeyUp(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        Dim KeyCode As Integer = eventArgs.KeyCode
        Dim Shift As Integer = eventArgs.KeyData \ &H10000
		'see if user has pressed ALT-A or ALT-P to change order

        '    If KeyCode = vbKeyEscape Then Me.Hide
    End Sub

    Private Sub lstLinks_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstLinks.SelectedIndexChanged

        cmdGo.Enabled = True
    End Sub
	
	Private Sub lstLinks_DoubleClick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles lstLinks.DoubleClick
        cmdGo_Click(cmdGo, New System.EventArgs())
	End Sub
	
	Private Sub lstLinks_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles lstLinks.KeyPress
        Dim KeyAscii As Integer = Asc(eventArgs.KeyChar)
        '    If (KeyAscii = vbKeyReturn) Then
		'        cmdGo_Click
		'    End If
		eventArgs.KeyChar = Chr(KeyAscii)
		If KeyAscii = 0 Then
			eventArgs.Handled = True
		End If
	End Sub
	
	Public Sub PopulateList(Optional ByRef newList As Boolean = True)
        Dim i As Integer
		Dim address As String
        Dim currentAddress As String = "" ' the current url selected, if any
		
		If lstLinks.SelectedIndex = -1 Then
			'no selected link
		Else
			'we have a selected link: remember what it is for when we change link
			'order so it can remain the selected link.
            currentAddress = lstLinks.Text
		End If
		Call lstLinks.Items.Clear()
		
        If optSortPageOrder.Checked Then
            'page order
            For i = 1 To numLinks
                address = links(i).address
                If InStr(1, address, "//") > 0 Then
                    address = VB.Right(address, Len(address) - InStr(1, address, "//") - 1)
                End If
                Call lstLinks.Items.Add(links(i).description & " - " & address)
                'check to see if this link we have just added was the current link
                'If so, make it the selected link
                If links(i).description & " - " & address = currentAddress Then
                    'found it!
                    lstLinks.SelectedIndex = lstLinks.Items.Count - 1
                End If
            Next i
        Else
            'alphabetical order
            For i = 1 To numLinks
                address = sortedLinks(i).address
                If InStr(1, address, "//") > 0 Then
                    address = VB.Right(address, Len(address) - InStr(1, address, "//") - 1)
                End If
                Call lstLinks.Items.Add(sortedLinks(i).description & " - " & address)
                'check to see if this link we have just added was the current link
                'If so, make it the selected link
                If sortedLinks(i).description & " - " & address = currentAddress Then
                    'found it!
                    lstLinks.SelectedIndex = lstLinks.Items.Count - 1
                End If
            Next i
        End If
		If newList Or lstLinks.SelectedIndex = -1 Then
			lstLinks.SelectedIndex = 0
		End If
	End Sub
	
End Class